import app from './app.js';


const port = 7777;

app.listen(port, (err) => {
  if (err) {
    console.log('Algo não deu certo');
  } else {
    console.log(
      `O Servidor foi iniciado com sucesso: http://localhost:${port}`
    );
  }
});
