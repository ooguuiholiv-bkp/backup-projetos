const { employeeRegister, allEmployees } = require('../services/employees.service');

// Cadastrar um funcionário
const registerEmployee = async (req, res) => {
  const { name, cpf } = req.body;
  const { name: nome, cpf: document, _id } = await employeeRegister({ name, cpf });
  return res.status(200).json({ nome, document, _id });
};

// listar funcionarios
const getAllEmployees = async (req, res) => {
  const employee = await allEmployees();
  return res.status(200).json(employee);
};

export { registerEmployee, getAllEmployees };
