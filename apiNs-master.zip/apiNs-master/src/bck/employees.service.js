import { employeeExist, getAllEmployees, newEmployee } from '../models/employees.model';

// Cadastra funcionario
const employeeRegister = async ({ name, cpf }) => {
  const employee = await employeeExist({ cpf });
  if (employee) return employee;
  const newEmploye = await newEmployee({ name, cpf });
  return newEmploye;
};

const allEmployees = async () => {
  const employee = await getAllEmployees();
  return employee;
};

export { employeeRegister, allEmployees };
