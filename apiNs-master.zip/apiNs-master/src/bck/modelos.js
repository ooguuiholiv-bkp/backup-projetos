// Funcionários
class Employee extends Model {}
Employee.init(
  {
    employee_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    employee_name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    employee_cpf: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  {
    sequelize: connection(),
    modelName: 'Employee'
  }
);

// Equipes
class Team extends Model {}
Team.init(
  {
    team_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    frota: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  {
    sequelize: connection(),
    modelName: 'Team'
  }
);

// Veículos
class Vehicle extends Model {}
Vehicle.init(
  {
    vehicle_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    marca: {
      type: DataTypes.STRING,
      allowNull: false
    },
    placa: {
      type: DataTypes.STRING,
      allowNull: false
    },
    km: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  {
    sequelize: connection(),
    modelName: 'Vehicle'
  }
);

class Cliente extends Model {}
Cliente.init(
  {
    cliente_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cnpj: {
      type: DataTypes.STRING,
      allowNull: false
    },
    user: {
      type: DataTypes.STRING,
      allowNull: false
    },
    pass: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  {
    sequelize: connection(),
    modelName: 'Cliente'
  }
);

class User extends Model {}
User.init(
  {
    user_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false
    },
    user: {
      type: DataTypes.STRING,
      allowNull: false
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false
    },
    pass: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  {
    sequelize: connection(),
    modelName: 'User'
  }
);

class NS extends Model {}
NS.init(
  {
    ns_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true
    },
    ns: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cliente: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cidade: {
      type: DataTypes.STRING,
      allowNull: false
    },
    tipo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    dataInicio: {
      type: DataTypes.DATE,
      allowNull: false
    },
    dataFinal: {
      type: DataTypes.DATE,
      allowNull: false
    },
    situacao: {
      type: DataTypes.STRING,
      allowNull: false
    },
    statusCemig: {
      type: DataTypes.STRING,
      allowNull: false
    },
    calcLT: {
      type: DataTypes.STRING,
      allowNull: false
    },
    travRodDNIT: {
      type: DataTypes.STRING,
      allowNull: false
    },
    travRodDER: {
      type: DataTypes.STRING,
      allowNull: false
    },
    parametrizacao: {
      type: DataTypes.STRING,
      allowNull: false
    },
    travessiaFCA: {
      type: DataTypes.STRING,
      allowNull: false
    },
    suprimentos: {
      type: DataTypes.STRING,
      allowNull: false
    },
    vistoria: {
      type: DataTypes.STRING,
      allowNull: false
    },
    preAtt: {
      type: DataTypes.STRING,
      allowNull: false
    },
    devolucao: {
      type: DataTypes.STRING,
      allowNull: false
    },
    pendencia: {
      type: DataTypes.STRING,
      allowNull: false
    },
    cco: {
      type: DataTypes.STRING,
      allowNull: false
    },
    transformadores: {
      type: DataTypes.STRING,
      allowNull: false
    },
  },
  { sequelize: connection(), modelName: 'NS' }
);

Employee.sync({ force: false });
Team.sync({ force: false });
Vehicle.sync({ force: false });
Cliente.sync({ force: false });
User.sync({ force: false });
NS.sync({ force: false });
