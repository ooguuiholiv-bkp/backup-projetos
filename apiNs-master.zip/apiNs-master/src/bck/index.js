import { Router } from 'express';
import { createUser, deleteUser, getAll, infoUser, updateUser } from '../controllers/user.controller'
import { getAllEmployees, registerEmployee } from '../controllers/employees.controller';
import { teste } from '../models/user.model';

const routes = new Router();

// routes.get('/', (req, res) => {
//   res.sendStatus(200)
// });

routes.get('/', teste)


/*--------------------------------------------------------------*/
/*---------------------ROTAS DE USUÁRIO-------------------------*/

// obtém a lista de usuários
routes.get('/users', getAll);

// Obtem os dados do usuário ativo
/*TODO criar rota de consulta aos dados do usuario que está ativo */
routes.get('/users/:id', infoUser)


// Criar usuario
routes.post('/users', createUser)

// deleção de usuário
routes.delete('/users/:id', deleteUser)

// Atualizar usuário
routes.put('/users/:id', updateUser)

/*--------------------------------------------------------------*/


/*--------------------------------------------------------------*/
/*-------------------ROTAS DE FUNCIONARIO-----------------------*/

// Cadastro de funcionário
routes.post('/employee', registerEmployee)

// Listar funcionarios
routes.get('/employee', getAllEmployees);




/*--------------------------------------------------------------*/

export default routes;
