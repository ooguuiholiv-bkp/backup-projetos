import connection from './mongoConnection';

// Verifica se o funcionario existe no bd
const employeeExist = async ({ cpf, id }) => {
  const db = await connection();
  let employee = null;
  if (cpf) {
    employee = await db.collection('employee').findOne({ cpf });
  }
  return employee;
};

// Adiciona funcionario ao banco de dados

const newEmployee = async ({ name, cpf }) => {
  const db = await connection();
  const employee = await db.collection('employee').insertOne({ name, cpf });
  const {insertedId: id} = employee
  return {id, name, cpf}
};

// Lista funcionarios
const getAllEmployees = async () => {
  const db = await connection();
  return db.collection('employee').find().toArray();
};

export { employeeExist, newEmployee, getAllEmployees };
