import { connection, User } from '../db/db';
import { ObjectId } from 'mongodb';


/*------------------------------------------------------------------*/
/*----------------------ROTAS DE USUÁRIO----------------------------*/

// Consulta todos os usuários cadastrados
const getAll = async () => {
  const db = await connection();
  return db.collection('users').find().toArray();
};

// Obtem informações de usuario
const getUser = async ({ id }) => {
  const db = await connection();
  return db
    .collection('users')
    .find({ _id: ObjectId(id) })
    .toArray();
};

// Cria um novo usuário
const newUser = async ({ name, user, email, password }) => {
  const db = await connection();
  const usuario = await User.create({
    name: name,
    user: user,
    email: email,
    password: password
  })
  const { insertedId: id } = usuario;
  return { email, user, name, _id: id, perfil };
};

// Verifica se o usuario existe no bd
const userExists = async ({ email, id }) => {
  const db = await connection();
  let user = null;
  if (id) {
    user = await db.collection('users').findOne({ _id: ObjectId(id) });
  } else {
    user = await db.collection('users').findOne({ email });
  }
  return user;
};

// Deleta usuario
const deleta = async ({ id }) => {
  const db = await connection();
  await db.collection('users').deleteOne({ _id: ObjectId(id) });
  return { id };
};

// Atualiza usuario
const update = async ({ id, email, password, user }) => {
  const db = await connection();

  if (email != undefined) {
    await db
      .collection('users')
      .updateOne({ _id: ObjectId(id) }, { $set: { email } });
  }
  if (password != undefined) {
    await db
      .collection('users')
      .updateOne({ _id: ObjectId(id) }, { $set: { password } });
  }
  if (user != undefined) {
    await db
      .collection('users')
      .updateOne({ _id: ObjectId(id) }, { $set: { user } });
  }
  // await db
  //   .collection('users')
  //   .updateOne({ _id: ObjectId(id) }, { $set: { email, user, password } });
  return { id, email, user };
};

/*------------------------------------------------------------------*/
export { getAll, newUser, userExists, deleta, update, getUser, teste };
