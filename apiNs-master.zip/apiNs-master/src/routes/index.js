import { Router } from 'express';

import {
  createUser,
  deleteUser,
  getAll,
  infoUser,
  updateUser,
} from '../controllers/user.controller';
import {
  createEmployee,
  deleteEmployee,
  getAllEmployee,
  infoEmployee,
  updateEmployee,
} from '../controllers/employee.controller';
import {
  createVehicle,
  deleteVehicle,
  getAllVehicle,
  getInfoVehicle,
  updateVehicle,
} from '../controllers/vehicle.controller';
import {
  createClient,
  getAllClient,
  getInfoClient,
  updateClient,
} from '../controllers/client.controller';
import {
  createNS,
  delNS,
  getAllNS,
  infoNs,
  updateNS,
} from '../controllers/ns.controller';
import { AuthLogin } from '../controllers/auth.controller';

const routes = new Router();

routes.get('/', (req, res) => {
  res.sendStatus(200);
});

/* Rotas de usuario */
routes.get('/users', getAll);
routes.get('/users/:id', infoUser);
routes.post('/users', createUser);
routes.put('/users/:id', updateUser);
routes.delete('/users/:id', deleteUser);

/* Rotas de funcionario */
routes.get('/employee', getAllEmployee);
routes.get('/employee/:id', infoEmployee);
routes.post('/employee', createEmployee);
routes.delete('/employee/:id', deleteEmployee);

/* Rotas de Frotas */
routes.get('/vehicle', getAllVehicle);
routes.get('/vehicle/:id', getInfoVehicle);
routes.post('/vehicle', createVehicle);
routes.put('/vehicle/:id', updateVehicle);
routes.delete('/vehicle/:id', deleteVehicle);

/* Rotas de clientes */
routes.get('/client', getAllClient);
routes.get('/client/:id', getInfoClient);
routes.post('/client', createClient);
routes.put('/client/:id', updateClient);

/* Rotas de NS */
routes.get('/ns/:id', infoNs);
routes.get('/ns', getAllNS);
routes.post('/ns', createNS);
routes.put('/ns/:id', updateNS);
routes.delete('/ns/:id', delNS);

/* Rota Auth */
routes.post('/auth', AuthLogin);


routes.post('/test', (req, res)=> {
  const {user, email, password, cliente} = req.body;
  res.status(200).json({user,email,password,cliente})
})

/* Rotas de Equipe */
// routes.post('/team')

export default routes;
