import {
  NSCreate,
  NSdel,
  allNS,
  editaNS,
  getInfoNS,
} from '../services/ns.service';

const createNS = async (req, res) => {
  const {
    ns,
    cliente,
    cnpj,
    cidade,
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  } = req.body;

  const {
    ns: NS,
    cliente: Cliente,
    situacao: Situacao,
  } = await NSCreate({
    ns,
    cliente,
    cnpj,
    cidade,
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  });
  return res.status(200).json({ NS, Cliente, Situacao });
};

const getAllNS = async (req, res) => {
  const NS = await allNS();
  return res.status(200).json({ NS });
};

const infoNs = async (req, res) => {
  const { id } = req.params;
  const info = await getInfoNS({ id });
  return res.status(200).json({ info });
};

const delNS = async (req, res) => {
  const { id } = req.params;
  const deletar = await NSdel({ id });
  return res.status(200).json({ deletar });
};

const updateNS = async (req, res) => {
  const { id } = req.params;
  const {
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  } = req.body;
  const edita = await editaNS({
    id,
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  });
  return res.status(200).json({ edita });
};

export { createNS, getAllNS, infoNs, delNS, updateNS };
