import { EmployeeInfo, allEmployee, create, delEmployee } from "../services/employee.service";

// criar um usuário
const createEmployee = async (req, res) => {
  const {employee, cpf} = req.body;
  const {employee: trabalhador, cpf: documento } = await create({employee, cpf})
  return res.status(200).json({trabalhador, documento})
};

const getAllEmployee = async (req, res) => {
  const funcionarios = await allEmployee()
  return res.status(200).json({funcionarios})

}

const infoEmployee = async (req, res) => {
  const {id} = req.params;
  const employee = await EmployeeInfo({id})
  return res.status(200).json({employee})
}

const deleteEmployee = async (req, res) => {
  const {id} = req.params;
  const delFunc = await delEmployee({id})
  return res.status(200).json(delFunc)
}

export {createEmployee, getAllEmployee, infoEmployee, deleteEmployee}
