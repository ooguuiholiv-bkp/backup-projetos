import { getUser } from '../models/user.model';
import { all, atualizar, criar, deletar } from '../services/user.service';
import {hash} from 'bcrypt'

/* --------------------------------------------------------- */
/* --------------------------------------------------------- */
// obter a lista de todos os usuarios
const getAll = async (req, res) => {
  const users = await all();
  const newList = users.map((user) => ({
    id: user.user_id,
    name: user.name,
    user: user.user,
    email: user.email,
  }));
  return res.status(200).json(newList);
};

// TODO Refatorar código -> rota esta chamando user.model

// Obter informações de um usuario atraves do id
const infoUser = async (req, res) => {
  const { id } = req.params;
  const users = await getUser({ id });
  const newList = users.map((user) => ({
    id: user.user_id,
    name: user.name,
    user: user.user,
    email: user.email,
    cliente: user.cliente
  }));
  return res.status(200).json({newList});
};

// criar um usuário
const createUser = async (req, res) => {
  const { name, user, email, password, cliente } = req.body;
  const passwordHash = await hash(password, 8)
  console.log(passwordHash)
  const { email: mail } = await criar({ name, user, email, passwordHash, cliente });
  return res.status(200).json({ mail, user, name });
};

// Deletar um usuário

const deleteUser = async (req, res) => {
  const { id } = req.params;
  const user = await deletar({ id });
  return res.status(200).json(user);
};

// Atualiza usuario
const updateUser = async (req, res) => {
  const { email, password, user } = req.body;
  const { id } = req.params;
  const dataUser = await atualizar({ id, email, password, user });
  res.status(200).json(dataUser);
};


/* --------------------------------------------------------- */
export { getAll, createUser, deleteUser, updateUser, infoUser };
