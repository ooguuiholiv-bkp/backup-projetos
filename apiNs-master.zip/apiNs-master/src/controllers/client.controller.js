import { hash } from 'bcrypt';
import {
  allClientes,
  clientCreate,
  clientUpdate,
  infoClient,
} from '../services/client.service';

const createClient = async (req, res) => {
  const { name, cnpj } = req.body;
  const { name: razaoSocial, cnpj: CNPJ } = await clientCreate({
    name,
    cnpj
  });
  return res.status(200).json({ razaoSocial, CNPJ });
};

const getAllClient = async (req, res) => {
  const clientes = await allClientes();
  return res.status(200).json({ clientes });
};

const getInfoClient = async (req, res) => {
  const { id } = req.params;
  const info = await infoClient({ id });
  return res.status(200).json({ info });
};

const updateClient = async (req, res) => {
  const { name, user, password } = req.body;
  const { id } = req.params;
  const atualiza = await clientUpdate({ name, user, password, id });
  return res.status(200).json({ atualiza });
};

export { createClient, getAllClient, getInfoClient, updateClient };
