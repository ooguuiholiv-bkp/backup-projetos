import {
  allVehicle,
  delVehicle,
  infoVehicle,
  vehicleCreate,
  vehicleUpdate,
} from '../services/vehicle.service';

const createVehicle = async (req, res) => {
  const { marca, placa, km } = req.body;
  const { marca: frota } = await vehicleCreate({ marca, placa, km });
  return res.status(200).json({ frota });
};

const getAllVehicle = async (req, res) => {
  const veiculos = await allVehicle();
  return res.status(200).json({ veiculos });
};

const getInfoVehicle = async (req, res) => {
  const { id } = req.params;
  const frota = await infoVehicle({ id });
  return res.status(200).json({ frota });
};

const updateVehicle = async (req, res) => {
  const { km, frota } = req.body;
  const { id } = req.params;
  const atualiza = await vehicleUpdate({ km, frota, id });
  return res.status(200).json({ atualiza });
};

const deleteVehicle = async (req, res) => {
  const { id } = req.params;
  const deletar = await delVehicle({ id });
  return res.status(200).json({ deletar });
};

export {
  createVehicle,
  getAllVehicle,
  getInfoVehicle,
  updateVehicle,
  deleteVehicle,
};
