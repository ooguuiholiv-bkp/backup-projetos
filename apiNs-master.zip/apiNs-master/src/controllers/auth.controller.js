import { Auth } from "../services/auth.service";

const AuthLogin = async (req, res) => {
  const {user, email, password} = req.body;
  const logar = await Auth({user, email, password})
  return res.status(200).json({logar})

}

export {AuthLogin}
