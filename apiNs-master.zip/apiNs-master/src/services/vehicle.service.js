import {
  criarFrota,
  destroyVehicle,
  frotaExist,
  listInfoVehicle,
  listarVeiculos,
  updateFrota,
} from '../models/vehicle.model';

const vehicleCreate = async ({ marca, placa, km }) => {
  const vehicle = await frotaExist({ placa });
  if (vehicle) return vehicle;
  const frota = await criarFrota({ marca, placa, km });
  return frota;
};

const allVehicle = async () => {
  const veiculos = await listarVeiculos();
  return veiculos;
};

const infoVehicle = async ({ id }) => {
  const info = await listInfoVehicle({ id });
  return info;
};

const vehicleUpdate = async ({ frota, km, id }) => {
  const vehicle = await frotaExist({ id });
  if (!vehicle) return vehicle;
  const atualiza = await updateFrota({ frota, km, id });
  return atualiza;
};

const delVehicle = async ({ id }) => {
  const vehicle = await frotaExist({ id });
  if (!vehicle) return { message: 'Veículo não encontrado' };
  const deletar = await destroyVehicle({ id });
  return deletar;
};

export { vehicleCreate, allVehicle, infoVehicle, vehicleUpdate, delVehicle };
