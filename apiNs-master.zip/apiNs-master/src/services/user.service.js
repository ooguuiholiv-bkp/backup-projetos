import {
  deleta,
  getAll,
  getUser,
  newUser,
  update,
  userExists,
} from '../models/user.model';

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

// Obtem a lista de usuario
const all = async () => {
  const users = await getAll();
  return users;
};

// info do usuario logado
const infoUser = async ({id}) => {
  const infoUser = await getUser({id});
  return infoUser
}

// Verifica e cria usuario caso nao exista no banco de dados
const criar = async ({ name, email, user, passwordHash, cliente }) => {
  const usuario = await userExists({ email });
  if (usuario) return usuario;
  const uzer = await newUser({ name, email, user, passwordHash, cliente });
  return uzer;
};

// Deleta um usuario do bd
const deletar = async ({ id }) => {
  const usuario = await userExists({ id });
  if (!usuario) return { message: 'Usuário não encontrado' };
  const user = await deleta({ id });
  return user;
};

// Atualiza usuário
const atualizar = async ({ id, email, password, user }) => {
  const usuario = await userExists({ id });
  if (!usuario) return { message: 'Usuário não encontrado' };

  const dados = await update({ id, email, password, user })
  return dados;
};

/* ---------------------------------------------------------------- */
export { all, criar, deletar, atualizar, infoUser };
