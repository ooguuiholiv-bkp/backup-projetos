import { Login } from '../models/auth.model';
import { userExists } from '../models/user.model';

const Auth = async ({ user, email, password }) => {
  const Exist = await userExists({ email });
  if (!Exist)
    return {
      message: 'Usuário ou senha nao encontrado em nossa base de dados',
    };
  const login = await Login({ user, email, password });
  return login;
};

export { Auth };
