import {
  AtualizaNs,
  addNs,
  deletarNs,
  infoNs,
  nsExist,
  todasNS,
} from '../models/ns.model';

const NSCreate = async ({
  ns,
  cliente,
  cnpj,
  cidade,
  tipo,
  dataInicio,
  dataFinal,
  situacao,
  statusCemig,
  calcLT,
  travRodDNIT,
  travRodDER,
  parametrizacao,
  travessiaFCA,
  suprimentos,
  vistoria,
  preAtt,
  devolucao,
  pendencia,
  cco,
  transformadores,
}) => {
  const EXISTE = await nsExist({ ns });
  if (EXISTE) return EXISTE;
  const statusObra = await addNs({
    ns,
    cliente,
    cnpj,
    cidade,
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  });

  return statusObra;
};

const allNS = async () => {
  const ns = await todasNS();
  return { ns };
};

const getInfoNS = async ({ id }) => {
  const listNs = await infoNs({ id });
  return { listNs };
};

const NSdel = async ({ id }) => {
  const del = await nsExist({ id });
  if (!del) return { message: 'NS Não encontrada em nossa base de dados' };
  const delNs = await deletarNs({ id });
  return delNs;
};

const editaNS = async ({
  id,
  tipo,
  dataInicio,
  dataFinal,
  situacao,
  statusCemig,
  calcLT,
  travRodDNIT,
  travRodDER,
  parametrizacao,
  travessiaFCA,
  suprimentos,
  vistoria,
  preAtt,
  devolucao,
  pendencia,
  cco,
  transformadores,
}) => {
  const EXISTE = await nsExist({ id });
  if (!EXISTE) return { message: 'NS Não encontrada em nossa base de dados' };
  const atualiza = await AtualizaNs({
    id,
    tipo,
    dataInicio,
    dataFinal,
    situacao,
    statusCemig,
    calcLT,
    travRodDNIT,
    travRodDER,
    parametrizacao,
    travessiaFCA,
    suprimentos,
    vistoria,
    preAtt,
    devolucao,
    pendencia,
    cco,
    transformadores,
  });
  return atualiza;
};

export { NSCreate, allNS, getInfoNS, NSdel, editaNS };
