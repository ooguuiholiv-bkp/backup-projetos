import { NewEmployee, delFuncionario, employeeExist, getAll, getEmployee } from "../models/employee.model"

const create = async ({employee, cpf}) => {
  const func = await employeeExist({cpf})
  if (func) return func;
  const newEmployee = await NewEmployee({employee, cpf})
  return newEmployee;
}

const allEmployee = async () => {
  const todos = await getAll()
  return todos;
}

const EmployeeInfo = async ({id}) => {
  const employeeInfo = await getEmployee({id})
  return employeeInfo

}

const delEmployee = async ({id}) => {
  const funcionario = await employeeExist({id})
  if(!funcionario) return {message: 'funcionário não encontrado'}
  const delFunc = await delFuncionario({id})
  return delFunc;

}
export {create, allEmployee, EmployeeInfo, delEmployee}
