import { AtualizaCliente, Criar, clientExist, dataClient, listClients } from "../models/client.model"

const clientCreate = async ({name, cnpj}) => {
  const cliente = await clientExist({cnpj})
  if (cliente) return cliente
  const newCliente = await Criar({name, cnpj})
  return newCliente;
}

const allClientes = async () => {
  const clientes = await listClients()
  return clientes;

}

const infoClient = async ({id}) => {
  const info = await dataClient({id})
  return info;
}

const clientUpdate = async ({name, password, user, id}) => {
  const cliente = await clientExist({id})
  if(!cliente) return {message: "Cliente não encontrado"}
  const atualiza = await AtualizaCliente({name, user, password, id})
  return atualiza;
}

export {clientCreate, allClientes, infoClient, clientUpdate}
