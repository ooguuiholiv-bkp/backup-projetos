const { Sequelize, DataTypes, UUIDV4 } = require('sequelize');
import * as dotenv from 'dotenv';
dotenv.config();

/* const sequelize = new Sequelize(
  process.env.DATA_DB,
  process.env.USER_DB,
  process.env.PASSWORD_DB,
  {
    host: process.env.HOST_DB,
    dialect: 'mysql',
    dialectModule: require('mysql2'),
    port: 3306,
  }
); */
const sequelize = new Sequelize('mbaconstrutora_bd', 'root', 'JunT4nd0@Ane', {
  host: 'localhost',
  dialect: 'mysql',
  dialectModule: require('mysql2'),
  port: 3306,
});

const connection = async () => {
  try {
    await sequelize.authenticate();
    console.log('All good');
  } catch (err) {
    console.error('All bad!!', err);
  }
};

const Employee = sequelize.define(
  'Employee',
  {
    employee_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    employee: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cpf: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
  }
);

const Vehicle = sequelize.define(
  'Vehicle',
  {
    vehicle_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    marca: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    placa: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    km: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
  }
);

const Team = sequelize.define(
  'Team',
  {
    team_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
  },
  {
    freezeTableName: true,
  }
);

const Client = sequelize.define(
  'Client',
  {
    cliente_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cnpj: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
  },
  {
    freezeTableName: true,
  }
);

const User = sequelize.define(
  'User',
  {
    user_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    user: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
    },
    pass: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cliente: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
  }
);

const NS = sequelize.define(
  'NS',
  {
    ns_id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true,
    },
    ns: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cliente: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cnpjCliente: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cidade: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    tipo: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dataInicio: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    dataFinal: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    situacao: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    statusCemig: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    calcLT: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    travRodDNIT: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    travRodDER: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    parametrizacao: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    travessiaFCA: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    suprimentos: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    vistoria: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    preAtt: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    devolucao: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    pendencia: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    cco: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    transformadores: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  { freezeTableName: true }
);

const Roles = sequelize.define('Roles', {
  roles_id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

const Roles_Users = sequelize.define('Roles_Users', {
  roles_users_id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    allowNull: false,
    primaryKey: true,
  },
});

/* Associações */
Team.belongsTo(Employee);
Employee.hasMany(Team);

Vehicle.belongsTo(Team);
Team.hasOne(Vehicle);

Team.belongsTo(Vehicle);
Vehicle.hasOne(Team);

User.hasOne(Client);
Client.belongsTo(User);

User.belongsToMany(Roles, { through: 'Roles_Users' });
Roles.belongsToMany(User, { through: 'Roles_Users' });

/* Criando tabelas */
sequelize.sync({ force: false }).then(() => {});

export { Employee, Vehicle, Team, Client, User, NS, Roles, Roles_Users, connection };
