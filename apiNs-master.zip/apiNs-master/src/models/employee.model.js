import { Employee } from '../db/db';

const employeeExist = async ({ cpf, id }) => {
  let employee = null;
  if (cpf != null || cpf != undefined) {
    employee = await Employee.findOne({
      where: {
        cpf: cpf,
      },
    });
  } else {
    employee = await Employee.findByPk(id);
  }
  return employee;
};

const NewEmployee = async ({ employee, cpf }) => {
 const newFunc = await Employee.create({
    employee: employee,
    cpf: cpf,
  });
  return { newFunc };
};

const getAll = async () => {
  const all = await Employee.findAll();
  return all;
};

const getEmployee = async ({ id }) => {
  const func = Employee.findAll({
    where: {
      employee_id: id,
    },
  });
  return func;
};

const delFuncionario = async ({ id }) => {
  const del = await Employee.destroy({
    where: {
      employee_id: id,
    },
  });
  return { del };
};

export { employeeExist, NewEmployee, getAll, getEmployee, delFuncionario };
