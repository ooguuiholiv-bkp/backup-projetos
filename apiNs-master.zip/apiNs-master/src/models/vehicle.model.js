import { Vehicle } from '../db/db';

const frotaExist = async ({ placa, id }) => {
  let vehicle = null;
  if (placa != undefined || placa != null) {
    vehicle = await Vehicle.findOne({
      where: {
        placa: placa,
      },
    });
  } else {
    vehicle = await Vehicle.findAll({
      where: {
        vehicle_id: id,
      },
    });
  }
  return vehicle;
};

const criarFrota = async ({ marca, placa, km }) => {
  const criar = await Vehicle.create({
    placa: placa,
    marca: marca,
    km: km,
  });
  return { criar };
};

const listarVeiculos = async () => {
  const listar = await Vehicle.findAll();
  return listar;
};

const listInfoVehicle = async ({ id }) => {
  const frota = await Vehicle.findAll({
    where: {
      vehicle_id: id,
    },
  });
  return frota;
};

const updateFrota = async ({ id, frota, km }) => {
  if (frota != null) {
    await Vehicle.update(
      { marca: frota },
      {
        where: {
          vehicle_id: id,
        },
      }
    );
  }
  if (km != null) {
    await Vehicle.update(
      { km: km },
      {
        where: {
          vehicle_id: id,
        },
      }
    );
  }
  return { frota, km };
};

const destroyVehicle = async ({ id }) => {
  const deletar = await Vehicle.destroy({
    where: {
      vehicle_id: id,
    },
  });
  return deletar;
};

export {
  frotaExist,
  criarFrota,
  listarVeiculos,
  listInfoVehicle,
  updateFrota,
  destroyVehicle,
};
