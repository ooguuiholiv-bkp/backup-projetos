import { NS } from '../db/db';

const nsExist = async ({ id, ns, cnpj }) => {
  let nsExistente = null;
  if (id != undefined || id != null) {
    nsExistente = await NS.findOne({
      where: {
        ns_id: id,
      },
    });
  }
  if (ns != undefined || ns != null) {
    nsExistente = await NS.findOne({
      where: {
        ns: ns,
      },
    });
  }
  if (cnpj != undefined || cnpj != null) {
    nsExistente = await NS.findOne({
      where: {
        cnpjCliente: cnpj,
      },
    });
  }
  return nsExistente;
};

const addNs = async ({
  ns,
  cliente,
  cnpj,
  cidade,
  tipo,
  dataInicio,
  dataFinal,
  situacao,
  statusCemig,
  calcLT,
  travRodDNIT,
  travRodDER,
  parametrizacao,
  travessiaFCA,
  suprimentos,
  vistoria,
  preAtt,
  devolucao,
  pendencia,
  cco,
  transformadores,
}) => {
  console.log(ns);
  const criar = await NS.create({
    ns: ns,
    cliente: cliente,
    cnpjCliente: cnpj,
    cidade: cidade,
    tipo: tipo,
    dataInicio: dataInicio,
    dataFinal: dataFinal,
    situacao: situacao,
    statusCemig: statusCemig,
    calcLT: calcLT,
    travRodDNIT: travRodDNIT,
    travRodDER: travRodDER,
    parametrizacao: parametrizacao,
    travessiaFCA: travessiaFCA,
    suprimentos: suprimentos,
    vistoria: vistoria,
    preAtt: preAtt,
    devolucao: devolucao,
    pendencia: pendencia,
    cco: cco,
    transformadores: transformadores,
  });
  return criar;
};

const todasNS = async () => {
  const ns = await NS.findAll();
  return { ns };
};

const infoNs = async ({ id }) => {
  const ns = await NS.findOne({
    where: {
      ns_id: id,
    },
  });
  return { ns };
};

const deletarNs = async ({ id }) => {
  const deleta = await NS.destroy({
    where: {
      ns_id: id,
    },
  });
  return deleta;
};

const AtualizaNs = async ({
  id,
  tipo,
  dataInicio,
  dataFinal,
  situacao,
  statusCemig,
  calcLT,
  travRodDNIT,
  travRodDER,
  parametrizacao,
  travessiaFCA,
  suprimentos,
  vistoria,
  preAtt,
  devolucao,
  pendencia,
  cco,
  transformadores,
}) => {
  if (tipo != null || tipo != undefined){
    await NS.update({tipo: tipo}, {where:{
      ns_id: id
    }})
  }
  if (dataInicio != null || dataInicio != undefined){
    await NS.update({dataInicio: dataInicio}, {where:{
      ns_id: id
    }})
  }
  if (dataFinal != null || dataFinal != undefined){
    await NS.update({dataFinal: dataFinal}, {where:{
      ns_id: id
    }})
  }
  if (situacao != null || situacao != undefined){
    await NS.update({situacao: situacao}, {where:{
      ns_id: id
    }})
  }
  if (statusCemig != null || statusCemig != undefined){
    await NS.update({statusCemig: statusCemig}, {where:{
      ns_id: id
    }})
  }
  if (calcLT != null || calcLT != undefined){
    await NS.update({calcLT: calcLT}, {where:{
      ns_id: id
    }})
  }
  if (travRodDNIT != null || travRodDNIT != undefined){
    await NS.update({travRodDNIT: travRodDNIT}, {where:{
      ns_id: id
    }})
  }
  if (travRodDER != null || travRodDER != undefined){
    await NS.update({travRodDER: travRodDER}, {where:{
      ns_id: id
    }})
  }
  if (parametrizacao != null || parametrizacao != undefined){
    await NS.update({parametrizacao: parametrizacao}, {where:{
      ns_id: id
    }})
  }
  if (travessiaFCA != null || travessiaFCA != undefined){
    await NS.update({travessiaFCA: travessiaFCA}, {where:{
      ns_id: id
    }})
  }
  if (suprimentos != null || suprimentos != undefined){
    await NS.update({suprimentos: suprimentos}, {where:{
      ns_id: id
    }})
  }
  if (vistoria != null || vistoria != undefined){
    await NS.update({vistoria: vistoria}, {where:{
      ns_id: id
    }})
  }
  if (preAtt != null || preAtt != undefined){
    await NS.update({preAtt: preAtt}, {where:{
      ns_id: id
    }})
  }
  if (devolucao != null || devolucao != undefined){
    await NS.update({devolucao: devolucao}, {where:{
      ns_id: id
    }})
  }
  if (pendencia != null || pendencia != undefined){
    await NS.update({pendencia: pendencia}, {where:{
      ns_id: id
    }})
  }
  if (cco != null || cco != undefined){
    await NS.update({cco: cco}, {where:{
      ns_id: id
    }})
  }
  if (transformadores != null || transformadores != undefined){
    await NS.update({transformadores: transformadores}, {where:{
      ns_id: id
    }})
  }
  return {message: "Os dados foram atualizados com sucesso!"}
};

export { nsExist, addNs, todasNS, infoNs, deletarNs, AtualizaNs };
