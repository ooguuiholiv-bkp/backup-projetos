import { Client } from '../db/db';

const clientExist = async ({ id, cnpj }) => {
  let cliente = null;
  if (cnpj != undefined || cnpj != null) {
    cliente = await Client.findOne({
      where: {
        cnpj: cnpj,
      },
    });
  } else {
    cliente = await Client.findByPk(id);
  }
  return cliente;
};

const Criar = async ({ name, cnpj }) => {
  const newCliente = await Client.create({
    name: name,
    cnpj: cnpj
  });
  return { newCliente };
};

const listClients = async () => {
  const clientes = await Client.findAll()
  return clientes

}

const dataClient = async ({id}) => {
  const cliente = await Client.findAll({
    where: {
      cliente_id: id
    }
  })
  return cliente
}

const AtualizaCliente = async ({name, user, password, id}) => {
  if (name != undefined || name != null){
    await Client.update({name: name},{
      where: {
        cliente_id: id
      }
    })
  }
  if (user != undefined || user != null){
    await Client.update({user: user},{
      where: {
        cliente_id: id
      }
    })
  }
  if (password != undefined || password != null){
    await Client.update({pass: password},{
      where: {
        cliente_id: id
      }
    })
  }
  return {name, user}
}

export { clientExist, Criar, listClients, dataClient, AtualizaCliente };
