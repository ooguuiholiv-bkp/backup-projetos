import { or } from 'sequelize';
import { User } from '../db/db';
import * as bcrypt from 'bcrypt';

const Login = async ({ user, email, password }) => {};

export { Login };
