import { Roles_Users, User } from '../db/db';
import { or } from 'sequelize';

/*------------------------------------------------------------------*/
/*----------------------ROTAS DE USUÁRIO----------------------------*/

// Consulta todos os usuários cadastrados
const getAll = async () => {
  return User.findAll();
};

// Obtem informações de usuario
const getUser = async ({ id }) => {
  const info = User.findAll({
    where: {
      user_id: id,
    },
  });
  return info;
};

// Cria um novo usuário
const newUser = async ({ name, user, email, passwordHash, cliente }) => {
  const newUser = await User.create({
    name: name,
    user: user,
    email: email,
    pass: passwordHash,
    cliente: cliente,
  });
  return { newUser };
};

// Verifica se o usuario existe no bd
const userExists = async ({ email, id, user }) => {
  let usuario = null;
  if (email != null || user != null) {
    usuario = await User.findOne({
      where: {
        email: email,
        or,
        user: user,
      },
    });
  } else {
    usuario = await User.findByPk(id);
  }
  return usuario;
};

// Deleta usuario
const deleta = async ({ id }) => {
  const deleta = await User.destroy({
    where: {
      user_id: id,
    },
  });
  return { deleta };
};

// Atualiza usuario
const update = async ({ id, email, password, user }) => {
  if (email != null) {
    await User.update(
      { email: email },
      {
        where: {
          user_id: id,
        },
      }
    );
  }
  if (password != null) {
    await User.update(
      { pass: password },
      {
        where: {
          user_id: id,
        },
      }
    );
  }
  if (user != null) {
    await User.update(
      { user: user },
      {
        where: {
          user_id: id,
        },
      }
    );
  }
  return { id, email, user };
};

/*------------------------------------------------------------------*/
export { getAll, newUser, userExists, deleta, update, getUser };
