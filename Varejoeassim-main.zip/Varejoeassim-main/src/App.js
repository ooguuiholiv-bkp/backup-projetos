import GlobalStyle from "./global";
import Varejo from "./pages/varejo";



function App() {
  return (
    <>
      <GlobalStyle />

      <Varejo />
    </>
  );
}

export default App;
