import React from "react";
// Importando Estilos
import "./styles.css";
import { Container } from "../SignIn/styles";
// Importando Imagens
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";
// Importando os Componentes
import { Button } from "../../components/Button";
import { TextAll } from "../../components/Text"; 
import { Input } from "../../components/Input";




export const RecoveryPage: React.FC = () => {
  return(
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="RecoveryArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <TextAll text="Informe Seu e-mail de usuário" id="txtRecovery" className="txtRecovery"/>
          <Input id="emailRecovery" type="text" className="emailRecovery" placeholder="Usuário / e-Mail" />
          <Button id="btnRecovery" className="btnRecovery" onclick={() => {alert("botão clicado")}} text="Recuperar Senha"/>
        </div>
      </Container>
    </div>
  )
}