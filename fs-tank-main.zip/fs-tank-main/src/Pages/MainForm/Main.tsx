import React from "react";

export const MainPage: React.FC = () => {
  return(
    <div>
      <h1>Teste</h1>
    </div>
  )
}