import React from "react";
// Importando folha de estilos
import "./styles.css";

import axios from "axios";


// Importando meus componentes
import { Input } from "../../components/Input";
import { Button } from "../../components/Button";
import { TextAll } from "../../components/Text";
import { Hiperlink } from "../../components/Hiperlink";
// Importando meus estilos
import { Container } from "./styles";
// Importando imagens necessárias
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";
import { useNavigate } from "react-router-dom";
// import SplashImg from "../../assets/splash2.png";
// import LogoImg from "../../assets/logo2.png";


let axiosConfig = {
  headers: {
    Authorization: ""
  }
}


export const SignIn: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash img" className="SplashImg" />
        <div className="LoginArea">
          <img src={LogoImg} alt="LogoImg" className="LogoImg" />
          <TextAll id="loginTxt" className="loginTxt" text="Informe suas credenciais de acesso" />
          <Input type="text" id="email" className="emailLogin" placeholder="Usuário / e-Mail" />
          <Input type="pass" id="password" className="passLogin" placeholder="Senha" />
          <Hiperlink id="hiperLogin" className="hiperLogin" href="#" text="Esqueci minha senha" />
          <Button text="Entrar" id="button" className="btnLogin" onclick={() => {

            function getElement<T extends HTMLElement>(selector: string) {
              const element = document.querySelector<T>(selector)
              if (!element) {
                throw new Error("O elemento não existe")
              }
              return element
            }

            const emailField = getElement<HTMLInputElement>('#email')
            const passwordField = getElement<HTMLInputElement>('#password')



            var email = emailField.value;
            var password = passwordField.value;

            axios.post("http://localhost:28555/auth", { email, password }).then(res => {
              var token = res.data.token;
              localStorage.setItem("token", token);
              axiosConfig.headers.Authorization = "Bearer " + localStorage.getItem("token");
            }).catch(err => {
              alert("login inválido ")
            })
          }} />
        </div>
      </Container>
    </div>

  )
}