import React from "react";
import "./styles.css";

import { Container } from "../SignIn/styles";
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";

import { TextAll } from "../../components/Text";
import { Input } from "../../components/Input";
import { Button } from "../../components/Button";



export const CheckCode: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="CheckCodeArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <TextAll id="checkTxt" className="checkTxt" text="Informe o código enviado em seu e-mail" />
          <div className="codeArea">
            <Input id="ChCode1" className="code1" placeholder="" type="text" />
            <Input id="ChCode1" className="code2" placeholder="" type="text" />
            <Input id="ChCode1" className="code3" placeholder="" type="text" />
            <Input id="ChCode1" className="code4" placeholder="" type="text" />
            <Input id="ChCode1" className="code5" placeholder="" type="text" />
          </div>
          <Button id="btnCheck" className="btnCheck" onclick={() => {alert("Clicou")}} text="Validar código de recuperação" />
        </div>
      </Container>
    </div>
  )
}