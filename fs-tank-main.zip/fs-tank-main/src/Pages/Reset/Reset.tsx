import React from "react";
import "./styles.css";

import { Container } from "../SignIn/styles";
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";

import { Input } from "../../components/Input";
import { Button } from "../../components/Button";





export const ResetPass: React.FC = () => {
  return(
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="ResetArea">
        <img src={LogoImg} alt="logo" className="LogoImg"/>
        <Input id="passReset" className="passReset" type="pass" placeholder="Nova senha" />
        <Input id="repeatPassReset" className="RepPassReset" type="pass" placeholder="Repita a nova senha" />
        <Button id="btnReset" className="btnReset" onclick={() => {alert("Clicou")}} text="Salvar nova senha" />
        </div>
      </Container>
    </div>
  )
}