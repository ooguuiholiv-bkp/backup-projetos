import React from "react";
import "./styles.css";
import { Container } from "../SignIn/styles";
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";


import { Button } from "../../components/Button";
import { TextAll } from "../../components/Text";
import { Hiperlink } from "../../components/Hiperlink";


export const VerifyPage: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="verifyArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <TextAll id="t1ver" className="t1ver" text="Nós enviamos um e-mail para você
contendo um código de recuperação."/>
          <TextAll id="t2ver" className="t2ver" text="verifique seu e-mail, anote o código
e selecione continuar."/>
          <TextAll id="t3ver" className="t3ver" text="Caso não tenha recebido o e-mail,
verifique sua caixa de spam ou clique
em reenviar o e-mail."/>
          <Button id="btnVerify" className="btnVerify" onclick={()=> {alert("clicou")}} text="Continuar" />
          <Hiperlink id="hiperVerify" className="hiperVerify" href="#" text="Reenviar o e-Mail"/>

        </div>
      </Container>
    </div>
  )
}