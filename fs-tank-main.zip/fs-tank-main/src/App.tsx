import React from 'react';
import { MyRoutes } from './route';

function App() {
  return (
      <MyRoutes />
  );
}

export default App;
