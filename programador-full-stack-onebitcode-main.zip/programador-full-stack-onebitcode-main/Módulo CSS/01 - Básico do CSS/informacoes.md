## Básico do CSS

#### O que é CSS?
Também conhecido como Cascade Style Sheets (Folha de Estilos em Cascata), é uma linguagem que define um estilo de um documento HTML, sempre é bom colocar o nosso CSS em arquivos separados
![Como funciona uma regra CSS](../../assets/comofuncionaumaregracss.png)

#### Cores no CSS!
Browsers modernos suportam 140 nomes de cores diferentes e elas podem ser especificadas de diversas formas diferentes:
* Nome
* Valores RGB
* Valores Hexadecimais
* Valores HSL (CSS3)
* Valores HWB (CSS4)

Definir cores por nome não é uma boa opção, afinal existem 140 nomes de cores, mas via hexadecimal somos capaz de atingir um numero muito maior que este, outro problema ao identificar a cor pelo nome é que pode acontecer de cada browser interpretar aquele nome de cor de uma forma diferente.
![Hexadecimal](../../assets/hexadecimal.png)
![Hexadecimal2](../../assets/hexadecimal2.png)

#### Backgrounds e Borders
Background é uma propriedade CSS utilizada para definir efeitos de background de um elemento (o que vai ser exibido no fundo do elemento)
* Background-color: é uma propriedade utilizada para definir a cor de fundo de um elemento
* Background-image: é uma propriedade que especifica uma imagem como fundo de um elemento
* Border: é uma propriedade do CSS utilizada para definir o estilo, largura e cor da borda de um elemento

#### O que são Seletores
Os seletores no CSS são padrões utilizados para identificar e selecionar elementos HTML em um documento, aos quais você deseja aplicar estilos ou regras de formatação. Eles permitem que você defina quais elementos específicos serão afetados pelas regras CSS que você escreve.Por exemplo, um seletor simples como h1 selecionará todos os elementos de cabeçalho de nível 1 no HTML, permitindo que você aplique estilos a esses elementos de forma consistente. Além disso, você pode combinar seletores de diferentes maneiras para ser mais específico na seleção de elementos, como usar classes (.) ou IDs (#) para direcionar elementos específicos.

[Sletores CSS](https://developer.mozilla.org/pt-BR/docs/Web/CSS/CSS_selectors)

[Os 30 Seletores CSS Que Você Deve Memorizar](https://webdesign.tutsplus.com/pt/the-30-css-selectors-you-must-memorize--net-16048t)

#### Especificidade
A especificidade determina quais regras de CSS serão aplicadas em seus elementos
![Cálculo de especificidade](../../assets/Especificidade%20Calculo.png)
Quando há empate na pontuação será considerado o último seletor a ser declarado

#### Herança
Basicamente, trata-se dos filhos herdando o estilo de seus pais

#### Textos e fontes
As fontes podem vir de dois lugares, ou da web, ou da máquina do usuário.