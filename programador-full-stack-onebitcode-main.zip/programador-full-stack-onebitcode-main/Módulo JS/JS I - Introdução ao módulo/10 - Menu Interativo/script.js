let menu = "";

do {
    menu = prompt("Secione uma das opções a seguir: \n1 - Home\n2 - Contatos\n3 - Downloads\n4 - Imagens\n5 - Encerrar")
    switch(parseFloat(menu)){
        case 1: 
            alert("Home") 
            break
        case 2: 
            alert("Contatos")
            break
        case 3: 
            alert("Downloads")
            break
        case 4: 
            alert("Imagens")
            break
        case 5: 
            alert("O programa esta sendo encerrado...")
            break
        default: "Opção inválida"
    }
} while(menu !== "5")
alert("O programa foi encerrado com sucesso!")