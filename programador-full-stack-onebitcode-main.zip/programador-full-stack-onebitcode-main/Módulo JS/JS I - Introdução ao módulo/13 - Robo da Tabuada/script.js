const tabuada = () => {
  let numero = prompt("Qual numero você deseja saber a tabuada? ");
  let mult = "";
  let result = "";

  for (let i = 0; i <= 20; i++) {
    mult = numero * i;
    console.log(
      "A multiplicação de " + i + " e " + numero + " é igual a " + mult
    );
    result += numero * i + "\n";
  }

  alert(result);
};

const palindromo = () => {
  const word = prompt("Informe uma palavra: ");
  let invertedWord = "";

  for (let i = word.length - 1; i >= 0; i--) {
    invertedWord += word[i];
  }
  if (word === invertedWord) {
    alert(word + " é um palíndromo!");
  } else {
    alert(word + " não é um palíndromo!\n\n" + word + " !== " + invertedWord);
  }
};
