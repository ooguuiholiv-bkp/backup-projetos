const conversor = () => {
  let vrConverte = prompt(
    "Informe um valor em metros para que seja convertido: "
  );
  let result;

  let medida = prompt(
    "Selecione para qual unidade deseja converter: \na)milímetro(mm)\nb)centímetro(cm)\nc)decímetro(dm)\nd)decâmetro(dam)\ne)hectômetro(hm)\nf)quilômetro(km)"
  );
  switch(medida){
    case "a":
        result = parseFloat(vrConverte) * 1000
        alert(vrConverte + " metros é igual a " + result + " milimetros")
        break
    case "b":
        result = parseFloat(vrConverte) * 100
        alert(vrConverte + " metros é igual a " + result + " centimetros")
        break
    case "c":
        result = parseFloat(vrConverte) * 10
        alert(vrConverte + " metros é igual a " + result + " decimetro")
        break
    case "d":
        result = parseFloat(vrConverte) / 10
        alert(vrConverte + " metros é igual a " + result + " decametro")
        break
    case "e":
        result = parseFloat(vrConverte) / 100
        alert(vrConverte + " metros é igual a " + result + " hectometro")
        break
    case "f":
        result = parseFloat(vrConverte) / 1000
        alert(vrConverte + " metros é igual a " + result + " kilometro")
        break
    default:
        alert("A opção selecionada não é válida")

  }
};
