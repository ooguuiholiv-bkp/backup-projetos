// const resultado = prompt("Escolha uma aternativa \na)\nb)\nc)")

const resultadoNumerico = prompt("Escolha uma aternativa \n1)\n2)\n3)")

switch (parseFloat(resultadoNumerico)){
    case 1:
        alert("O resultado é 'a'")
        break
    case 2:
        alert("O resultado é 'b'")
        break
    case 3:
        alert("O resultado é 'c'")
        break
    default:
        alert("finalizando...")
        
}