## Seja bem vindo ao módulo JS

#### O que é linguagem de programação
Nada mais é do que um conjunto de códigos com instruções para o computador realizar. Estão associadas ao comportamento de um programa.

#### O que é o Javascript
É uma linguagem de programação e possui algumas particularidades, criada em 1995 por Brendan Eich para ser usada pelo Netscape e nao tem nada a ver com JAVA. Seu nome oficial é ECMAScript e ela é de Alto nível e interpretada.É multiparadigma.

#### Tipos de dados

1. Tipos primitivos
    * Number e bigint
    * String
    * Boolean
    * Null e undefined

2. Objetos e funções

#### Variáveis
Servem para armazenar dados para utilização posterior de dados.
Existem algumas maneiras de criar variaveis:
1. var = 
2. let = 
3. const =

#### Operadores e expressões
Os operadores nos permitem manipular nossas variaveis e fazer cálculos, comparações, etc...
1. Operadores Aritméticos:
    * +
    * -
    * *
    * /
    * %

2. Agrupamento
    * ()

3. Atribuição
    * =
    * +=
    * -=
    * *=
    * /=
    * %=

4. Encadeamento

5. Incrementar ++ Decrementar --