let money = prompt("Qual o montante voce tem disponível? ")
let opcao;
let op;
do {
    opcao = prompt("1)Adicionar Dinheiro\n2)Remover Dinheiro\n3)Sair")
    if(opcao === "1"){
        op = prompt("Quanto será adicionado ao montante final? ")
        money = parseFloat(money) + parseFloat(op)
        alert("O seu valor total de montante é: R$ " + money)
    }
    if(opcao === "2"){
        op = prompt("Quanto será subtraído ao montante final? ")
        money = parseFloat(money) - parseFloat(op)
        alert("O seu valor total de montante é: R$ " + money)
    }
    if(opcao === "3"){
        break
    }
} while(opcao !== "3" || opcao !== "Sair")
alert("O seu valor total de montante é: R$ " + money)
