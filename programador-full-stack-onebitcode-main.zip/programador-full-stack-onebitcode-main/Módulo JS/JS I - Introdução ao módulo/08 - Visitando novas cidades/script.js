let turista = prompt("E aí turista, qual é o seu nome? ")
let cidades = "";
let contagem = 0;

let continuar = prompt("Você visitou alguma cidade? (Sim/Nao)")

while(continuar === "Sim"){
  let cidade = prompt("Qual é o nome da cidade visitada? ")
  cidades += " . " + cidade + "\n"
  contagem++
  continuar = prompt("Você visitou alguma outra cidade? (Sim/Nao)") 
}

alert(
  "Caraca " + turista + " Voce visitou " + contagem + " cidades\nMuito top, você ja visitou\n" + cidades
)