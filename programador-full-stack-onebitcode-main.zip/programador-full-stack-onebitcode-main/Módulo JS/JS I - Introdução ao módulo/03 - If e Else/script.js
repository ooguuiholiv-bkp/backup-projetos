if (6 !== "6") {
  console.log("OIee");
}

const result = 6 === 6 ? "Verdadeiro" : "Falso";
console.log(result);

let idade = prompt("Qual sua idade? ");

if (idade > 18) {
  alert("Você é maior de idade");
} else if (idade > 14) {
  alert("Você é adolescente");
} else if (idade < 14){
    alert("Você é criança")
}
