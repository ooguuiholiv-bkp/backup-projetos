let num1 = prompt("Informe um nº: ");
let num2 = prompt("Informe outro nº: ");


console.log(
  "A soma entre ",
  num1,
  "e",
  num2,
  "é igual a:",
  (parseFloat(num1) + parseFloat(num2))
);
console.log(
    "A subtração entre ",
    num1,
    "e",
    num2,
    "é igual a:",
    (parseFloat(num1) - parseFloat(num2))
  );
  console.log(
    "A multiplicação entre ",
    num1,
    "e",
    num2,
    "é igual a:",
    (parseFloat(num1) * parseFloat(num2))
  );
  console.log(
    "A divisão entre ",
    num1,
    "e",
    num2,
    "é igual a:",
    (parseFloat(num1) / parseFloat(num2))
  );
