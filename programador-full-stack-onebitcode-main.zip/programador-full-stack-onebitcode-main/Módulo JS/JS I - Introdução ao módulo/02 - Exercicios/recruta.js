let nome = prompt("Informe seu nome recruta: ");
let sobrenome = prompt("Informe seu sobrenome recruta: ");
let campoEstudo = prompt("Qual sua área de estudos?  ");
let anoDeNasc = prompt("E seu ano de nascimento é qual?  ");



console.log("Olá meu nome é ",
nome,
sobrenome,
" eu tenho",
2023 - anoDeNasc,
" anos e estudo ",
campoEstudo);;
