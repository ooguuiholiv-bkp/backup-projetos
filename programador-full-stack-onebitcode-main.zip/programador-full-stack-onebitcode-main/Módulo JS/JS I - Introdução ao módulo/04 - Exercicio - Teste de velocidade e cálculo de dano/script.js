const velocidade = () => {
  let car1 = prompt("Insira o nome do veículo: ");
  let vel1 = prompt("Qual a velocidade deste veículo? ");

  let car2 = prompt("Insira o nome do segundo veículo: ");
  let vel2 = prompt("Qual a velocidade deste veículo? ");

  if (parseFloat(vel1) > parseFloat(vel2)) {
    alert(
      "O veículo " + car1 + " está trafegando em velocidade maior que " + car2
    );
  } else if (parseFloat(vel1) < parseFloat(vel2)) {
    alert(
      "O veículo " + car2 + " está trafegando em velocidade maior que " + car1
    );
  } else {
    alert("Ambos os veículos estão trafegando em mesma velocidade");
  }
};

const calculoDeDano = () => {
  let dano = 0;
  let person1 = prompt("Informe o nome do personagem atacante: ");
  let atackPower = prompt("Qual seu poder de ataque? ");

  let person2 = prompt("Informe o nome do personagem defensor: ");
  let lifePoints = prompt("Informe seus pontos de vida: ");
  let defPoints = prompt("Informe seu poder de defesa: ");
  let shield = prompt(
    "Seu personagem possui escudo? (responda com *sim* ou *nao*) "
  );

  if (parseFloat(atackPower) > parseFloat(defPoints) && shield === "nao") {
    dano = parseFloat(atackPower) - parseFloat(defPoints);
    lifePoints = parseFloat(lifePoints) - parseFloat(dano);
    alert(
      "O ataque de " +
        person1 +
        " a " +
        person2 +
        " gerou um dano de " +
        dano +
        " os pontos de vida de " +
        person2 +
        " agora são " +
        lifePoints
    );
  } else if (
    parseFloat(atackPower) > parseFloat(defPoints) &&
    shield === "sim"
  ) {
    dano = (parseFloat(atackPower) - parseFloat(defPoints)) * 0.5;
    lifePoints = parseFloat(lifePoints) - parseFloat(dano);
    alert(
      "O ataque de " +
        person1 +
        " a " +
        person2 +
        " gerou um dano de " +
        dano +
        " os pontos de vida de " +
        person2 +
        " agora são " +
        lifePoints
    );
  } else if (parseFloat(atackPower) <= parseFloat(defPoints)) {
    dano = 0;
    lifePoints = parseFloat(lifePoints) - parseFloat(dano);
    alert(
      "O ataque de " +
        person1 +
        " a " +
        person2 +
        " nao gerou dano algum a " +
        person2 +
        " os pontos de vida de " +
        person2 +
        " continuam " +
        lifePoints
    );
  }
};
