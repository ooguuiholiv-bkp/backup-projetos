let nome = "oguuiholiv"

for(let i = 0; i < nome.length; i++){
    console.log(nome[i])
}