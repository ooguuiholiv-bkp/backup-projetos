const listaDeCompras = []
console.log(listaDeCompras)

listaDeCompras[0] = "Arroz"
listaDeCompras[1] = "Feijão"
listaDeCompras[2] = 777