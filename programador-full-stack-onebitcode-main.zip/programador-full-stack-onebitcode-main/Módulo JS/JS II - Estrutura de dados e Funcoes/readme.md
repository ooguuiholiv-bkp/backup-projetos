## Estrutura de dados e Funcoes

### Estruturas de dados
É um modo particular de armazenar e organizar dados de modo que possam ser usados de forma eficiente, facilitando sua busca e modificação

1. Estrutura de dados clássicas
    * Lista ligada
        * Coleção ordenada de valores onde cada elemento aponta para o próximo
    * Array
        * Coleção de elementos que podem ser identificados por um índice
    * Fila (Queue)
        * Coleção de elementos onde o primeiro elemento a ser retirado deve ser o primeiro elemento adicionado.
        * Também chamadas de listas FIFO (first-in first-out, ou primeiro a entrar/ primeiro a sair)
        * ![FIFO](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Fifo_queue.png/640px-Fifo_queue.png)
    * Pilha (Stack)
        * Coleção de elementos onde o primeiro elemento a ser retirado deve ser o último elemento adicionado
        * Também chamadas de listas LIFO (last-in / first-out, ou último a entrar / primeiro a sair)
        * ![LIFO](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Lifo_stack.svg/800px-Lifo_stack.svg.png)
    * Árvore (Tree)
        * Conjunto de elementos chamados de nós (ou nodes) organizados em estrutura hierárquica (não sequencial), ou seja, podendo estar "abaixo" ou "acima" de outros nós.
        * Pense em uma árvore genealógica, na estrutura das pastas no seu computador ou na estrutura de uma página HTML.
        * ![TREE](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/Tree.example.png/300px-Tree.example.png)

2. Estruturas de dados no JavaScript (e outras linguagens de alto-nivel)
    * Listas (Arrays)
    * Dicionários (Objetos)


### Arrays (Vetores)
* É uma estrutura de dados para se trabalhar com todo tipo de lista
* Seus elementos são identificados por um índice inteiro começando pelo 0
* Pode armazenar qualquer tipo de dado e ter qualquer tamanho
* Pode ser criado e utilizado através de []
    * let array = []
    * array[0] = 'Olá'
    * array[1] = 42
* Possuem funções para vários casos de uso
    * enfileirar e desenfileirar
    * empilhar e desempilhar
    * achar o índice de um valor
    * cortar e concatenar
    * etc

### Trabalhando com Arrays

* Para adicionar elementos no final do array voce pode dar ```push```.

* Caso deseje adicionar elementos no inicio do array use ```unshift```.

* A função ```pop``` remove o ultimo elemento do array.

* Já caso deseje remover o primeiro elemento do array, deve usar a função ```shift```.

Vamos agora as Pesquisas de elementos.
Dentro de pesquisas temos o método ```includes``` que pesquisa se determinado elemento consta no array e nos retorna um estado booleano (true or false)

Tambem é possível utilizar o ```indexOf``` para localizar um item e retornar o indíce do elemento

O método ```slice``` faz uma cópia de um pedaço especifico do array e armazena em outro array

É possível tambem substituir elementos, utilizando o método ```splice``` é possível remover um grupo de elementos de um array e substituir por outro grupo de elementos