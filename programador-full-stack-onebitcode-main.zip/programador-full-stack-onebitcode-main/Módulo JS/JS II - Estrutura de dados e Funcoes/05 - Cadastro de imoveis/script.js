const app = () => {
  let opcao = "";
  const imoveis = [];

  do {
    opcao = prompt(
      "Bem-vindo(a) ao cadastro de imóveis!\n " +
        "Todal de imóveis: " +
        imoveis.length +
        "\n\nEscolha uma opção:\n1. Novo imóvel\n2. Lista de imóveis\n3. Sair"
    );
    switch (opcao) {
      case "1":
        const imovel = {};

        imovel.proprietario = prompt(
          "Informe o nome do proprietário do imóvel: "
        );
        imovel.quartos = prompt(
          "Informe a quantidade de quartos que o imóvel possui: "
        );
        imovel.banheiros = prompt(
          "Informe a quantidade de banheiros que o imóvel possui: "
        );
        imovel.garagem = prompt("O imóvel possui garagem? (Sim/Nao) ");

        const confirmacao = confirm(
          "Salvar este imóvel? \n" +
            "\nProprietário: " +
            imovel.proprietario +
            "\nNumero de quartos: " +
            imovel.quartos +
            "\nNumero de banheiros: " +
            imovel.banheiros +
            "\nPossui garagem? " +
            imovel.garagem
        );
        if (confirmacao) {
          imoveis.push(imovel);
        }
        break;
      case "2":
        for (let i = 0; i < imoveis.length; i++) {
          alert(
            "Imóvel: " +
              (i + 1) +
              "\nProprietário: " +
              imoveis[i].proprietario +
              "\nNumero de quartos: " +
              imoveis[i].quartos +
              "\nNumero de banheiros: " +
              imoveis[i].banheiros +
              "\nPossui garagem? " +
              imoveis[i].garagem
          );
        }
        break
      case "3":
        alert("Encerrando aplicação...");
        break;
      default:
        alert("Opção inválida...");
    }
  } while (opcao !== "3");
};
