

const func = () => {
    const arr = ['Nathaly', 'Samalla', 'Carol', 'Jany', 'Ane']
    console.log(arr)
    
    arr.push('Brasil')
    console.log(arr)
    arr.unshift('Juu')
    console.log(arr)
    
    const ultimo = arr.pop()
    console.log(ultimo)
    const primeiro = arr.shift()
    console.log(primeiro)
    console.log(arr.includes('Carol'))
    const indice = arr.indexOf('Samalla')
    console.log(indice)
    
    const slice = arr.slice(0,3)
    console.log(slice)
}

const movies = ['Star Wars', 'Gente Grande', 'Amizade Colorida', 'Palm Springs']
const series = ['How i met your mother', 'Friends', 'Big Bang theory', 'Vikings']

console.log(movies)
console.log(series)

const love = series.concat(movies, 'Supernatural')
console.log(love)

const indice = love.indexOf('Supernatural')

const elementosRemovidos = love.splice(indice, 1, 'The ranch')
console.log(love)
console.log(elementosRemovidos)

/* Iterar sobre elementos */

for(let indice = 0; indice < love.length; indice++){
    const elemento = love[indice]
    console.log(elemento + ' se encontra na posição ' + indice)
}