### Curso de programação full stack - OneBitCode

[Clique aqui para ver todas as minhas anotações durante o curso](https://mature-basil-76a.notion.site/OneBitCode-ad8e80ca425a40fd9fb074efe361f21d?pvs=4)