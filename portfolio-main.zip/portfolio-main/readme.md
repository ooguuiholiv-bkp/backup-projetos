# Atenção, você finalmente dicidiu que iria levar a sério essa parada, então não vacila mais.

# Lista To Do
- [x] Criar Header
    - [x] Atualizar Header
- [x] Criar Pagina Sobre
- [] Criar página de Portfólio -> redirecionando para o github do projeto
- [] Criar página de Contatos
- [] Criar Footer

- finalizado - criarei outro com nextjs