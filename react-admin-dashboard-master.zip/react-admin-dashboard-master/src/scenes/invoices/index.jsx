import { Box, useTheme } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { tokens } from "../../theme";
// import { mockDataInvoices } from "../../data/mockData";

import Header from "../../components/Header";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import { useState } from "react";
import { useEffect } from "react";

const Invoices = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    { field: "id", headerName: "ID" },
    {
      field: "ns",
      headerName: "NS",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    {
      field: "client",
      headerName: "Cliente",
      flex: 2,
    },
    {
      field: "cnpj",
      headerName: "CNPJ",
      flex: 1,
    },
    // {
    //   field: "cost",
    //   headerName: "Cost",
    //   flex: 1,
    //   renderCell: (params) => (
    //     <Typography color={colors.greenAccent[500]}>
    //       ${params.row.cost}
    //     </Typography>
    //   ),
    // },
    // {
    //   field: "data_inicio",
    //   headerName: "Inicio",
    //   flex: 1,
    // },
  ];
  const [ns, setNs] = useState([])
  useEffect(() => {
    api.get('/ns', config).then(response => {
      setNs(response.data)
    }).catch(error => console.log(error))
  },[])

  return (
    <Box m="20px">
      <Header title="Consulta de NS" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
        }}
      >
        <DataGrid checkboxSelection rows={ns} columns={columns} />
      </Box>
    </Box>
  );
};


export default Invoices;
