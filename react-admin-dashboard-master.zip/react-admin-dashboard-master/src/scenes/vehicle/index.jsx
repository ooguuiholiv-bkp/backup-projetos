import { Box, Button, TextField } from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import Header from "../../components/Header";
import api from "../../services/api";
import { config } from "../../services/authenticated";


const VehicleCreateForm = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");

  const handleFormSubmit = (values) => {
    api
      .post("/vehicle", values, config)
      .then(() => {
        alert("Veículo cadastrado com sucesso!")
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <Box m="20px">
      <Header title=" Veículos" subtitle="Criar um novo veículo" />

      <Formik
        onSubmit={handleFormSubmit}
        initialValues={initialValues}
        validationSchema={checkoutSchema}
      >
        {({
          values,
          errors,
          touched,
          handleBlur,
          handleChange,
          handleSubmit,
        }) => (
          <form onSubmit={handleSubmit}>
            <Box
              display="grid"
              gap="30px"
              gridTemplateColumns="repeat(4, minmax(0, 1fr))"
              sx={{
                "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
              }}
            >
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Marca"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.marca}
                name="marca"
                id="marca"
                error={!!touched.marca && !!errors.marca}
                helperText={touched.marca && errors.marca}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Placa"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.placa}
                name="placa"
                id="placa"
                error={!!touched.placa && !!errors.placa}
                helperText={touched.placa && errors.placa}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="number"
                label="KM"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.km}
                name="km"
                id="km"
                error={!!touched.km && !!errors.km}
                helperText={touched.km && errors.km}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Frota"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.frota}
                name="frota"
                id="frota"
                error={!!touched.frota && !!errors.frota}
                helperText={touched.frota && errors.frota}
                sx={{ gridColumn: "span 2" }}
              />
            </Box>
            <Box display="flex" justifyContent="end" mt="20px">
              <Button type="submit" color="secondary" variant="contained">
                Criar Veículo
              </Button>
            </Box>
          </form>
        )}
      </Formik>
    </Box>
  );
};
const checkoutSchema = yup.object().shape({
  marca: yup.string().required("Campo Obrigatório"),
  placa: yup.string().required("Campo Obrigatório"),
  frota: yup.string().required("Campo Obrigatório"),
});
const initialValues = {
  marca: "",
  placa: "",
  km: "",
  frota: "",
};

export default VehicleCreateForm;
