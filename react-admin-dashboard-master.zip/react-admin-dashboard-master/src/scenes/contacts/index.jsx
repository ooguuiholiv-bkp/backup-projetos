import { Box } from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
// import { mockDataContacts } from "../../data/mockData";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import { useEffect, useState } from "react";
// import api from "../../services/api";
// import { config } from "../../services/authenticated";

const Contacts = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const columns = [
    { field: "id", headerName: "ID", flex: 0.5 },
    // { field: "registrarId", headerName: "ID" },
    {
      field: "name",
      headerName: "Nome",
      flex: 1,
      cellClassName: "name-column--cell",
    },

    {
      field: "cpf",
      headerName: "CPF / CNPJ",
      flex: 1,
    },
    {
      field: "email",
      headerName: "Email",
      flex: 1,
    },
    {
      field: "typeUser",
      headerName: "Permissões",
      flex: 1,
    },
    // {
    //   field: "is_client",
    //   headerName: "Cliente",
    //   flex: 1,
    // },
    // {
    //   field: "is_employee",
    //   headerName: "Funcionário",
    //   flex: 1,
    // },
  ];

  const [users, setUsers] = useState([])

  useEffect(() => {
    api.get('/user',config).then(response => {
      let usuarios = response.data;
      let dataUser = usuarios.map(user => {
         if(user.typeUser === 1){
          user.typeUser = "Admin"
        }
         if(user.typeUser === 2){
          user.typeUser = "Editor"
        }
         if(user.typeUser === 3){
          user.typeUser = "Cliente"
        }
        return {
          name: user.name,
          email: user.email,
          cpf: user.cpf,
          id: user.id,
          typeUser: user.typeUser
        }
      })
      
      setUsers(dataUser)
    }).catch(error => console.log(error))
  },[])
  
  return (
    <Box m="20px">
      <Header title="Informações de Usuários" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <DataGrid
          rows={users}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
        />
      </Box>
    </Box>
  );
};

export default Contacts;
