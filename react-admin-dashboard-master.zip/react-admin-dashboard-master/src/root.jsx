import { createBrowserRouter } from "react-router-dom";
import { Login } from "./pages/login";
import App from "./App";
import { PrivateRoute } from "./PrivateRoutes";

export const rotas = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/forgot",
    element: <App />,
  },
  {
    path: "*",
    element: (
      <PrivateRoute>
        <App />
      </PrivateRoute>
    ),
  },
]);
