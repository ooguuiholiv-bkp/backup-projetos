import React from "react";
import { Navigate } from "react-router-dom";
import { config } from "./services/authenticated";
import api from "./services/api.js";
export const PrivateRoute = ({ children }) => {
  const user = window.localStorage.getItem("token");
  return user ? children : <Navigate to="/login" />;
};
