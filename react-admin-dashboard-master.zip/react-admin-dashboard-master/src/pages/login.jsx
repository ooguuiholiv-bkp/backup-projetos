import React from "react";
import styled from "styled-components";
import Logo from "../assets/logo.png";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

import api from "../services/api";
import { Button, TextField } from "@mui/material";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #141b2d;
    .content {
      width: 25vw;
      height: 65vh;
      background: #f2f2f2;
      border-radius: 0.2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      .logo-img {
        width: 15vw;
      }
      form {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 0.8rem;
      }
    }
  }
`;

export const Login = () => {
  const loginData = (data) => api.post('/auth', data).then((res) => {
    localStorage.setItem('nome', res.data.user.name)
    localStorage.setItem('token', res.data.accessToken)
    window.location.href = '/'
    console.log(res)
  }).catch(err => {
    console.log(err)
  })

  const checkForm = yup.object().shape({
    email: yup.string().required("Campo Obrigatório"),
    password: yup.string().required("Campo Obrigatório"),
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(checkForm),
  });
  return (
    <Container>
      <div className="content">
        <img src={Logo} className="logo-img" alt="" />
        <form onSubmit={handleSubmit(loginData)}>
          <TextField
            variant="outlined"
            type="email"
            label="Email"
            name="email"
            id="email"
            {...register("email")}
          />
          <p>{errors.email?.message}</p>
          <TextField
            variant="outlined"
            type="password"
            label="password"
            name="password"
            id="password"
            {...register("password")}
          />
          <p>{errors.password?.message}</p>
          <Link to="/forgot">
            <p>Esqueci minha senha</p>
          </Link>
          <Button type="submit" variant="contained" color="success">
            Entrar
          </Button>
        </form>
      </div>
    </Container>
  );
};
