

import Footer from "../../components/Main/Footer/Footer";
import Header from "../../components/Main/Header/Header";
// import Main from "../../components/Main/MainContent/Maincontent";
import Sidebar from "../../components/Main/Sidebar/Sidebar";


function Home (){
  return(
    <>
    <Header />
    <Sidebar />
    {/* <Main /> */}
    <Footer />
    </>
  )
}

export default Home;