import styled from 'styled-components';

export const Container = styled.div`
  height: 83vh;
  width: 15vw;
  background-color: #8C1F28;
`;
