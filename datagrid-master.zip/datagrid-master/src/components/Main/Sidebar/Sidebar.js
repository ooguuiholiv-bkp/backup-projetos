import React from "react";
import Main from "../MainContent/Maincontent";
import { Container } from "./Styles";


function Sidebar(){
  return(
    <Container>
      <Main />
    </Container>
  )
}
export default Sidebar;