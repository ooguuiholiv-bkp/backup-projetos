import React, { useEffect, useState, useMemo } from "react";
import { Header, Pagination, Search } from "../../Datagrid";
import { Container } from "./Styles";
import useFullPageLoader from "../../../hooks/useFullPageLoader";
import "../../../../node_modules/bootstrap/scss/bootstrap.scss";

const DataTable = () => {
  const [users, setUsers] = useState([]);
  const [loader, showLoader, hideLoader] = useFullPageLoader();
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState("");
  const [sorting, setSorting] = useState({ field: "", order: "" });

  const ITEMS_PER_PAGE = 4;

  const headers = [
    { name: "nº", field: "id", sortable: false },
    { name: "nome", field: "name", sortable: true },
    { name: "username", field: "username", sortable: true },
    { name: "email", field: "email", sortable: true },
  ];

  useEffect(() => {
    const getData = () => {
      showLoader();

      fetch("https://jsonplaceholder.typicode.com/users")
        .then((response) => response.json())
        .then((json) => {
          hideLoader();
          setUsers(json);
        });
    };
    getData();
  }, []);

  const usersData = useMemo(() => {
    let computedUsers = users;

    if (search) {
      computedUsers = computedUsers.filter(
        (usuario) =>
          usuario.name.toLowerCase().includes(search.toLowerCase()) ||
          usuario.email.toLowerCase().includes(search.toLowerCase()) ||
          usuario.username.toLowerCase().includes(search.toLowerCase())
      );
    }
    setTotalItems(computedUsers.length);

    // sorting users
    if (sorting.field) {
      const reversed = sorting.order === "asc" ? 1 : -1;
      computedUsers = computedUsers.sort(
        (a, b) => reversed * a[sorting.field].localeCompare(b[sorting.field])
      );
    }

    // currente page slice
    return computedUsers.slice(
      (currentPage - 1) * ITEMS_PER_PAGE,
      (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
    );
  }, [users, currentPage, search, sorting]);

  return (
    <Container>
      <div className="card">
        <div className="row w-100">
          <div className="col mb-3 col-12 text-center">
            <div className="row">
              <div className="col-md-6">
                <Pagination
                  total={totalItems}
                  itemsPerPage={ITEMS_PER_PAGE}
                  currentPage={currentPage}
                  onPageChange={(page) => setCurrentPage(page)}
                />
              </div>
              <div className="col-md-6 d-flex flex-row-reverse">
                <Search
                  onSearch={(value) => {
                    setSearch(value);
                    setCurrentPage(1);
                  }}
                />
              </div>
            </div>

            <table className="table table-striped">
              <Header
                headers={headers}
                onSorting={(field, order) => setSorting({ field, order })}
              />
              <tbody>
                {usersData.map((user) => (
                  <tr>
                    <th scope="row" key={user.id}>
                      {user.id.toString()}
                    </th>
                    <td>{user.name}</td>
                    <td>{user.username}</td>
                    <td>{user.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        {loader}
      </div>
    </Container>
  );
};

// function Main() {
//   return (
//     <Container>
//       <div className="card"></div>
//     </Container>
//   );
// }

export default DataTable;
