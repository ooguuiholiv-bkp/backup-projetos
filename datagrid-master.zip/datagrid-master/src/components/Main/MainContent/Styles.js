import styled from "styled-components";

export const Container = styled.div`
  width: 85vw;
  height: 85vh;
  background-color: #f2f2f2;
  margin-left: 15vw;
  display: flex;
  justify-content: center;
  align-items: center;
  .card {
    background-color: rgba(4,64,64,0.8);
    width: 80vw;
    height: 75vh;
    border-radius: 1rem;
    display: flex;
    justify-content: center;
    align-items: center;
    position: fixed;
  }
  
`;
