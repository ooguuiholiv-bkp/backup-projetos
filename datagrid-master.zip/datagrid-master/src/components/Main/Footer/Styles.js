import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  height: 7vh;
  background-color: #8C1F28;
  display: flex;
  justify-content: center;
  align-items: center;
  
  .Copy{
    font-weight: bold;
    color: #F2F2F2;
    cursor: default;
  }
`;
