import React from "react";
import { Container } from "./Styles";

function Footer (){
  return(
    <Container>
      <p className="Copy">&copy; Guilherme Oliveira 2022</p>
    </Container>
  )
}
export default Footer;