import React from "react";
import { Container } from "./Styles";

function Header (){
  return(
    <Container>
      
    </Container>
  )
}

export default Header;