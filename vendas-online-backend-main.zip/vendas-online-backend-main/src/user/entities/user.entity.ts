export interface UserEntity {
  id: number;
  name: string;
  email: string;
  phone: string;
  cpf: string;
  password: string;
}
