import {Login} from '../src/Pages/Login/index'

function App() {

  return (
    <div className="App">
      <Login>
        

      </Login>
      
    </div>
  )
}

export default App
