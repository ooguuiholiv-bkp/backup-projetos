import React from 'react';
import { SignIn } from './Pages/SignIn/LoginPage';

function App() {
  return (
      <SignIn />
  );
}

export default App;
