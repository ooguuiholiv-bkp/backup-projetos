interface IProps {
  id: string;
  className: string;
  text: string;
}

export const TextAll = (props: IProps) => {
  const {id, className, text} = props;
  return(
    <p id={id} className={className}>{text}</p>
  )
}