import styled from "styled-components";
import SplashImg from "../assets/splash.png";
import LogoImg from "../assets/logo.png"

export const LayoutBoxSplash = styled.img`
background-image: url(${SplashImg});
width: 100%;
max-width: 600px;

`;
export const LayoutBoxLogo = styled.img`
@import url(${LogoImg});

`;




