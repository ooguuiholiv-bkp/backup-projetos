interface IProps {
  id: string;
  className: string;
  placeholder: string;
  type: string;
}


export const Input = (props: IProps) => {
  const {id, className, placeholder, type} = props;
  return(
    <div>
      <input type={type} id={id} className={className} placeholder={placeholder}></input>
    </div>
  )
}
