interface IProps {
  href: string;
  id: string;
  className: string;
  text: string;

}

export const Hiperlink = (props: IProps) => {
  const {href, id, className, text} = props;
  return(
    <div>
      <a id={id} className={className} href={href}>{text}</a>
    </div>
  )
}