import React, { MouseEventHandler } from "react";

interface IProps {
  id: string;
  className: string;
  onclick: MouseEventHandler;
  text: string;
}

export const Button = (props: IProps) => {
  const {id, className, onclick, text} = props;
  return(
    <div>
      <button id={id} className={className} onClick={onclick}>{text}</button>
    </div>
  )
}