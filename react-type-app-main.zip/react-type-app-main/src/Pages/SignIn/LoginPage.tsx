import React from "react";
// Importando folha de estilos
import "./styles.css";

// Importando meus componentes
import { Input } from "../../components/Input";
import { Button } from "../../components/Button";
import { TextAll } from "../../components/Text";
import { Hiperlink } from "../../components/Hiperlink";
// Importando meus estilos
import { Container } from "./styles";
// Importando imagens necessárias
// import SplashImg from "../../assets/splash.png";
// import LogoImg from "../../assets/logo.png";
import SplashImg from "../../assets/splash2.png";
import LogoImg from "../../assets/logo2.png";



export const SignIn: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash img" className="SplashImg" />
        <img src={LogoImg} alt="LogoImg" className="LogoImg" />
        <TextAll id="loginTxt" className="loginTxt" text="Informe suas credenciais de acesso" />
        <Input type="text" id="email" className="emailLogin" placeholder="Usuário / e-Mail" />
        <Input type="pass" id="password" className="passLogin" placeholder="Senha" />
        <Hiperlink id="hiperLogin" className="hiperLogin" href="#" text="Esqueci minha senha" />
        <Button text="Entrar" id="button" className="btnLogin" onclick={() => { alert("Entrou") }} />
      </Container>
    </div>

  )
}