import { createGlobalStyle, GlobalStyleComponent } from "styled-components";

export const Base = createGlobalStyle`
html, body{
  background-color: #F7972E;

}
`;