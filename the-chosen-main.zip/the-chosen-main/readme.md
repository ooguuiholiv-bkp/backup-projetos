## The Chosen - Os escolhidos..
#### Esta página foi criada como uma forma de apresentar meus conhecimentos em html css e js...

[] - Crie a estrutura padrão html...

[] - Depois crie um nav adicionando a ele uma posição fixa, dando tambem um tamanho maximo de 240px;

[] - Dentro do seu nav crie todos os botões necessários para transporte de página

[] - comece a estilizar...