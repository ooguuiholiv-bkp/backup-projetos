import React from "react";
import styled from "styled-components";

export const FooterContainer = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  font-family:"Roboto",san-serif;
  font-size: 0.9rem;
  width: 100vw;
  height: 8vh;
  display: flex;
  background: linear-gradient(
    275.76deg,
    #ffbb00 34.11%,
    rgba(28, 28, 28, 0.75) 313.31%
  );
  position: fixed;
  bottom: 0;
  justify-content: center;
  text-align: center;
  align-items: center;
`;

export const FooterLayout = () => {
  return (
    <FooterContainer>
      <div className="info">
        <p>
          Av. Paranaíba. 2783 - Marta Helena - CEP: 38.307-160 - Ituiutaba MG <br />
          (34) 3271-7700 - e-mail: part@mbaconstrutora.com.br
        </p>
      </div>
    </FooterContainer>
  );
};
