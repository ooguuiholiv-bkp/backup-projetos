import React from "react";
import styled from "styled-components";
import Logo from "../../assets/img/logo.png";
import User from "../../assets/img/user.jpg";

export const HeaderContainer = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  font-family: "Roboto", sans-serif;
  width: 100vw;
  height: 10vh;
  display: flex;
  background: linear-gradient(
    275.76deg,
    #ffbb00 34.11%,
    rgba(28, 28, 28, 0.75) 313.31%
  );
  position: fixed;
  top: 0;
  justify-content: space-between;

  .info {
    width: 45%;
    height: 100%;
    margin-left: 5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;

    .logo {
      width: 20%;
      img {
        width: 100%;
      }
    }
    .infoEmpresa {
    }
  }
  .users {
    display: flex;
    align-items: center;
    width: 15%;
    height: 100%;
    gap: 0.5rem;

    img {
      width: 4.5vw;
      border-radius: 50%;
    }
  }
`;

export const HeaderLayout = () => {
  return (
    <HeaderContainer>
      <div className="info">
        <div className="logo">
          <img src={Logo} alt="" />
        </div>
        <div className="infoEmpresa">
          <p>CNPJ: 05.578.215/0001-14</p>
          <p>I.E: 342.225.390.00.14</p>
        </div>
      </div>
      <div className="users">
        <p>
          Seja bem vindo, <br /> Nome do usuário
        </p>
        <img src={User} alt="" />
      </div>
    </HeaderContainer>
  );
};
