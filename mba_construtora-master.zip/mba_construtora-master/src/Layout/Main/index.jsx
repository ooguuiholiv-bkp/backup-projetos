import React from 'react';
import styled from 'styled-components';

export const MainContainer = styled.div`
    width: 100vw;
    height: 82vh;
    display: flex;
    position: fixed;
    margin-top: 10vh;
    background: #FFF;
  
`;
export const MainLayout = ({children}) => {
    return(
        <MainContainer>
            {children}
        </MainContainer>
    )
}