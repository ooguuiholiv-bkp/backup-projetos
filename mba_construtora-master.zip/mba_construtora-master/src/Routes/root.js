import { createBrowserRouter } from "react-router-dom";
import React from "react";
import { Home } from "../Pages/Institucional";
import { Login } from "../Pages/Login";
import { IntranetHome } from "../Pages/Intranet/Home";
import { Login2 } from "../Pages/Login2";
import { Forgot } from "../Pages/Forgot";
import { UserCreate } from "../Components/User";


export const router = createBrowserRouter([
    {
      path: "/",
      element: <IntranetHome />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: '/log',
      element: <Login2 />
    },
    {
      path: '/forgot',
      element: <Forgot />
    },
    {
      path: "/intranet",
      element: <IntranetHome />,
    },
    {
      path: "/user",
      element: <UserCreate />,
    },
  ]);