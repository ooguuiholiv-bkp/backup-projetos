import React from "react";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import * as RiIcons from "react-icons/ri";


export const SideData = [
    {
        title: 'Pagina Inicial',
        path: '/',
        icon: <FaIcons.FaDesktop />,
    },
    {
      title: "Dashboard",
      path: "#",
      icon: <AiIcons.AiOutlineFolder />,
      iconClosed: <RiIcons.RiArrowDownSFill />,
      iconOpened: <RiIcons.RiArrowUpSFill />,
      subNav: [
        {
          title: "Usuarios",
          path: "/user",
          icon: <FaIcons.FaRegBuilding />,
        },
        {
          title: "Cliente",
          path: "/cliente",
          icon: <AiIcons.AiOutlineCopyright />,
        },
        {
          title: "NS",
          path: "/NS",
          icon: <AiIcons.AiOutlineIdcard />,
        },
        {
          title: "Frotas",
          path: "/veiculo",
          icon: <FaIcons.FaCarAlt />,
        },
        {
          title: "Equipe",
          path: "/equipe",
          icon: <FaIcons.FaCarAlt />,
        },
      ],
    },
    {
        title: "Cadastros",
        path: "#",
        icon: <AiIcons.AiOutlineFolder />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: "Usuarios",
            path: "/user",
            icon: <FaIcons.FaRegBuilding />,
          },
          {
            title: "Cliente",
            path: "/cliente",
            icon: <AiIcons.AiOutlineCopyright />,
          },
          {
            title: "NS",
            path: "/NS",
            icon: <AiIcons.AiOutlineIdcard />,
          },
          {
            title: "Frotas",
            path: "/veiculo",
            icon: <FaIcons.FaCarAlt />,
          },
          {
            title: "Equipe",
            path: "/equipe",
            icon: <FaIcons.FaCarAlt />,
          },
        ],
      },
]