import React from "react";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import styled from "styled-components";
import { IntranetContainer } from "../Pages/Intranet/Home";
import { HeaderLayout } from "../Layout/Header";
import { MainLayout } from "../Layout/Main";
import { FooterLayout } from "../Layout/Footer";
import Sidebar from "../Layout/Sidebar";
import { axios } from 'axios';

export const UserContainer = styled.div`
  width: 100vw;
  height: 82vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: white;
  .content {
    width: 65%;
    height: 90%;
    display: flex;
    flex-direction: column;
    align-items: center;
    border-radius: 0.4rem;
    background: #cecece;

    .titlePage {
      margin-top: 0.4rem;
      text-align: center;
      font-size: 1.7rem;
    }
    hr {
      border: 1px solid black;
    }
    form {
      margin-top: 1.2rem;
      width: 90%;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      justify-content: start;

      button {
        font-family: "Roboto", sans-serif;
        align-content: center;
        width: 20vw;
        margin-left: auto;
        margin-right: auto;
      }

      .form-group {
        width: 45%;
      }
    }
  }
`;
export const UserCreate = () => {
  return (
    <IntranetContainer>
      <HeaderLayout />
      <MainLayout>
        <UserContainer>
          <div className="content">
            <div
              className="card"
              style={{
                width: "100%",
                borderBottom: "none",
                background: "#373737",
                color: "#f2f2f2",
              }}
            >
              <div
                className="card-header"
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "center",
                  fontSize: "1.6rem",
                  fontFamily: "Roboto, sans-serif",
                  border: "none",
                }}
              >
                Cadastro de Usuários
              </div>
            </div>
            <form>
              <div className="form-group">
                <input
                  type="email"
                  className="form-control"
                  id="inputEmail"
                  aria-describedby="emailHelp"
                  placeholder="Seu email"
                />
              </div>
              <div className="form-group">
                <input
                  type="password"
                  className="form-control"
                  id="exampleInputPassword1"
                  placeholder="Senha"
                />
              </div>
              {/* <div className="form-group">
                <input
                  type="user"
                  className="form-control"
                  id="userId"
                  placeholder="Nome de usuário"
                />
              </div> */}
              <div class="input-group form-group">
                <div class="input-group-prepend">
                  <div class="input-group-text" style={{border: 'none'}}>@</div>
                </div>
                <input
                  type="text"
                  class="form-control"
                  id="inlineFormInputGroupUsername"
                  placeholder="Usuário"
                  style={{border: "none"}}
                />
              </div>
              <div
                className="form-group form-check"
                style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}
              >
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="checkClient"
                />
                <label className="form-check-label" for="checkClient">
                  É cliente?
                </label>
              </div>

              <button type="submit" className="btn btn-primary">
                Enviar
              </button>
            </form>
          </div>
        </UserContainer>
      </MainLayout>
      <FooterLayout />
      <Sidebar />
    </IntranetContainer>
  );
};
