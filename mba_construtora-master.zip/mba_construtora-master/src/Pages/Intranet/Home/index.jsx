import React from "react";
import styled from "styled-components";
import { HeaderLayout } from "../../../Layout/Header";
import { FooterLayout } from "../../../Layout/Footer";
import { MainLayout } from "../../../Layout/Main";
import Sidebar from "../../../Layout/Sidebar";
import Search from "../../../assets/svg/search.svg";



export const IntranetContainer = styled.div`
  width: 100vw;
  height: 100vh;
  .mainContent {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: space-around;

    .search {
      display: flex;
      align-items: center;
      height: 30%;
      
      form {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.2rem;
        input {
          width: 20vw;
          height: 5vh;
          border-radius: 0.2rem;
          border: none;
          background: #ccc;
          color: black;
        }
        button {
          width: 5vw;
          height: 5vh;
          border: none;
          background: transparent;
          border-radius: 0.2rem;
          cursor: pointer;

          img {
            width: 50%;
          }
        }
      }
    }
  }
`;

export const IntranetHome = () => {
  return (
    <IntranetContainer>
      <HeaderLayout />
      <MainLayout>
        <div className="mainContent">
          <div className="search">
            <form action="">
              <input type="text" placeholder="Digite o número de NS" />
              <button>
                <img src={Search} alt="lupa" />
              </button>
            </form>
          </div>
        </div>
      </MainLayout>
      <FooterLayout />
      <Sidebar />
    </IntranetContainer>
  );
};
