import React from "react";
import styled from "styled-components";

export const Container = styled.div`
@import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  @media screen and (min-width: 1024px) {
    width: 100vw;
    height: 100vh;
    background: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    overflow: hidden;

    .header {
      width: 100%;
      height: 8vh;
      background: linear-gradient(
      275.76deg,
      #ffbb00 34.11%,
      rgba(28, 28, 28, 0.75) 313.31%
    );
      position: fixed;
      top: 0;
    }
    .content {
      width: 30%;
      height: 60%;
      background: #f2f2f2;
      border-radius: 0.5rem;
      box-shadow: 7px 7px 2px -3px rgba(0, 0, 0, 0.75);

      h1{
        margin: 1rem;
        font-size: 1.5rem;
        font-family: "Roboto", sans-serif;
      }
      .form{
        height: 75%;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        align-items: center;
        justify-content: center;

        input{
          width: 75%;
          height: 9%;
          border: none;
          border-radius: 0.3rem;
        }
        button {
          width: 40%;
          height: 9%;
          border-radius: 0.5rem;
          border: none;
          background: #1ed761;
        }
      }
    }

    .footer {
      width: 100%;
      height: 8vh;
      background: linear-gradient(
      275.76deg,
      #ffbb00 34.11%,
      rgba(28, 28, 28, 0.75) 313.31%
    );
      position: fixed;
      bottom: 0;
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px){
    width: 100vw;
  height: 100vh;
  background: #fff;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  overflow: hidden;

  .header{
    width: 100%;
    height: 8vh;
    background: yellow;
    position: fixed;
    top: 0;
  }
  .content{
    width: 70%;
    height: 60%;
    background: #f2f2f2;
    border-radius: 0.5rem;
    box-shadow: 7px 7px 2px -3px rgba(0,0,0,0.75);
  }

  .footer{
    width: 100%;
    height: 8vh;
    background: yellow;
    position: fixed;
    bottom: 0;
  }
  }
  @media screen and (max-width:767px){
    width: 100vw;
  height: 100vh;
  background: #fff;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  overflow: hidden;

  .header{
    width: 100%;
    height: 8vh;
    background: yellow;
    position: fixed;
    top: 0;
  }
  .content{
    width: 85%;
    height: 60%;
    background: #f2f2f2;
    border-radius: 0.5rem;
    box-shadow: 7px 7px 2px -3px rgba(0,0,0,0.75);
    
  }

  .footer{
    width: 100%;
    height: 8vh;
    background: yellow;
    position: fixed;
    bottom: 0;
  }
  }
`;

export const Login = () => {
  return (
    <Container>
      <div className="header"></div>
      <div className="content">
        <h1>Credenciais de acesso</h1>
        <hr />
        <form action="" className="form">
          <input type="text" placeholder="User" id="user"/>
          <input type="password" placeholder="Password" id="password"/>
          <button>Login</button>
        </form>
      </div>
      <div className="footer"></div>
    </Container>
  );
};
