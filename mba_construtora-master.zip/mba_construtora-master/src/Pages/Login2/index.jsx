import React from "react";
import styled from "styled-components";
import Splash from "../../assets/img/splash.png";
import { Link } from "react-router-dom";
import Logo from "../../assets/img/logo.png";
import axios from "axios";
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";

export const IntranetContainer = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  @media screen and (min-width: 1024px) {
    width: 100vw;
    height: 100vh;
    background-color: #f2f2f2;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    .container {
      display: flex;
      flex-direction: row;
      width: 40%;
      height: 75%;
      background-color: #ffffff;
      border-radius: 1.4rem;
      margin: 0;
      padding: 0;

      /* .splash {
      visibility: hidden;
      width: 50%;
      height: 100%;
      background: url(${Splash});
      background-size: cover;
      border-top-left-radius: inherit;
      border-bottom-left-radius: inherit;
    } */

      .content {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;

        .logo {
          width: 50%;
          display: flex;
          justify-content: center;
          margin-top: 1rem;
          img {
            width: 75%;
          }
        }
        .info {
          margin-top: 1rem;
          p {
            text-transform: uppercase;
            font-family: "Roboto", sans-serif;
            font-size: 0.8rem;
            color: #1c1c1c;
          }
        }
        .LoginForm {
          margin-top: 3rem;
          .form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.8rem;
            input {
              width: 25vw;
              height: 5vh;
              border-radius: 0.3rem;
              border: none;
              background-color: #f2f2f2;
            }
            p {
              position: relative;
              text-transform: uppercase;
              font-size: 0.7rem;
              font-family: "Roboto", sans-serif;
            }
            .btn-warning {
              width: 20vw;
              height: 5vh;
              border-radius: 0.3rem;
              color: #fff;
              border: none;
            }
          }
        }
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100vw;
    height: 100vh;
    background-color: #f2f2f2;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    .container {
      display: flex;
      flex-direction: row;
      width: 40%;
      height: 75%;
      background-color: #ffffff;
      border-radius: 1.4rem;
      margin: 0;
      padding: 0;

      /* .splash {
      visibility: hidden;
      width: 50%;
      height: 100%;
      background: url(${Splash});
      background-size: cover;
      border-top-left-radius: inherit;
      border-bottom-left-radius: inherit;
    } */

      .content {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;

        .logo {
          width: 50%;
          display: flex;
          justify-content: center;
          margin-top: 1rem;
          img {
            width: 75%;
          }
        }
        .info {
          margin-top: 1rem;
          p {
            text-transform: uppercase;
            font-family: "Roboto", sans-serif;
            font-size: 0.8rem;
            color: #1c1c1c;
          }
        }
        .LoginForm {
          margin-top: 3rem;
          .form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.8rem;
            input {
              width: 25vw;
              height: 5vh;
              border-radius: 0.3rem;
              border: none;
              background-color: #f2f2f2;
            }
            p {
              position: relative;
              text-transform: uppercase;
              font-size: 0.7rem;
              font-family: "Roboto", sans-serif;
            }
            .btn-warning {
              width: 20vw;
              height: 5vh;
              border-radius: 0.3rem;
              color: #fff;
              border: none;
            }
          }
        }
      }
    }
  }
  @media screen and (max-width: 767px) {
    width: 100vw;
    height: 100vh;
    background-color: #f2f2f2;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    .container {
      display: flex;
      flex-direction: row;
      width: auto;
      height: auto;
      background-color: #ffffff;
      border-radius: 1rem;
      margin: 0;
      padding: 0;

      /* .splash {
      visibility: hidden;
      width: 50%;
      height: 100%;
      background: url(${Splash});
      background-size: cover;
      border-top-left-radius: inherit;
      border-bottom-left-radius: inherit;
    } */

      .content {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;

        .logo {
          width: 75%;
          display: flex;
          justify-content: center;
          margin-top: 1rem;
          img {
            width: 75%;
          }
        }
        .info {
          margin-top: 1rem;
          p {
            text-transform: uppercase;
            text-align: center;
            font-family: "Roboto", sans-serif;
            font-size: 0.8rem;
            color: #1c1c1c;
          }
        }
        .LoginForm {
          margin-top: 3rem;
          .form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.8rem;
            input {
              width: auto;
              height: 5vh;
              border-radius: 0.2rem;
              border: none;
              background-color: #f2f2f2;
            }
            p {
              position: relative;
              text-transform: uppercase;
              font-size: 0.7rem;
              text-align: center;
              font-family: "Roboto", sans-serif;
            }
            .btn-warning {
              width: auto;
              height: 5vh;
              border-radius: 0.3rem;
              color: #fff;
              border: none;
              margin-bottom: 3rem;
            }
          }
        }
      }
    }
  }
`;

export const Login2 = () => {
  return (
    <IntranetContainer>
      <div className="container">
        <div className="splash"></div>
        <div className="content">
          <div className="logo">
            <img src={Logo} alt="" />
          </div>
          <div className="info">
            <p>informe suas credenciais de acesso!</p>
          </div>
          <div className="LoginForm">
            <form className="form">
              <input type="text" placeholder="Usuario" id="user" />
              <input
                type="password"
                placeholder="Senha"
                id="password"
                autoComplete="none"
              />
              <p>
                <Link to="/forgot" className="infoForgot">
                  esqueci minha senha
                </Link>
              </p>
              <button
                className="btn btn-warning"
                onClick={() => {
                  var userField = document.querySelector("#user");
                  var passwordField = document.querySelector("#password");

                  var user = userField.value;
                  var password = passwordField.value;

                  axios
                    .post("http://localhost:7777/auth", {
                      user,
                      password,
                    })
                    .then((res) => {
                      var token = res.data.token;
                      localStorage.setItem("token", token, "user", user);
                      window.location.href = "/int";
                    })
                    .catch((err) => {
                      console.log(err);
                      alert("error");
                    });
                }}
              >
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
    </IntranetContainer>
  );
};
