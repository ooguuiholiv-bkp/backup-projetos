import {
  Box,
  Button,
  Select,
  TextField,
  MenuItem,
  NativeSelect,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import Header from "../../components/Header";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import { useEffect, useState } from "react";
import InputMask from "react-input-mask";

const NsCreateForm = () => {
  const [clients, setClients] = useState([]);

  useEffect(() => {
    api
      .get("/user/c")
      .then((res) => {
        let clientes = res.data;
        setClients(clientes);
      })
      .catch();
  }, []);
  
  

  const isNonMobile = useMediaQuery("(min-width:600px)");

  const handleFormSubmit = (values) => {
    api
      .post("/ns", values, config)
      .then(() => {
        alert("NS cadastrada com sucesso");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <Box m="20px">
      <Header title=" NS" subtitle="Cadastro de NS" />

      <Formik
        onSubmit={handleFormSubmit}
        initialValues={initialValues}
        validationSchema={checkoutSchema}
      >
        {({
          values,
          errors,
          touched,
          handleBlur,
          handleChange,
          handleSubmit,
        }) => (
          <form onSubmit={handleSubmit}>
            <Box
              display="grid"
              gap="30px"
              gridTemplateColumns="repeat(4, minmax(0, 1fr))"
              sx={{
                "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
              }}
            >
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="NS"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.ns}
                name="ns"
                id="ns"
                error={!!touched.ns && !!errors.ns}
                helperText={touched.ns && errors.ns}
                sx={{ gridColumn: "span 2" }}
                inputProps={{maxLength: 10}}
              />
              <Select
                variant="filled"
                labelId="label-cliente"
                label="Cliente"
                id="client"
                name="client"
                sx={{ gridColumn: "span 2" }}
                onBlur={handleBlur}
                onChange={handleChange}
                error={!!touched.ns && !!errors.ns}
                helperText={touched.client && errors.client}
              >
                {clients.map((c, index) => (
                  <MenuItem key={index} value={c.name}>
                    {c.name}
                  </MenuItem>
                ))}
              </Select>

              {/* <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Cliente"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.cliente}
                name="cliente"
                id="cliente"
                error={!!touched.cliente && !!errors.cliente}
                helperText={touched.cliente && errors.cliente}
                sx={{ gridColumn: "span 2" }}
              /> */}
              <InputMask
                mask="99.999.999/9999-99"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.cnpj}
              >
                {() => (
                  <TextField
                    fullWidth
                    variant="filled"
                    type="text"
                    label="CNPJ"
                    onBlur={handleBlur}
                    onChange={handleChange}
                    value={values.cnpj}
                    name="cnpj"
                    id="cnpj"
                    error={!!touched.cnpj && !!errors.cnpj}
                    helperText={touched.cnpj && errors.cnpj}
                    sx={{ gridColumn: "span 2" }}
                  />
                )}
              </InputMask>

              

              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Cidade"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.city}
                name="city"
                id="city"
                error={!!touched.city && !!errors.city}
                helperText={touched.city && errors.city}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Nome da Obra"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.nameobra}
                name="nameobra"
                id="nameobra"
                error={!!touched.nameobra && !!errors.nameobra}
                helperText={touched.nameobra && errors.nameobra}
                sx={{ gridColumn: "span 2" }}
              />
              {/*<TextField
                fullWidth
                variant="filled"
                type="text"
                label="Tipo"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.tipo}
                name="tipo"
                id="tipo"
                error={!!touched.tipo && !!errors.tipo}
                helperText={touched.tipo && errors.tipo}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Data de Inicio"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.data_inicio}
                name="data_inicio"
                id="data_inicio"
                error={!!touched.data_inicio && !!errors.data_inicio}
                helperText={touched.data_inicio && errors.data_inicio}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Data de Término"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.data_final}
                name="data_final"
                id="data_final"
                error={!!touched.data_final && !!errors.data_final}
                helperText={touched.data_final && errors.data_final}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Situação"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.situacao}
                name="situacao"
                id="situacao"
                error={!!touched.situacao && !!errors.situacao}
                helperText={touched.situacao && errors.situacao}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Status Cemig"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.status_cemig}
                name="status_cemig"
                id="status_cemig"
                error={!!touched.status_cemig && !!errors.status_cemig}
                helperText={touched.status_cemig && errors.status_cemig}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Calc LT"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.calc_lt}
                name="calc_lt"
                id="calc_lt"
                error={!!touched.calc_lt && !!errors.calc_lt}
                helperText={touched.calc_lt && errors.calc_lt}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Travessia Rod DNIT"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.travessia_rod_dnit}
                name="travessia_rod_dnit"
                id="travessia_rod_dnit"
                error={!!touched.travessia_rod_dnit && !!errors.travessia_rod_dnit}
                helperText={touched.travessia_rod_dnit && errors.travessia_rod_dnit}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Travessia Rod DER"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.travessia_rod_der}
                name="travessia_rod_der"
                id="travessia_rod_der"
                error={!!touched.travessia_rod_der && !!errors.travessia_rod_der}
                helperText={touched.travessia_rod_der && errors.travessia_rod_der}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Parametrização"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.parametrizacao}
                name="parametrizacao"
                id="parametrizacao"
                error={!!touched.parametrizacao && !!errors.parametrizacao}
                helperText={touched.parametrizacao && errors.parametrizacao}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Travessia FCA"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.travessia_fca}
                name="travessia_fca"
                id="travessia_fca"
                error={!!touched.travessia_fca && !!errors.travessia_fca}
                helperText={touched.travessia_fca && errors.travessia_fca}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Suprimentos"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.suprimentos}
                name="suprimentos"
                id="suprimentos"
                error={!!touched.suprimentos && !!errors.suprimentos}
                helperText={touched.suprimentos && errors.suprimentos}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Vistoria"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.vistoria}
                name="vistoria"
                id="vistoria"
                error={!!touched.vistoria && !!errors.vistoria}
                helperText={touched.vistoria && errors.vistoria}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Pre Atualização"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.pre_att}
                name="pre_att"
                id="pre_att"
                error={!!touched.pre_att && !!errors.pre_att}
                helperText={touched.pre_att && errors.pre_att}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Devolução"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.devolucao}
                name="devolucao"
                id="devolucao"
                error={!!touched.devolucao && !!errors.devolucao}
                helperText={touched.devolucao && errors.devolucao} 
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Pendência"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.pendencia}
                name="pendencia"
                id="pendencia"
                error={!!touched.pendencia && !!errors.pendencia}
                helperText={touched.pendencia && errors.pendencia}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="CCO"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.cco}
                name="cco"
                id="cco"
                error={!!touched.cco && !!errors.cco}
                helperText={touched.cco && errors.cco}
                sx={{ gridColumn: "span 2" }}
              />
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Transformadores"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.transformadores}
                name="transformadores"
                id="transformadores"
                error={!!touched.transformadores && !!errors.transformadores}
                helperText={touched.transformadores && errors.transformadores}
                sx={{ gridColumn: "span 2" }}
              /> */}
            </Box>
            <Box display="flex" justifyContent="end" mt="20px">
              <Button type="submit" color="secondary" variant="contained">
                Cadastrar NS
              </Button>
            </Box>
          </form>
        )}
      </Formik>
    </Box>
  );
};
const checkoutSchema = yup.object().shape({
  city: yup.string().required("Campo Obrigatório"),
  client: yup.string().required("Campo Obrigatório"),
  cnpj: yup.string(),
  city: yup.string(),
  nameobra: yup.string(),
  tipo: yup.string(),
  data_inicio: yup.string(),
  data_final: yup.string(),
  situacao: yup.string(),
  status_cemig: yup.string(),
  calc_lt: yup.string(),
  travessia_rod_dnit: yup.string(),
  travessia_rod_der: yup.string(),
  parametrizacao: yup.string(),
  travessia_fca: yup.string(),
  suprimentos: yup.string(),
  vistoria: yup.string(),
  pre_att: yup.string(),
  devolucao: yup.string(),
  pendencia: yup.string(),
  cco: yup.string(),
  transformadores: yup.string(),
});
const initialValues = {
  ns: "",
  client: "",
  cnpj: "",
  city: "",
  nameobra: "",
  // tipo: "",
  // data_inicio: "",
  // data_final: "",
  // situacao: "",
  // status_cemig: "",
  // calc_lt: "",
  // travessia_rod_dnit: "",
  // travessia_rod_der: "",
  // parametrizacao: "",
  // travessia_fca: "",
  // suprimentos: "",
  // vistoria: "",
  // pre_att: "",
  // devolucao: "",
  // pendencia: "",
  // cco: "",
  // transformadores: "",
};

export default NsCreateForm;
