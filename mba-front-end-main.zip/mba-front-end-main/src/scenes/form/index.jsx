import { Box, Button, MenuItem, Select, TextField } from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import Header from "../../components/Header";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import InputMask from "react-input-mask";
import { useState } from "react";
import jwt_decode from "jwt-decode";

export const mask = (v) => {
  v = v.replace(/\D/g, "");

  if (v.length <= 11) {
    v = v.replace(/(\d{3})(\d)/, "$1.$2");
    v = v.replace(/(\d{3})(\d)/, "$1.$2");
    v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  } else {
    v = v.replace(/^(\d{2})(\d)/, "$1.$2");
    v = v.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
    v = v.replace(/\.(\d{3})(\d)/, ".$1/$2");
    v = v.replace(/(\d{4})(\d)/, "$1-$2");
  }

  return v;
};

const Form = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");

  const token = localStorage.getItem("token");
  const decodeToken = jwt_decode(token);
  const typeUser = decodeToken.typeUser;
  const handleFormSubmit = (values) => {
    if (typeUser !== 3) {
      api
        .post("/user", values, config)
        .then(() => {
          alert("Usuário/Cliente cadastrado com sucesso!");
        })
        .catch((err) => {
          console.log(err);
        });
    } else{
      
    }
  };

  const [valor, setValor] = useState("");

  function handleChangeMask(event) {
    const { value } = event.target;

    setValor(mask(value));
  }
  return (
    <Box m="20px">
      <Header title=" USUARIO" subtitle="Criar um novo usuário/cliente" />

      <Formik
        onSubmit={handleFormSubmit}
        initialValues={initialValues}
        validationSchema={checkoutSchema}
      >
        {({
          values,
          errors,
          touched,
          handleBlur,
          handleChange,
          handleSubmit,
        }) => (
          <form onSubmit={handleSubmit}>
            <Box
              display="grid"
              gap="30px"
              gridTemplateColumns="repeat(4, minmax(0, 1fr))"
              sx={{
                "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
              }}
            >
              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Nome Completo - Nome do Cliente (completo)"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.name}
                name="name"
                id="name"
                error={!!touched.name && !!errors.name}
                helperText={touched.name && errors.name}
                sx={{ gridColumn: "span 2" }}
              />

              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="CPF / CNPJ"
                onBlur={handleBlur}
                onChange={handleChangeMask}
                value={(values.cpf = valor)}
                name="cpf"
                id="cpf"
                error={!!touched.cpf && !!errors.cpf}
                helperText={touched.cpf && errors.cpf}
                sx={{ gridColumn: "span 2" }}
                inputProps={{ maxLength: 18 }}
              />

              <TextField
                fullWidth
                variant="filled"
                type="text"
                label="Email"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.email}
                name="email"
                id="email"
                error={!!touched.email && !!errors.email}
                helperText={touched.email && errors.email}
                sx={{ gridColumn: "span 4" }}
              />

              <TextField
                fullWidth
                variant="filled"
                type="password"
                label="Password"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.password}
                name="password"
                id="password"
                error={!!touched.password && !!errors.password}
                helperText={touched.password && errors.password}
                sx={{ gridColumn: "span 4" }}
              />

              <Select
                variant="filled"
                name="typeUser"
                id="typeUser"
                onBlur={handleBlur}
                onChange={handleChange}
                value={values.typeUser}
                error={!!touched.typeUser && !!errors.typeUser}
                helperText={touched.typeUser && errors.typeUser}
              >
                <MenuItem value={Number(2)}>Editor</MenuItem>
                <MenuItem value={Number(3)}>Cliente</MenuItem>
              </Select>
            </Box>
            <Box display="flex" justifyContent="end" mt="20px">
              <Button type="submit" color="secondary" variant="contained">
                Criar Usuário
              </Button>
            </Box>
          </form>
        )}
      </Formik>
    </Box>
  );
};

const phoneRegExp =
  /^((\+[1-9]{1,4}[ -]?)|(\([0-9]{2,3}\)[ -]?)|([0-9]{2,4})[ -]?)*?[0-9]{3,4}[ -]?[0-9]{3,4}$/;

const checkoutSchema = yup.object().shape({
  name: yup.string().required("Campo Obrigatório"),
  email: yup.string().email("invalid email").required("Campo Obrigatório"),
  cpf: yup.string(),
  password: yup.string().required("Campo Obrigatório"),
});
const initialValues = {
  name: "",
  email: "",
  cpf: "",
  password: "",
};

export default Form;
