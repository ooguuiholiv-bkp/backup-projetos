import {
  Alert,
  Box,
  Button,
  IconButton,
  Modal,
  TextField,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import Header from "../../components/Header";
import { useTheme } from "@mui/material";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import { useEffect, useState } from "react";
import CreateIcon from "@mui/icons-material/Create";
import DeleteIcon from "@mui/icons-material/Delete";
import jwt_decode from "jwt-decode";


const Tickets = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const columns = [
    {
      field: "title",
      headerName: "Titúlo",
      flex: 1,
      cellClassName: "name-column--cell",
    },

    {
      field: "description",
      headerName: "Descrição",
      flex: 1,
    },
    {
      field: "priority",
      headerName: "Prioridade",
      flex: 1,
    },
    {
      field: "status",
      headerName: "Status",
      flex: 1,
    },
    {
      field: "-",
      headerName: "Ações",
      flex: 1,
      renderCell: () => (
        <strong>
          <IconButton>
            <CreateIcon />
          </IconButton>
          <IconButton>
            <DeleteIcon />
          </IconButton>
        </strong>
      ),
    },
  ];

  const [users, setUsers] = useState([]);
  const isNonMobile = useMediaQuery("(min-width:600px)");

  const [selectedItem, setSelectedItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editedItem, setEditedItem] = useState(null);
  const [alertOpen, setAlertOpen] = useState(false);
  const [alertSuccessOpen, setAlertSuccessOpen] = useState(false);
  const handleRowClick = (params) => {
    const clickedItem = users.find((item) => item.id === params.id);

    if (clickedItem) {
      setSelectedItem(clickedItem);
      setEditedItem({ ...clickedItem }); // Clone o objeto para que as edições não afetem o item original
      setIsModalOpen(true);
    }
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  const handleSaveChanges = async () => {
    try {
      const { id, typeUser,...editedData } = editedItem;

      await api.put(`/user/${editedItem.id}`, editedData, config);
      setUsers((prevData) =>
        prevData.map((item) => (item.id === editedItem.id ? editedItem : item))
      );
      setAlertSuccessOpen(true);
      handleCloseModal();
    } catch (error) {
      console.log(error);
      setAlertOpen(true);
      handleCloseModal();
    }

    setUsers((prevData) =>
      prevData.map((item) => (item.id === editedItem.id ? editedItem : item))
    );
    handleCloseModal();
  };

  const deleteUser = async () => {
    try {
      await api.delete(`/user/${editedItem.id}`, config);
      setAlertSuccessOpen(true);
      handleCloseModal();
    } catch (error) {
      console.log(error);
      setAlertOpen(true);
      handleCloseModal();
    }
  };

  const handleCloseAlert = () => {
    setAlertOpen(false);
  };
  const handleCloseAlertSuccess = () => {
    setAlertSuccessOpen(false);
  };

  const handleFieldChange = (field, value) => {
    setEditedItem((prevItem) => ({ ...prevItem, [field]: value }));
  };

  const token = localStorage.getItem('token')
  const decodeToken = jwt_decode(token);
  const typeUser = decodeToken.typeUser;

  useEffect(() => {
    if(typeUser === 3){
    } else{
      api
      .get("/ticket", config)
      .then((response) => {
        let usuarios = response.data;
        let dataUser = usuarios.map((user) => {
          if (user.typeUser === 1) {
            user.typeUser = "Admin";
          }
          if (user.typeUser === 2) {
            user.typeUser = "Editor";
          }
          if (user.typeUser === 3) {
            user.typeUser = "Cliente";
          }
          return {
            title: user.title,
            description: user.description,
            priority: user.priority,
            id: user.id,
            typeUser: user.typeUser,
          };
        });

        setUsers(dataUser);
      }).catch((error) => console.log(error))
    }
  })

  return (
    <Box m="20px">
      <Header title="Informações de Usuários" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <DataGrid
          rows={users}
          columns={columns}
          components={{ Toolbar: GridToolbar }}
          onRowClick={handleRowClick}
        />
        <Modal
          open={isModalOpen}
          onClose={handleCloseModal}
          aria-labelledby="modal-title"
          aria-describedby="modal-description"
        >
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              minWidth: "75vw",
              minHeight: "80vh",
              transform: "translate(-50%, -50%)",
              width: 400,
              bgcolor: "rgb(62, 67, 150, 0.95)",
              boxShadow: 24,
              p: 4,
            }}
          >
            <Typography id="modal-title" variant="h6" component="h2">
              Detalhes do Item Selecionado
            </Typography>
            <br />
            <br />
            {selectedItem && (
              <Box
                display="grid"
                gap="30px"
                gridTemplateColumns="repeat(2, minmax(0, 1fr))"
                sx={{
                  "& > div": {
                    gridColumn: isNonMobile ? undefined : "span 4",
                  },
                }}
              >
                <TextField value={editedItem.name} label="Nome do Cliente" />

                <TextField
                  value={editedItem.cpf}
                  label="CPF / CNPJ"
                  onChange={(e) => handleFieldChange("cpf", e.target.value)}
                />
                <TextField
                  value={editedItem.email}
                  label="E-mail"
                  onChange={(e) => handleFieldChange("email", e.target.value)}
                />
              </Box>
            )}
            <Box display="flex" justifyContent="end" mt="20px" gap="1rem">
              <Button
                type="submit"
                color="secondary"
                variant="contained"
                onClick={handleSaveChanges}
              >
                Salvar Alterações
              </Button>
              <Button
                type="submit"
                color="error"
                variant="contained"
                onClick={deleteUser}
              >
                Deletar
              </Button>
            </Box>
          </Box>
        </Modal>
        {alertOpen && (
          <Alert severity="error" variant="filled" onClose={handleCloseAlert}>
            Aconteceu um erro ao tentar concluir esta operação - Talvez voce não
            tenha permissões suficientes.
          </Alert>
        )}
        {alertSuccessOpen && (
          <Alert
            severity="success"
            variant="outlined"
            onClose={handleCloseAlertSuccess}
          >
            Suas alterações foram salvas com sucesso.
          </Alert>
        )}
      </Box>
    </Box>
  );
};

export default Tickets;
