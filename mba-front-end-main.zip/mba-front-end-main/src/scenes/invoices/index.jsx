import {
  Alert,
  AlertTitle,
  Box,
  Button,
  IconButton,
  Modal,
  Select,
  TextField,
  TextareaAutosize,
  Typography,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { tokens } from "../../theme";
import CreateIcon from "@mui/icons-material/Create";
import DeleteIcon from "@mui/icons-material/Delete";
import Header from "../../components/Header";
import api from "../../services/api";
import { config } from "../../services/authenticated";
import { useState } from "react";
import { useEffect } from "react";
import jwt_decode from "jwt-decode";
import { MenuItem } from "react-pro-sidebar";
import { Formik } from "formik";
import * as yup from "yup";

const Invoices = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const [selectedItem, setSelectedItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editedItem, setEditedItem] = useState(null);
  const [ns, setNs] = useState([]);
  const token = localStorage.getItem("token");
  const decodeToken = jwt_decode(token);
  const typeUser = decodeToken.typeUser;
  const id = decodeToken.id;
  const name = decodeToken.name;

  const [isOpenTicketModal, setIsOpenTicketModal] = useState(false);

  useEffect(() => {
    if (typeUser === 3) {
      api
        .get(`/ns/u/${id}`, config)
        .then((response) => setNs(response.data))
        .catch((error) => console.log(error));
    } else {
      api
        .get("/ns", config)
        .then((response) => setNs(response.data))
        .catch((error) => console.log(error));
    }
  }, []);

  const handleRowClick = (params) => {
    const clickedItem = ns.find((item) => item.id === params.id);

    if (clickedItem) {
      setSelectedItem(clickedItem);
      setEditedItem({ ...clickedItem }); // Clone o objeto para que as edições não afetem o item original
      setIsModalOpen(true);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  const handleCloseTicketModal = () => {
    setIsOpenTicketModal(false);
  };

  const handleSaveChanges = async () => {
    try {
      const { id, ...editedData } = editedItem;

      await api.put(`/ns/${editedItem.id}`, editedData, config);
      setNs((prevData) =>
        prevData.map((item) => (item.id === editedItem.id ? editedItem : item))
      );
      setAlertSuccessOpen(true);
      handleCloseModal();
    } catch (error) {
      console.log(error);
      setAlertOpen(true);
      handleCloseModal();
    }

    setNs((prevData) =>
      prevData.map((item) => (item.id === editedItem.id ? editedItem : item))
    );
    handleCloseModal();
  };

  const [alertOpen, setAlertOpen] = useState(false);
  const [alertSuccessOpen, setAlertSuccessOpen] = useState(false);

  const deleteNs = async () => {
    try {
      await api.delete(`/ns/${editedItem.id}`, config);
      setAlertSuccessOpen(true);
      handleCloseModal();
    } catch (error) {
      console.log(error);
      setAlertOpen(true);
      handleCloseModal();
    }
  };
  const handleCloseAlert = () => {
    setAlertOpen(false);
  };
  const handleCloseAlertSuccess = () => {
    setAlertSuccessOpen(false);
  };

  const handleFieldChange = (field, value) => {
    setEditedItem((prevItem) => ({ ...prevItem, [field]: value }));
  };

  const [campo, setCampo] = useState({
    title: "",
    description: "",
    priority: "",
  });
  const handleFieldTicketChange = (dados) => {
    setCampo((prevDados) => ({
      ...prevDados,
      ...dados,
    }));
  };

  const handleFormSubmit = (values) => {
    api
      .post("/ticket", values, config)
      .then(() => {
        handleCloseTicketModal(true)
        handleCloseModal(true)
        setAlertSuccessOpen(true)
      })
      .catch((err) => {
        handleCloseTicketModal(true)
        handleCloseModal(true)
        setAlertOpen(true)
        console.error(err)
      });
  };

  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    // { field: "id", headerName: "ID" },
    {
      field: "ns",
      headerName: "NS",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    {
      field: "client",
      headerName: "Cliente",
      flex: 2,
    },
    {
      field: "city",
      headerName: "Cidade",
      flex: 1,
    },
    {
      field: "nameobra",
      headerName: "Nome da Obra",
      flex: 1,
    },
    {
      field: "-",
      headerName: "Ações",
      flex: 1,
      renderCell: () => (
        <strong>
          <IconButton>
            <CreateIcon />
          </IconButton>
          <IconButton>
            <DeleteIcon />
          </IconButton>
        </strong>
      ),
    },
  ];

  return (
    <Box m="20px">
      <Header title="Consulta de NS" />
      <Box
        m="40px 0 0 0"
        height="75vh"
        sx={{
          "& .MuiDataGrid-root": {
            border: "none",
          },
          "& .MuiDataGrid-cell": {
            borderBottom: "none",
          },
          "& .name-column--cell": {
            color: colors.greenAccent[300],
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: colors.blueAccent[700],
            borderBottom: "none",
          },
          "& .MuiDataGrid-virtualScroller": {
            backgroundColor: colors.primary[400],
          },
          "& .MuiDataGrid-footerContainer": {
            borderTop: "none",
            backgroundColor: colors.blueAccent[700],
          },
          "& .MuiCheckbox-root": {
            color: `${colors.greenAccent[200]} !important`,
          },
          "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
            color: `${colors.grey[100]} !important`,
          },
        }}
      >
        <DataGrid
          rows={ns}
          columns={columns}
          onRowClick={handleRowClick}
          components={{ Toolbar: GridToolbar }}
        />
        <Modal
          open={isModalOpen}
          onClose={handleCloseModal}
          aria-labelledby="modal-title"
          aria-describedby="modal-description"
        >
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              minWidth: "75vw",
              minHeight: "80vh",
              transform: "translate(-50%, -50%)",
              width: 400,
              bgcolor: "rgb(62, 67, 150, 0.95)",
              boxShadow: 24,
              p: 4,
            }}
          >
            <Typography id="modal-title" variant="h3" component="h2">
              Detalhes do Item Selecionado
            </Typography>
            <br />
            <br />
            {selectedItem && (
              <Box
                display="grid"
                gap="30px"
                gridTemplateColumns="repeat(4, minmax(0, 1fr))"
                sx={{
                  "& > div": {
                    gridColumn: isNonMobile ? undefined : "span 4",
                  },
                }}
              >
                <TextField
                  value={editedItem.ns}
                  label="NS"
                  onChange={(e) => handleFieldChange("ns", e.target.value)}
                />
                <TextField value={editedItem.client} label="Nome do Cliente" />
                <TextField
                  value={editedItem.cnpj}
                  label="CNPJ Contratante"
                  onChange={(e) => handleFieldChange("cnpj", e.target.value)}
                />
                <TextField
                  value={editedItem.city}
                  label="Cidade"
                  onChange={(e) => handleFieldChange("city", e.target.value)}
                />
                <TextField
                  value={editedItem.nameobra}
                  label="Nome da Obra"
                  onChange={(e) =>
                    handleFieldChange("nameobra", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.type}
                  label="Tipo de Obra"
                  onChange={(e) => handleFieldChange("type", e.target.value)}
                />
                <TextField
                  value={editedItem.situation}
                  label="Situação"
                  onChange={(e) =>
                    handleFieldChange("situation", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.statusCemig}
                  label="Status na Cemig"
                  onChange={(e) =>
                    handleFieldChange("statusCemig", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.calcLt}
                  label="Calc LT"
                  onChange={(e) => handleFieldChange("calcLt", e.target.value)}
                />
                <TextField
                  value={editedItem.travRodDnit}
                  label="Trav Rod Dnit"
                  onChange={(e) =>
                    handleFieldChange("travRodDnit", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.travRodDer}
                  label="Trav Rod Der"
                  onChange={(e) =>
                    handleFieldChange("travRodDer", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.parameterization}
                  label="Parametrização"
                  onChange={(e) =>
                    handleFieldChange("parameterization", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.travFca}
                  label="Trav FCA"
                  onChange={(e) => handleFieldChange("travFca", e.target.value)}
                />
                <TextField
                  value={editedItem.supplies}
                  label="Suprimentos"
                  onChange={(e) =>
                    handleFieldChange("supplies", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.survey}
                  label="Inspeção"
                  onChange={(e) => handleFieldChange("survey", e.target.value)}
                />
                <TextField
                  value={editedItem.preAtt}
                  label="Pre Att"
                  onChange={(e) => handleFieldChange("preAtt", e.target.value)}
                />
                <TextField
                  value={editedItem.devolution}
                  label="Devolução"
                  onChange={(e) =>
                    handleFieldChange("devolution", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.pendenncy}
                  label="Pendencia"
                  onChange={(e) =>
                    handleFieldChange("pendenncy", e.target.value)
                  }
                />
                <TextField
                  value={editedItem.cco}
                  label="cco"
                  onChange={(e) => handleFieldChange("cco", e.target.value)}
                />
                <TextField
                  value={editedItem.transformers}
                  label="Transformador"
                  onChange={(e) =>
                    handleFieldChange("transformers", e.target.value)
                  }
                />
              </Box>
            )}
            <Box display="flex" justifyContent="end" mt="20px" gap="1rem">
              <Button
                type="submit"
                color="info"
                variant="contained"
                onClick={() => {
                  setIsOpenTicketModal(true);
                }}
              >
                Abrir Ticket
              </Button>
              <Button
                type="submit"
                color="secondary"
                variant="contained"
                onClick={handleSaveChanges}
              >
                Salvar Alterações
              </Button>
              <Button
                type="submit"
                color="error"
                variant="contained"
                onClick={deleteNs}
              >
                Deletar
              </Button>
            </Box>
            <Modal
              open={isOpenTicketModal}
              onClose={handleCloseTicketModal}
              aria-labelledby="modal-title"
              aria-describedby="modal-description"
            >
              <Box
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  minWidth: "75vw",
                  minHeight: "90vh",
                  transform: "translate(-50%, -50%)",
                  width: 400,
                  bgcolor: "rgb(62, 67, 150, 0.95)",
                  boxShadow: 24,
                  p: 4,
                }}
              >
                <Typography id="modal-title" variant="h3" component="h2">
                  Abrir Ticket
                </Typography>
                <br />
                <br />
                <Formik
                  onSubmit={handleFormSubmit}
                  initialValues={initialValues}
                  validationSchema={checkoutSchema}
                >
                  {({
                    values,
                    errors,
                    touched,
                    handleBlur,
                    handleChange,
                    handleSubmit,
                  }) => (
                    <form onSubmit={handleSubmit}>
                      <Box
                        display="grid"
                        gap="30px"
                        gridTemplateColumns="repeat(1, minmax(0, 1fr))"
                        sx={{
                          "& > div": {
                            gridColumn: isNonMobile ? undefined : "span 4",
                          },
                        }}
                      >
                        <TextField
                          value={(values.ns = editedItem.ns)}
                          label="NS"
                          id="ns"
                          name="ns"
                          sx={{ gridColumn: "span 4" }}
                        />
                        <TextField
                          fullWidth
                          variant="filled"
                          type="text"
                          label="Titulo"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          value={values.title}
                          name="title"
                          id="title"
                          error={!!touched.title && !!errors.title}
                          helperText={touched.title && errors.title}
                          sx={{ gridColumn: "span 4" }}
                        />

                        <TextField
                          fullWidth
                          variant="filled"
                          type="text"
                          label="Descrição"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          value={values.description}
                          name="description"
                          id="description"
                          error={!!touched.description && !!errors.description}
                          helperText={touched.description && errors.description}
                          sx={{ gridColumn: "span 4" }}
                        />
                        <TextField
                          fullWidth
                          variant="filled"
                          type="text"
                          label="Descrição"
                          placeholder="Baixa / Media / Alta"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          value={values.priority}
                          name="priority"
                          id="priority"
                          error={!!touched.priority && !!errors.priority}
                          helperText={touched.priority && errors.priority}
                          sx={{ gridColumn: "span 4" }}
                        />
                      </Box>
                      <Box display="flex" justifyContent="end" mt="20px">
                        <Button
                          type="submit"
                          color="secondary"
                          variant="contained"
                        >
                          Abrir Ticket
                        </Button>
                      </Box>
                    </form>
                  )}
                </Formik>
              </Box>
            </Modal>
          </Box>
        </Modal>
        {alertOpen && (
          <Alert severity="error" variant="filled" onClose={handleCloseAlert}>
            Aconteceu um erro ao tentar concluir esta operação - Talvez voce não
            tenha permissões suficientes.
          </Alert>
        )}
        {alertSuccessOpen && (
          <Alert
            severity="success"
            variant="outlined"
            onClose={handleCloseAlertSuccess}
          >
            Suas alterações foram salvas com sucesso.
          </Alert>
        )}
      </Box>
    </Box>
  );
};
const checkoutSchema = yup.object().shape({
  title: yup.string().required("Campo Obrigatório"),
  description: yup.string().required("Campo Obrigatório"),
  priority: yup.string().required("Campo Obrigatório").matches(/^(Baixa|Media|Alta|BAIXA|MEDIA|ALTA|baixa|media|alta)$/, "Valor inválido"),
  ns: yup.string().required("Campo Obrigatório"),
});
const initialValues = {
  title: "",
  description: "",
  priority: "",
  ns: "",
};

export default Invoices;
