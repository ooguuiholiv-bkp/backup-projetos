import styled from "@emotion/styled";
import Logo from "../../assets/logo.png";
import { TextField } from "@mui/material";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #141b2d;
    .content {
      width: 25vw;
      height: 65vh;
      background: #f2f2f2;
      border-radius: 0.2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      .logo-img {
        width: 15vw;
      }
      form {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 2rem;
      }
    }
  }
`;

export const Forgot = () => {
  return (
    <Container>
        <div className="content">
            <img src={Logo} alt="logo" className="logo-img" />
            
            <form action="">
                
                <TextField name="email" placeholder="email" id="email" type="text" label="Insira seu e-mail" />
                <TextField type="submit" value="Redefinir senha" color="success" onClick={() => {
                    alert("Caso este e-mail exista em nossa base de dados você receberá em seu e-mail a senha redefinida")
                }}/>
            </form>
        </div>
    </Container>
  )
};
