import { createBrowserRouter } from "react-router-dom";
import { Login } from "./pages/login/login";
import App from "./App";
import { PrivateRoute } from "./PrivateRoutes";
import { Forgot } from "./pages/forgot/forgot";

export const rotas = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/forgot",
    element: <Forgot />,
  },
  {
    path: "*",
    element: (
      <PrivateRoute>
        <App />
      </PrivateRoute>
    ),
  },
]);
