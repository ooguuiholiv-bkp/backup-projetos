import { Button } from "./styles";

export const Botao = ({type, onClick, children, color, large}) => {
  return (
    <>
      <Button large={large} color={color} type={type} onClick={onClick}>{children}</Button>
    </>
  );
};
