import styled from "styled-components";

export const Button = styled.button`
  width: ${props => props.large };
  height: 5vh;
  border-radius: 0.3rem;
  border: none;
  color: white;
  background-color: ${props => props.color};
  margin-left: 0.2rem;
`;
