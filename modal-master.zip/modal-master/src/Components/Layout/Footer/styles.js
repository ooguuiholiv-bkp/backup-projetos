import styled from 'styled-components';

export const Container = styled.div`
  width: 20vw;
  height: 3vh;
  background-color: greenyellow;
  margin-top: 0;
  grid-row-start: 3;
  grid-column-start: 1;
`;
