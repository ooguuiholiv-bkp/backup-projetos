import styled from 'styled-components';

export const Container = styled.div`
  width: 80vw;
  height: 10vh;
  background-color: #F2F;
  margin-left: auto;
  grid-row-start: 1;
  grid-column-start: 2;
`;
