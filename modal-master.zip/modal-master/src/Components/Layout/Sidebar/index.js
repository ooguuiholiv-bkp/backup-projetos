import React from "react";
import { Container } from "./styles";

function Sidebar() {
  const hide = () => {
    var x = document.getElementById("link-cad");
    if (x.style.display === "none") {
      x.style.display = "grid";
    } else {
      x.style.display = "none";
    }
  };
  return (
    <Container>
      <div className="menus">
        <button onClick={hide}>
          Cadastros
        </button>
        <div id="link-cad">
          <a href="/motorista">Motorista</a>
          <a href="#">Veiculo</a>
        </div>
      </div>
    </Container>
  );
}
export default Sidebar;
