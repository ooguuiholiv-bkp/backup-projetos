import styled from 'styled-components';

export const Container = styled.div`
  width: 20vw;
  height: 97vh;
  background-color: #2562AB;
  margin-top: 0;
  grid-row-start: 1;
  grid-column-start: 1;

  #link-cad{
    display: grid;
  }
  a{
    color: white;
  }
`;
