import Footer from "../../Components/Layout/Footer";
import Header from "../../Components/Layout/Header";
import Sidebar from "../../Components/Layout/Sidebar";
import Body from "./Body";

import { Container } from "./styles";

function Layout({children}) {
  return (
    <>
      <Container>
        <Header />
        <Sidebar />
        <Body>
          {children}
        </Body>
        <Footer />
      </Container>
    </>
  );
}
export default Layout;
