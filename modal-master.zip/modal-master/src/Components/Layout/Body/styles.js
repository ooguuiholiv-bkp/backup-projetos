import styled from 'styled-components';

export const Container = styled.div`
  width: 80vw;
  height: 90vh;
  background-color: #F2F2F2;
  grid-column-start: 2;
  grid-row-start: 1;
  grid-row-end: 4;
  margin-top: 10vh;
`