import React, { useState, useEffect } from "react";
import styled from "styled-components";
import { FaAddressCard } from "react-icons/fa";
import { AiFillPhone } from "react-icons/ai";
import { AiFillSetting } from "react-icons/ai";
import { BsClipboardData } from "react-icons/bs";

const Overlay = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  background-color: rgba(13, 140, 238, 0.25);
`;

const Box = styled.section`
  display: grid;
  background-color: #f2f2f2;
  border-radius: 0.5rem;
  width: 65vw;
  height: 90vh;
`;

const Header = styled.header`
  height: 10vh;
  grid-area: "header";
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid rgba(0, 0, 0, 0.2);
  align-items: center;
  padding: 0 1rem;
  background-color: #0d8cee;
  border-top-left-radius: 0.6rem;
  border-top-right-radius: 0.6rem;
  color: white;
  button {
    border: none;
    background: none;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
  }
`;

const Content = styled.div`
  padding: 0.2rem 1rem;
  display: grid;
  overflow: auto;

  div {
    margin: 0.2rem;
  }

  .codigo-div {
    display: grid;
    grid-row-start: 1;

    input {
      width: 10vw;
    }
  }
  .documento-div {
    display: grid;
    grid-row-start: 1;
    grid-column-start: 2;
    grid-column-end: 5;
    input {
      width: 25vw;
    }
  }
  .nome-div {
    display: grid;
    grid-row-start: 2;
    grid-column: 1/5;

    input {
      width: 75%;
    }
  }
  .apelido-div {
    display: grid;
    grid-row-start: 3;
    grid-column: 1/5;

    input {
      width: 75%;
    }
  }
  .tab-dados {
    justify-content: start;
    align-content: center;
    display: grid;
    margin-top: 2rem;
    .list {
      .list-items {
        font-size: 1rem;
        display: grid;
        align-content: center;
        width: 10vw;
        height: 5vh;
        list-style: none;
        margin: 0.2rem;
        border-radius: 0.2rem;
        padding: 0 0.2rem;

        &.active {
          background-color: rgba(13, 140, 238, 0.9);
          transition: all 0.3s ease-in-out;
          a {
            color: white;
          }
        }
        a {
          color: rgba(13, 140, 238, 0.9);
          text-decoration: none;

          .icon {
            font-size: 1.2rem;
          }

          span {
            padding: 0 0.2rem;
          }
        }
      }
    }
  }
  .panel-container {
    display: grid;
    .dados-endereco {
      display: grid;
      h2 {
        color: orange;
      }
    }
    .dadosEnd {
      grid-column-start: 1;
      grid-row-start: 3;
    }
    .logEnd {
      grid-column-start: 1;
      grid-row-start: 5;
      background-color: antiquewhite;
    }
    .numEnd {
      grid-column-start: 2;
      grid-row-start: 5;
      background-color: aquamarine;
    }
    .compEnd {
      grid-column-start: 1;
      grid-row-start: 7;
      background-color: aliceblue;
    }
    .bairroEnd {
      grid-column-start: 2;
      grid-row-start: 7;
      background-color: red;
    }
    .cityEnd {
      grid-column-start: 1;
      grid-row-start: 9;
      background-color: yellow;
    }
    .cityEnd2 {
      grid-column-start: 2;
      grid-row-start: 9;
      background-color: yellowgreen;
    }
    .dadosEndLabel {
      grid-column-start: 1;
      grid-row-start: 2;
    }
    .logEndLabel {
      grid-column-start: 1;
      grid-row-start: 4;
    }
    .numEndLabel {
      grid-column-start: 2;
      grid-row-start: 4;
    }
    .compEndLabel {
      grid-column-start: 1;
      grid-row-start: 6;
    }
    .bairroEndLabel {
      grid-column-start: 2;
      grid-row-start: 6;
    }
    .cityEndLabel {
      grid-column-start: 1;
      grid-row-start: 8;
    }
  }
  .dados-contato {
    display: grid;
    h2 {
      color: orange;
    }
  }
  .parametros-page {
    display: grid;
    h2 {
      color: orange;
    }
  }
  .outros-dados {
    display: grid;
    h2 {
      color: orange;
    }
  }

  .oculto {
    display: none;
  }
`;

const Footer = styled.div`
  display: grid;
  width: 100%;
  background-color: #f2f2f2;
  border-top: 1px solid rgba(0, 0, 0, 0.2);
  grid-column-start: 1;
  grid-row-end: 15;
  color: white;
  text-align: center;
  border-bottom-left-radius: 0.2rem;
  border-bottom-right-radius: 0.2rem;
  justify-items: end;
  align-items: center;

  .btn-action {
    display: flex;
    margin: 0 1rem;

    button {
      margin: 0 0.2rem;
      width: 7vw;
      height: 5vh;
      border: none;
      color: white;
      border-radius: 0.2rem;
    }
    .primary-btn {
      background-color: #0d8cee;

      &:hover {
        background-color: #0c75e2;
        transition: all 200ms ease-in;
      }
    }
    .secondary-btn {
      background-color: #727b84;
      &:hover {
        background-color: #726b84;
        transition: all 200ms ease-in;
      }
    }
  }
`;

export default function Modal() {
  const [active, setActive] = useState([]);

  useEffect(() => {
    const listItem = document.querySelectorAll(".list-items");
    function activeLink() {
      listItem.forEach((item) => item.classList.remove("active"));
      this.classList.add("active");
      setActive();
    }
    listItem.forEach((item) => item.addEventListener("click", activeLink));
  }, [active]);

  const [div, setDiv] = useState([]);
  useEffect(() => {
    
  }, [div])

  return (
    <Overlay>
      <Box>
        <Header>
          <h2> Cadastro de Motoristas</h2>
          <button type="button">X</button>
        </Header>
        <Content>
          <div className="codigo-div">
            <label htmlFor="codigo">Código</label>
            <input type="text" disabled id="codigo" />
          </div>
          <div className="documento-div">
            <label htmlFor="documento">CPF</label>
            <input name="documento" maxLength={11} type="text" id="documento" />
          </div>
          <div className="nome-div">
            <label htmlFor="nome">Nome</label>
            <input name="nome" type="text" id="nome" />
          </div>
          <div className="apelido-div">
            <label htmlFor="apelido">Apelido</label>
            <input name="apelido" type="text" id="apelido" />
          </div>
          <div className="tab-dados">
            <ul className="list">
              <li className="list-items active endereco" id="endereco">
                <a href="#dados-endereco">
                  <span className="icon">{<FaAddressCard />}</span>
                  <span className="text">Endereço</span>
                </a>
              </li>
              <li className="list-items">
                <a href="#dados-contato">
                  <span className="icon">{<AiFillPhone />}</span>
                  <span className="text">Contato</span>
                </a>
              </li>
              <li className="list-items">
                <a href="#parametros-page">
                  <span className="icon">{<AiFillSetting />}</span>
                  <span className="text">Parâmetros</span>
                </a>
              </li>
              <li className="list-items">
                <a href="#outros-dados">
                  <span className="icon">{<BsClipboardData />}</span>
                  <span className="text">Outros dados</span>
                </a>
              </li>
            </ul>
          </div>

          <div className="panel-container">
            <form id="form1">
              <div className="dados-endereco oculto" id="dados-endereco">
                <h2>Dados do Endereço</h2>
                <label htmlFor="dadosEnd" className="dadosEndLabel">
                  Código Postal
                </label>
                <input
                  type="text"
                  name="dadosEnd"
                  className="dadosEnd"
                  id="dadosEnd"
                />
                <label htmlFor="logEnd" className="logEndLabel">
                  Logradouro
                </label>
                <input
                  type="text"
                  name="logEnd"
                  className="logEnd"
                  id="logEnd"
                />
                <label htmlFor="numEnd" className="numEndLabel">
                  Número
                </label>
                <input
                  type="text"
                  name="numEnd"
                  className="numEnd"
                  id="numEnd"
                />
                <label htmlFor="compEnd" className="compEndLabel">
                  Complemento
                </label>
                <input
                  type="text"
                  name="compEnd"
                  className="compEnd"
                  id="compEnd"
                />
                <label htmlFor="bairroEnd" className="bairroEndLabel">
                  Bairro
                </label>
                <input
                  type="text"
                  name="bairroEnd"
                  className="bairroEnd"
                  id="bairroEnd"
                />
                <label htmlFor="cityEnd" className="cityEndLabel">
                  Cidade
                </label>
                <input
                  type="text"
                  name="cityNum"
                  className="cityEnd"
                  id="cityEnd"
                />
                <input
                  type="text"
                  name="cityEnd"
                  className="cityEnd2"
                  id="cityEnd"
                />
              </div>
              <div className="dados-contato" id="dados-contato">
                <h2>Dados de Contato</h2>
                <label htmlFor="telefone">Fixo</label>
                <input
                  type="text"
                  name="telefone"
                  className="telefone"
                  id="telefone"
                />
                <label htmlFor="celular">Celular</label>
                <input
                  type="text"
                  name="celular"
                  className="celular"
                  id="celular"
                />
                <label htmlFor="email">E-mail</label>
                <input type="text" name="email" className="email" id="email" />
              </div>
              <div className="parametros-page" id="parametros-page">
                <h2>Parâmetros</h2>
                <label htmlFor="COMBOBLOQUEIOABASTECIMENTO">
                  Bloqueio abastecimento
                </label>
                <select
                  name="COMBOBLOQUEIOABASTECIMENTO"
                  id="COMBOBLOQUEIOABASTECIMENTO"
                >
                  <option value="N" selected>
                    Não
                  </option>
                  <option value="S">Sim</option>
                </select>
                <label htmlFor="CODIGOINTEGRACAO">Código de integração</label>
                <input
                  name="CODIGOINTEGRACAO"
                  type="text"
                  className="CODIGOINTEGRACAO"
                  id="CODIGOINTEGRACAO"
                />
              </div>
              <div className="outros-dados" id="outros-dados">
                <h2>Outros dados</h2>
                <label htmlFor="CNH">CNH</label>
                <input type="text" name="CNH" id="CNH" className="CNH" />
                <label htmlFor="categoriaCnh">Categoria</label>
                <select name="categoriaCnh" id="categoriaCnh">
                  <option disabled value="nenhum" selected>
                    Nenhum
                  </option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                  <option value="E">E</option>
                  <option value="AB">AB</option>
                  <option value="AC">AC</option>
                  <option value="AD">AD</option>
                  <option value="AE">AE</option>
                </select>
                <label htmlFor="primeiraCnh">Primeira CNH</label>
                <input
                  type="date"
                  name="primeiraCnh"
                  id="primeiraCnh"
                  className="primeiraCnh"
                />
                <label htmlFor="vencimentoCnh">Vencimento CNH</label>
                <input
                  name="vencimentoCnh"
                  type="date"
                  id="vencimentoCnh"
                  className="vencimentoCnh"
                />
                <label htmlFor="cracha">Crachá</label>
                <input
                  name="cracha"
                  type="text"
                  id="cracha"
                  className="cracha"
                />
                <label htmlFor="tag">TAG</label>
                <input name="tag" type="text" id="tag" className="tag" />
              </div>
            </form>
          </div>
        </Content>
        <Footer>
          <div className="btn-action">
            <button type="submit" form="form1" className="primary-btn">
              Salvar
            </button>
            <button type="button" className="secondary-btn">
              Voltar
            </button>
          </div>
        </Footer>
      </Box>
    </Overlay>
  );
}
