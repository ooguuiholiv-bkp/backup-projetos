import { GlobalStyles } from "./Global";
import Home from "./Pages/Home";
import { Rotas } from "./routes";

function App() {
  return (
   <>
    <GlobalStyles />
    <Rotas />
   </>
  );
}

export default App;
