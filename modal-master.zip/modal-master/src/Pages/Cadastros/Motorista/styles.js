import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  height: 100%;

  .icon{
    font-size: 2rem;
  }

  .header{
    display: flex;
    align-items: center;
    font-size: 1.5rem;
    padding: 2rem;
    span{
      font-weight: bold;
    }
  }
  .card{
    background-color: #f2f2f2;
    border: none;
  }
`;

export const Container2 = styled.div`
width: 90%;
height: 90%;
margin: auto;
`
