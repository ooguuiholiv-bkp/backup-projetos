import React, { useEffect, useState, useMemo } from "react";
import { Header, Pagination, Search } from "../../../Components/Datagrid";
import useFullPageLoader from "../../../hooks/useFullPageLoader";
import Layout from "../../../Components/Layout";
import { CgFileDocument } from "react-icons/cg";
import { Container, Container2 } from "./styles";
import "../../../../node_modules/bootstrap/scss/bootstrap.scss";
import { Botao } from "../../../Components/Button";

const DataTable = () => {
  const [users, setUsers] = useState([]);
  const [loader, showLoader, hideLoader] = useFullPageLoader();
  const [totalItems, setTotalItems] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState("");
  const [sorting, setSorting] = useState({ field: "", order: "" });

  const ITEMS_PER_PAGE = 5;

  const headers = [
    { name: "Nome", field: "id", sortable: false },
    { name: "CodiNome", field: "name", sortable: true },
    { name: "Documento", field: "username", sortable: true },
    { name: "Celular", field: "email", sortable: true },
  ];

  useEffect(() => {
    const getData = () => {
      showLoader();

      fetch("https://jsonplaceholder.typicode.com/users")
        .then((response) => response.json())
        .then((json) => {
          hideLoader();
          setUsers(json);
        });
    };
    getData();
  }, []);

  const usersData = useMemo(() => {
    let computedUsers = users;

    if (search) {
      computedUsers = computedUsers.filter(
        (usuario) =>
          usuario.name.toLowerCase().includes(search.toLowerCase()) ||
          usuario.email.toLowerCase().includes(search.toLowerCase()) ||
          usuario.username.toLowerCase().includes(search.toLowerCase())
      );
    }
    setTotalItems(computedUsers.length);

    // sorting users
    if (sorting.field) {
      const reversed = sorting.order === "asc" ? 1 : -1;
      computedUsers = computedUsers.sort(
        (a, b) => reversed * a[sorting.field].localeCompare(b[sorting.field])
      );
    }

    // currente page slice
    return computedUsers.slice(
      (currentPage - 1) * ITEMS_PER_PAGE,
      (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
    );
  }, [users, currentPage, search, sorting]);

 
  return (
    <Container2>
      <div className="card">
        <div className="row w-100">
          <div className="col mb-3 col-12 text-center">
            <div className="row">
              <div className="col-md-6 mb-2">
                <Search
                  onSearch={(value) => {
                    setSearch(value);
                    setCurrentPage(1);
                  }}
                />
              </div>
              <div className="col-md-6 d-flex flex-row">
                <Botao color={"#7136F6"} large={"8vw"} >
                  Pesquisar
                </Botao>
                <Botao color={"#727B84"} large={"7vw"}>
                  Exportar
                </Botao>
                <Botao color={"#0C85E2"} large={"6vw"} onClick={() => {window.location.href = '/modal'}}>
                  Adicionar
                </Botao>
                <Botao color={"#6EBBF7"} large={"5vw"}>
                  Editar
                </Botao>
                <Botao color={"#FD6588"} large={"5vw"}>
                  Excluir
                </Botao>
              </div>
             
            </div>

            <table className="table table-striped">
              <Header
                headers={headers}
                onSorting={(field, order) => setSorting({ field, order })}
              />
              <tbody>
                {usersData.map((user) => (
                  <tr>
                    <th scope="row" key={user.id}>
                      {user.id.toString()}
                    </th>
                    <td>{user.name}</td>
                    <td>{user.username}</td>
                    <td>{user.email}</td>
                  </tr>
                ))}
              </tbody>
              
            </table>
            <div className="col-md d-flex flex-row-reverse">
                <Pagination
                  total={totalItems}
                  itemsPerPage={ITEMS_PER_PAGE}
                  currentPage={currentPage}
                  onPageChange={(page) => setCurrentPage(page)}
                />
              </div>
          </div>
        </div>
        {loader}
      </div>
    </Container2>
  );
};

function Motorista() {
  return (
    <Layout>
      <Container>
        <div className="header">
          <div className="icon">{<CgFileDocument />}</div>
          <h1 className="descricao">
            <span>Motoristas</span> Listagem
          </h1>
        </div>
        <div className="card">{<DataTable />}</div>
      </Container>
    </Layout>
  );
}
export default Motorista;
