import Layout from "../../Components/Layout";

function Home() {
  return (
    <>
      <Layout>

        
      </Layout>
    </>
  );
}
export default Home;
