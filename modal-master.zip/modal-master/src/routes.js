import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./Pages/Home";
import Motorista from "./Pages/Cadastros/Motorista"
import Modal from "./Components/Modal";

 
export const Rotas = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/motorista" element={<Motorista />} />
        <Route path="/modal" element={<Modal />} />
      </Routes>
    </BrowserRouter>
  );
};
