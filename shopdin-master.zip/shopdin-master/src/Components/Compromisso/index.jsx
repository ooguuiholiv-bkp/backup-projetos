import React from "react";

import Peoples from "../../Assets/img1.png";
import Logo from "../../Assets/logo.png";

import styled from "styled-components";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;

    .images {
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 40vw;
      .peoples {
        padding-top: 2rem;
        width: 100%;
      }
      .logo {
        width: 35%;
      }
    }
    .text {
      width: 40vw;
      padding-left: 6rem;
      padding-top: 4rem;
      color: blue;
      .title {
        font-size: 4rem;
        text-transform: uppercase;
      }
      .textContent {
        margin-top: 1.5rem;
        font-size: 1.85rem;
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;

    .images {
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 40vw;
      .peoples {
        padding-top: 2rem;
        padding-left: 2rem;
        width: 100%;
      }
      .logo {
        padding-left: 2rem;
        width: 35%;
      }
    }
    .text {
      width: 60vw;
      padding-left: 4rem;
      padding-top: 4rem;
      color: blue;
      .title {
        font-size: max(3rem, 22px);
        text-transform: uppercase;
      }
      .textContent {
        margin-top: 1rem;
      }
    }
  }
  @media screen and (max-width: 767px) {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column-reverse;
    justify-content: center;

    .images {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      width: 100%;
      .peoples {
        padding-top: 2rem;
        padding-right: 2rem;
        width: 40%;
      }
      .logo {
        padding-right: 2rem;
        width: 20%;
      }
    }
    .text {
      width: 60vw;
      padding-left: 6rem;
      padding-top: 4rem;
      color: blue;
      .title {
        font-size: 2rem;
        text-transform: uppercase;
      }
      .textContent {
        margin-top: 1rem;
      }
    }
  }
`;

export const NossoCompromisso = () => {
  return (
    <>
      <Container id="about">
        <section className="images">
          <img src={Peoples} className="peoples" alt="" />
          {/* <img src={Logo} alt="" className="logo" /> */}
        </section>
        <section className="text">
          <h1 className="title">No Shopdin Tem, Quem Tem Economiza</h1>
          <p className="textContent">
            O Shopdin é o marketeplace do comércio local e conectar pessoas à
            economia de tempo e dinheiro é o que acreditamos. Ajudamos
            vendedores, compradores, Ong´s locais se conectar em uma plataforma
            digital simplificando o dia a dia no varejo é nossa missão.
          </p>
        </section>
      </Container>
    </>
  );
};
