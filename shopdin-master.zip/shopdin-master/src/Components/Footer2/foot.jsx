import React from 'react'
import styled from 'styled-components'

export const Container = styled.footer`
@media screen and (min-width: 1024px){
  
width: 100%;
height: 10vh;
background-color: #ff6600;
display: flex;
justify-content: center;
align-items: center;
p{
  color: white;
}
}
@media screen and (min-width: 768px) and (max-width: 1023px) {
  
width: 100%;
height: 10vh;
background-color: #ff6600;
display: flex;
justify-content: center;
align-items: center;
p{
  color: white;
}
  
}
@media screen and (max-width: 767px) {
visibility: hidden;
width: 100%;
height: 0%;
background-color: black;
display: flex;
justify-content: center;
align-items: center;
p{
  color: white;
} 
}
`
export const Foot = () => {
  return(
    <>
    <Container>
      <p>&copy;2022 Shopdin - Todos os direitos reservados. CNPJ 17.361.198/0001-31</p>
    </Container>
    </>
  )
}