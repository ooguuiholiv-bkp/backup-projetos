import React from "react";
import { OptionsData } from "../../Services/Options";
import styled from "styled-components";
import { Link } from "react-router-dom";

export const Container = styled.div`
@media screen  and (min-width: 1024px){
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  .text {
    text-align: center;
  }
  .title {
    padding-top: 0.8rem;
    text-transform: uppercase;
    font-size: 1.4rem;
    color: blue;
  }
}
@media screen and (min-width: 768px) and (max-width: 1023px) {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  .text {
    text-align: center;
  }
  .title {
    padding-top: 0.8rem;
    text-transform: uppercase;
    font-size: 1.4rem;
    color: blue;
  }
}
@media screen and (max-width: 767px){
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 2rem;
  .text {
    text-align: center;
  }
  .title {
    padding-top: 0.8rem;
    text-transform: uppercase;
    font-size: 1.4rem;
    color: blue;
  }
}
`;

export const OptionsList = styled.ul`
  @media screen and (min-width: 1024px) {
    margin-top: 5rem;
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    column-gap: 2rem;
    row-gap: 3rem;
    
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    margin-top: 5rem;
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    column-gap: 2rem;
    row-gap: 3rem;
  }
  @media screen and (max-width: 767px){
    margin-top: 3rem;
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    column-gap: 2rem;
    row-gap: 3rem;
  }
`;

export const Option = styled.li`
@media screen and (min-width: 1024px) {
  
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 200px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
    text-align: center;
  }
  
}
@media screen and (min-width: 768px) and (max-width: 1023px) {
  
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 150px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
    text-align: center;
  }
}
@media screen and (max-width: 767px){
  
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 100px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
    text-align: center;
  }
  
}
`;

export const Options = () => {
  return (
    <>
      <Container>
        <div className="text">
          <h1 className="title">Clique e conheça seu comércio local!</h1>
        </div>
        <div className="content">
          <OptionsList>
            {OptionsData.map((o) => {
              return (
                <Option key={o.id}>
                  {/* <Link to={''}> */}
                  <a>
                    <img src={o.img} alt="" />
                    <p>{o.title}</p>
                  </a>
                  {/* </Link> */}
                </Option>
              );
            })}
          </OptionsList>
        </div>
      </Container>
    </>
  );
};
