import { Link } from "@mui/material";
import React, { useState } from "react";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Logo from "../../Assets/logo2.png";
import styled from "styled-components";
import * as RiIcons from "react-icons/ri";

export const HeaderContent = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100%;
    height: 5em;
    background-color: #ff6600;
    text-transform: uppercase;
    font-size: 1.2rem;
    display: flex;
    justify-content: space-evenly;
    align-items: center;

    img {
      width: 10vw;
    }
    Button {
      color: #ff6600;
      border-color: white;
      background: white;
      font-size: 1.2rem;
      font-weight: bold;

    }
    Button:hover{
      color: #ff6600;
      border-color: white;
      background: white;
      font-size: 1.2rem;
    }
    .btn-login {
      href {
        text-decoration: none;
        color: white;
        
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100%;
    height: 15vh;
    background-color: #ff6600;
    text-transform: uppercase;
    font-size: max(0.8rem, 12px);
    display: flex;
    justify-content: space-evenly;
    align-items: center;

    img {
      width: 12vw;
    }
    Button {
      color: #ff6600;
      border-color: white;
      background: white;
      width: 14vw;
      font-size: max(0.8rem, 12px);
    }
    Button:hover{
      color: #ff6600;
      border-color: white;
      background: white;
      width: 14vw;
      font-size: max(0.8rem, 12px);
    }
  }

  @media screen and (max-width: 767px) {
    display: none;
    width: 100%;
    height: 35vh;
    background-color: #ff6600;
    text-transform: uppercase;
    font-size: max(0.8rem, 12px);

    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    text-align: center;
    row-gap: 0.3rem;

    img {
      width: 14vw;
    }
    Button {
      color: #ff6600;
      border-color: white;
      background: white;
      width: 35vw;
      font-size: max(0.5rem, 12px);
      margin-bottom: 2rem;
    }
  }
`;

export const NavBar = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <HeaderContent>
      <img src={Logo} alt="logo" />
      <Link href="#inicio" color={"white"} underline="none">
        Início
      </Link>
      {/* <Link
        style={{ cursor: "pointer" }}
        color={"white"}
        underline="none"
        id="basic-button"
        aria-controls={open ? "basic-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
      >
        Comunidade <RiIcons.RiArrowDownSFill />
      </Link> */}
      
      {/* <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{ "aria-labelledby": "basic-button" }}
      >
        <MenuItem onClick={handleClose}>opcao1</MenuItem>
        <MenuItem onClick={handleClose}>opcao2</MenuItem>
        <MenuItem onClick={handleClose}>opcao3</MenuItem>
        <MenuItem onClick={handleClose}>opcao4</MenuItem>
      </Menu> */}
      <Link href="#about" color={"white"} underline="none">
        Sobre a Shopdin
      </Link>
      <Link href="#benf" color={"white"} underline="none">
        Nosso Compromisso
      </Link>
      <Link href="#transparencia" color={"white"} underline="none">
        Transparência
      </Link>
      <Link href="#parceiros" color={"white"} underline="none">
        Comunidade
      </Link>
      <Link href="https://www.shopdin.com.br/" color={"white"} underline="none">
        <Button className="btn-login" variant="outlined">
          Faça seu pedido
        </Button>
      </Link>
    </HeaderContent>
  );
};
