import React from "react";
import styled from "styled-components";
import FundoCep from "../../Assets/FundoCep.png";
import ManShopdin from "../../Assets/manShopdin.png";

export const Carrousel = styled.div`
  @media screen and (min-width: 1024px) {
    height: 100%;
    width: 100%;
    background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.2)),
      url(${FundoCep});
    background-position: center;
    background-size: 150%;
    margin-top: 0;
    display: flex;
    justify-content: center;
    align-items: center;

    .title {
      color: white;
      text-transform: uppercase;
      font-size: 2rem;
      font-family: "Inter", sans-serif;
      font-weight: 900;
    }
    .subtitle {
      margin-top: 1.8rem;
      color: white;
      text-transform: uppercase;
    }
    form {
      margin-top: 1rem;
    }
    form .uf {
      width: 5vw;
      height: 5vh;
      border: none;
      border-radius: 0.5rem;
    }
    form .cidade {
      width: 20vw;
      height: 5vh;
      border: none;
      border-radius: 0.5rem;
      margin-left: 0.5rem;
    }
    .text {
      width: 30vw;
    }
    .images {
      width: 30vw;
      img {
        width: 100%;
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    height: 40vh;
    width: 100%;
    background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.2)),
      url(${FundoCep});
    background-position: center;
    background-size: 150%;
    margin-top: 0;
    display: flex;
    justify-content: center;
    align-items: center;

    .title {
      color: white;
      text-transform: uppercase;
      font-size: max(1.4rem, 14px);
      font-family: "Inter", sans-serif;
      font-weight: 900;
    }
    .subtitle {
      margin-top: 1.8rem;
      font-size: max(0.8rem, 12px);
      color: white;
      text-transform: uppercase;
    }
    form {
      margin-top: 1rem;
    }
    form .uf {
      width: 6vw;
      height: 3vh;
      border: none;
      border-radius: 0.5rem;
    }
    form .cidade {
      width: 24vw;
      height: 3vh;
      border: none;
      border-radius: 0.5rem;
      margin-left: 0.5rem;
    }
    .text {
      width: 40vw;
    }
    .images {
      width: 30vw;
      img {
        width: 100%;
      }
    }
  }
  @media screen and (max-width: 767px) {
    height: 40vh;
    width: 100%;
    background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.2)),
      url(${FundoCep});
    background-position: center center;
    background-size: auto;
    margin-top: 0;
    display: flex;
    justify-content: center;
    align-items: center;

    .title {
      color: white;
      text-transform: uppercase;
      font-size: max(1.1rem, 12px);
      font-family: "Inter", sans-serif;
      font-weight: 900;
    }
    .subtitle {
      margin-top: 1.8rem;
      font-size: max(0.7rem, 10px);
      color: white;
      text-transform: uppercase;
    }
    form {
      margin-top: 1rem;
    }
    form .uf {
      width: 6vw;
      height: 3vh;
      border: none;
      border-radius: 0.5rem;
    }
    form .cidade {
      width: 24vw;
      height: 3vh;
      border: none;
      border-radius: 0.5rem;
      margin-left: 0.5rem;
    }
    .text {
      width: 40vw;
    }
    .images {
      width: 30vw;
      img {
        width: 100%;
      }
    }
  }
`;

export const CarrouselCep = () => {
  return (
    <>
      <Carrousel id="inicio">
        <div className="text">
          <h2 className="title">
            O primeiro shopping <br /> do comércio local, <br /> na palma da sua{" "}
            <br /> mão
          </h2>
          {/* <h3 className="subtitle">
            Selecione sua cidade e aproveite as ofertas
          </h3> */}
          {/* <form className="localizacao">
            <input type="" placeholder="UF" name="uf" id="uf" className="uf" />
            <input
              type=""
              placeholder="Cidade"
              name="cidade"
              id="cidade"
              className="cidade"
            />
          </form> */}
        </div>
        <div className="images">
          <img src={ManShopdin} alt="man" />
        </div>
      </Carrousel>
    </>
  );
};
