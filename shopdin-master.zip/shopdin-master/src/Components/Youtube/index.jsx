import React from "react";
import Iphone13 from "../../Assets/iPhone.png";
import styled from "styled-components";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;

    .mockup {
      margin-top: 4rem;
      margin-left: auto;
      margin-right: auto;
      width: 40%;
      img {
        width: 100%;
      }

      .botoes {
        button {
          width: auto;
          height: 5vh;
          font-size: max(0.8rem, 10px);
          margin-left: 0.4rem;
          border-radius: 0.4rem;
          border: none;
        }
      }
    }

    .content {
      
      display: flex;
      flex-direction: column;
      margin-left: auto;
      margin-right: auto;

      .title {
        margin-top: 4rem;
        font-size: 2.2rem;
        text-transform: uppercase;
        font-weight: bold;
        color: blue;
      }
      .youtube-video {
        margin-top: 1.5rem;
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;

    .mockup {
      margin-top: 4rem;
      margin-left: auto;
      margin-right: auto;
      width: 45%;
      img {
        width: 95%;
      }

      .botoes {
        button {
          width: auto;
          height: 5vh;
          font-size: max(0.8rem, 10px);
          margin-left: 0.4rem;
          border-radius: 0.4rem;
          border: none;
        }
      }
    }

    .content {
      display: flex;
      flex-direction: column;
      margin-left: auto;
      margin-right: auto;
      .title {
        padding-top: 4rem;
        font-size: 2.2rem;
        padding-left: 1rem;
        text-transform: uppercase;
        font-weight: bold;
        color: blue;
      }
      .youtube-video {
        padding-top: 1.5rem;
        padding-left: 1rem;
        iframe {
          width: 95%;
          height: 35vh;
        }
      }
    }
  }
  @media screen and (max-width: 767px) {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    

    .mockup {
      margin-top: 2rem;
      width: 45%;
      margin-left: auto;
      margin-right: auto;
      img {
        width: 100%;
      }

      .botoes {
        button {
          
          width: auto;
          font-size: max(0.8rem, 10px);
          height: 5vh;
          margin-left: 0.4rem;
          border-radius: 0.4rem;
          border: none;
        }
      }
    }

    .content {
      display: flex;
      flex-direction: column;
      margin-left: auto;
      margin-right: auto;
      .title {
        padding-top: 4rem;
        font-size: 2.2rem;
        padding-left: 0.6rem;
        text-transform: uppercase;
        font-weight: bold;
        color: blue;
      }
      .youtube-video {
        padding-top: 1.5rem;
        iframe {
          width: 100%;
          height: 30vh;
        }
      }
    }
  }
`;

export const Youtube = () => {
  return (
    <>
      <Container id="transparencia">
        <div className="content">
          <h1 className="title">Veja como é fácil e simples!</h1>
          <div className="youtube-video">
            <iframe
              width={"100%"}
              height={400}
              src="https://www.youtube.com/embed/CtL8IFcWOIw"
              title="YouTube video player"
            ></iframe>
          </div>
        </div>
        <div className="mockup">
          <img src={Iphone13} alt="" />
          <div className="botoes">
            <a href="#">
              <button>PlayStore</button>
            </a>
            <a href="#">
              <button>AppStore</button>
            </a>
          </div>
        </div>
      </Container>
    </>
  );
};
