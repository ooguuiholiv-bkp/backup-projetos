import React from "react";
import styled from "styled-components";
import Logo from "../../Assets/logo.png";
import * as FAicons from "react-icons/fa";
import * as MDicons from "react-icons/md";

export const Container = styled.div`
@media screen and (min-width: 1024px) {
  width: 100%;
  height: 50vh;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding-top: 4rem;
  background-color: #ff6600;
  font-size: 1.4rem;
  hr {
    padding: 0;
    margin: 0;
    color: white;
    border: 2px solid white;
    height: 90%;
  }

  .primary {
    display: flex;
    flex-direction: column;
    width: 30vw;
    .icons{
      display: flex;
      color: white;
      justify-content: center;
      font-size: 1.8rem;
      gap: 2rem;
    }
    .logo {
      width: 45%;
      margin-left: auto;
      margin-right: auto;
    }
  }

  .secondary {
    display: flex;
    flex-direction: column;
    width: 30vw;
    padding-top: 2.5rem;
    h1 {
      color: black;
      text-transform: uppercase;
    }
    ul li {
      text-transform: Capitalize;
      list-style: none;
      color: white;
      padding-top: 0.6rem;
    }
  }
  .tertiary {
    display: flex;
    flex-direction: column;
    padding-top: 2.5rem;
    width: 30vw;
    h1 {
      color: black;
      text-transform: uppercase;
    }
    ul li {
      text-transform: Capitalize;
      list-style: none;
      color: white;
      padding-top: 0.6rem;
    }
  }
}
@media screen and (min-width: 768px) and (max-width: 1023px){
  width: 100%;
  height: 40vh;
  display: flex;
  justify-content: space-around;
  padding-top: 4rem;
  background-color: #ff6600;
  font-size: max(1.2rem, 14px);
  hr {
    
    padding: 0;
    margin: 0;
    color: white;
    border: 2px solid white;
    height: 90%;
  }

  .primary {
    display: flex;
    flex-direction: column;
    width: 30vw;
    .icons{
      display: flex;
      justify-content: center;
      font-size: max(1.8rem, 15px);
      gap: 1rem;
      color: white;
    }
    .logo {
      width: 45%;
      margin-left: auto;
      margin-right: auto;
    }
  }

  .secondary {
    display: flex;
    flex-direction: column;
    width: 30vw;
    padding-top: 2.5rem;
    h1 {
      text-transform: uppercase;
      color: black;
    }
    ul li {
      text-transform: Capitalize;
      list-style: none;
      color: white;
      padding-top: 0.6rem;
    }
  }
  .tertiary {
    display: flex;
    flex-direction: column;
    padding-top: 2.5rem;
    width: 30vw;
    h1 {
      text-transform: uppercase;
      color: black;
    }
    ul li {
      text-transform: Capitalize;
      list-style: none;
      color: white;
      padding-top: 0.6rem;
    }
  }
}
@media screen and (max-width: 767px) {
  visibility: hidden;
  width: 100%;
  height: 0%;
  display: flex;
  justify-content: space-around;
  padding-top: 4rem;

  font-size: max(0.8rem, 12px);
  hr {
    padding: 0;
    margin: 0;
    color: red;
    border: 2px solid red;
    height: 90%;
  }

  .primary {
    display: flex;
    flex-direction: column;
    width: 30vw;
    .icons{
      display: flex;
      flex-direction: column;
      margin-left: 5rem;
      font-size: max(1rem, 10px);
      row-gap: 0.6rem;
    }
    .logo {
      width: 45%;
      margin-left: auto;
      margin-right: auto;
    }
  }

  .secondary {
    display: flex;
    flex-direction: column;
    text-transform: uppercase;
    width: 30vw;
    padding-top: 2.5rem;
    h1 {
      color: red;
    }
    ul li {
      list-style: none;
      color: blue;
      padding-top: 0.6rem;
    }
  }
  .tertiary {
    display: flex;
    flex-direction: column;
    padding-top: 2.5rem;
    width: 30vw;
    text-transform: uppercase;
    h1 {
      color: red;
    }
    ul li {
      list-style: none;
      color: blue;
      padding-top: 0.6rem;
    }
  }
}
  
`;

export const Footer = () => {
  return (
    <>
      <Container>
        <div className="primary">
          <img src={Logo} alt="logo" className="logo" />
          <div className="icons">
            <FAicons.FaInstagram />
            <FAicons.FaFacebook />
            <FAicons.FaTwitter />
            <FAicons.FaTiktok />
            <MDicons.MdEmail />
          </div>
        </div>
        <hr />
        <div className="secondary">
          <h1>institucional</h1>
          <ul>
            <li>início</li>
            <li>faça seu pedido</li>
            <li>sobre a shopdin</li>
            <li>comunidade</li>
            <li>nosso compromisso</li>
            <li>transparencia</li>
          </ul>
        </div>
        <hr />
        <div className="tertiary">
          <h1>nossos canais</h1>
          <ul>
            <li>instagram</li>
            <li>facebook</li>
            <li>twitter</li>
            <li>tiktok</li>
            <li>e-mail</li>
            <li>site institucional</li>
          </ul>
        </div>
      </Container>
    </>
  );
};
