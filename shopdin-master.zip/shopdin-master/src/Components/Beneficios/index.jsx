import React from "react";
import styled from "styled-components";
import Fundo from "../../Assets/fundo.png";
import { BeneficiosData } from "../../Services/Beneficios";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    width: 100%; 
    height: 100vh;
    background: url(${Fundo});
    display: flex;
    flex-direction: column;
    .text {
      text-transform: uppercase;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 12rem;
      color: white;
    }
    .text .title {
      font-size: 2.2rem;
    }
    .text .subtitle {
      font-size: 2rem;
    }
    hr{
      opacity: 0;
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100%;
    height: 95vh;
    background: url(${Fundo});
    display: flex;
    flex-direction: column;
    .text {
      text-transform: uppercase;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 12rem;
      color: white;
    }
    .text .title {
      font-size: max(1.6rem, 16px);
    }
    .text .subtitle {
      font-size: max(1.4rem, 14px);
    }
    hr{
      opacity: 0;
    }
  }
  @media screen and (max-width: 767px) {
    width: 100%;
    height: 92vh;
    background: url(${Fundo});
    display: flex;
    flex-direction: column;
    .text {
      text-transform: uppercase;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 12rem;
      color: black;
    }
    .text .title {
      font-size: max(1.1rem, 16px);
      text-align: center;
    }
    .text .subtitle {
      font-size:  max(0.9rem, 14px);
      text-align: center;
    }
  }
`;

export const BeneficiosList = styled.ul`
@media screen and (min-width: 1024px) {
  margin-top: 5rem;
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  column-gap: 2rem;
  row-gap: 3rem;
}
 @media screen and (min-width: 768px) and (max-width: 1023px) {
  margin-top: 5rem;
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  column-gap: 2rem;
  row-gap: 3rem;
 }
 @media screen and (max-width: 767px){
  margin-top: 5rem;
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  column-gap: 2rem;
  row-gap: 3rem;
 }
`;

export const Benef = styled.li`
@media screen and (min-width: 1024px) {
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 200px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: white;
    text-transform: capitalize;
    text-align: center;
  }
}
@media screen and (min-width: 768px) and (max-width: 1023px) {
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 200px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
    text-align: center;
    font-size: 0.8rem;
  }
}
 @media screen and (max-width: 767px) {
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 150px;
    border-radius: 15%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    transition: all 0.4s;
    text-decoration: none;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
    text-align: center;
    font-size: 0.8rem;
  }
 }
`;

export const Beneficios = () => {
  return (
    <>
      <Container id="benf">
        <section className="text">
          <h1 className="title">
            Melhor que comprar é comprar com benefícios!
          </h1>
          <h2 className="subtitle">em toda compra na shopdin você:</h2>
        </section>
        <section className="images">
          <BeneficiosList>
            {BeneficiosData.map((b) => {
              return (
                <Benef key={b.id}>
                  <img src={b.img} alt="" />
                  <p>{b.title}</p>
                </Benef>
              );
            })}

          </BeneficiosList>
          {/* <hr /> */}
        </section>
       
      </Container>
    </>
  );
};
