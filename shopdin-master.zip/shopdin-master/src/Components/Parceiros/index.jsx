import React from "react";
import styled from "styled-components";
import Moto from "../../Assets/entregador.png";
import Parceiro from "../../Assets/parceiro.png";
import Franqueado from "../../Assets/franqueado.png";
import Lojista from "../../Assets/lojista.png";
export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    overflow: hidden;
    width: 100%;
    height: 100%;

    .title {
      text-align: center;
      text-transform: uppercase;
      font-size: 2.2rem;
      color: blue;
      padding-top: 2rem;
    }

    .cards {
      display: flex;
      flex-direction: column;
      width: 85%;
      margin-left: auto;
      margin-right: auto;
      padding-top: 2rem;

      .primary {
        width: 95vw;
        display: flex;
        justify-content: center;
        align-items: center;

        .one {
          width: 30vw;
          padding-top: 0.6rem;

          img {
            width: 80%;
          }
        }

        .two {
          width: 30vw;

          img {
            width: 80%;
          }
        }
      }
      .secondary-img {
        width: 93vw;
        display: flex;
        justify-content: center;
        align-items: center;
        .three {
          width: 30vw;
          padding-top: 0.6rem;
          img {
            width: 90%;
          }
        }
        .four {
          width: 30vw;
          padding-top: 0.6rem;
          img {
            width: 90%;
          }
        }
      }
    }
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    width: 100%;
    height: 100%;

    .title {
      text-align: center;
      text-transform: uppercase;
      font-size: max(2rem, 16px);
      color: blue;
      padding-top: 2rem;
    }

    .cards {
      display: flex;
      flex-direction: column;
      width: 90%;
      margin-left: auto;
      margin-right: auto;
      padding-top: 2rem;

      .primary {
        width: 95vw;
        display: flex;
        justify-content: center;
        align-items: center;

        .one {
          width: 30vw;
          padding-top: 0.6rem;

          img {
            width: 100%;
          }
        }

        .two {
          width: 30vw;

          img {
            width: 100%;
          }
        }

      }
      .secondary-img {
        width: 95vw;
        display: flex;
        justify-content: center;
        align-items: center;
        .three {
          width: 32vw;
          padding-top: 0.6rem;
          img {
            width: 100%;
          }
        }
        .four {
          width: 32vw;
          padding-top: 0.6rem;
          img {
            width: 100%;
          }
        }
      }
    }
  }
  @media screen and (max-width: 767px) {
    width: 100%;
    height: 100%;

    .title {
      text-align: center;
      text-transform: uppercase;
      font-size: max(1.3rem, 12px);
      color: blue;
      padding-top: 2rem;
    }

    .cards {
      display: flex;
      flex-direction: column;
      width: 90%;
      margin-left: auto;
      margin-right: auto;
      padding-top: 2rem;

      .primary {
        width: 95vw;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;

        .one {
          width: 80vw;
          padding-top: 0.6rem;

          img {
            width: 100%;
          }
        }

        .two {
          width: 80vw;

          img {
            width: 100%;
          }
        }

      }
      .secondary-img {
        width: 95vw;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        .three {
          width: 90vw;
          padding-top: 0.6rem;
          img {
            width: 100%;
          }
        }
        .four {
          width: 90vw;
          padding-top: 0.6rem;
          img {
            width: 100%;
          }
        }
      }
    }
  }
`;

export const Parceiros = () => {
  return (
    <>
      <Container id="parceiros">
        <div className="content">
          <h1 className="title">Faça parte da nossa comunidade!</h1>
          <div className="cards">
            <div className="primary">
            <div className="one">
                <a href="#">
                  <img src={Lojista} alt="franqueado" />
                </a>
              </div>
              <div className="two">
                <a href="#">
                  <img src={Parceiro} alt="parceiro" />
                </a>
              </div>
            </div>
            <div className="secondary-img">
              <div className="three">
                <a href="#">
                  <img src={Franqueado} alt="franqueado" />
                </a>
              </div>
              
              <div className="four">
                <a href="#">
                  <img src={Moto} alt="entregador" />
                </a>
              </div>
            </div>
            <div className="secondary"></div>
          </div>
        </div>
      </Container>
    </>
  );
};
