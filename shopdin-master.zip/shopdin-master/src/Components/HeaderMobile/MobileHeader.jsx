import React, { useState, useEffect } from "react";
import styled from "styled-components";

export const Container = styled.div`
  @media screen and (min-width: 1024px) {
    display: none;
  }
  @media screen and (min-width: 768px) and (max-width: 1023px) {
    display: none;
  }
  @media screen and (max-width: 767px) {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 10vh;
    bottom: 0;
    position: fixed;
    width: 100%;
    text-align: center;

    .navigation {
      width: 100%;
      height: 10vh;
      background-color: #d8d8d8;
      position: fixed;
      bottom: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      border-top-left-radius: 0.8rem;
      border-top-right-radius: 0.8rem;
    }
    .navigation ul {
      display: flex;
      width: 95%;
    }
    .navigation ul li {
      position: relative;
      list-style: none;
      width: auto;
      margin: auto;
      z-index: 1;
    }
    .navigation ul li a {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      width: 100%;
      text-align: center;
      font-weight: 500;
      text-transform: uppercase;
    }
    .navigation ul li a .icon {
      position: relative;
      display: block;
      line-height: 75px;
      font-size: 1.8em;
      text-align: center;
      transition: 0.5s;
      color: #222327;
    }
    /* .navigation ul li.active a .icon{
      transform: translateY(-36px);
    } */
    .navigation ul li a .text {
      position: absolute;
      color: #222327;
      font-weight: 400;
      font-size: 0.55em;
      letter-spacing: 0.05em;
      transition: 0.5s;
      opacity: 0;
      transform: translateY(20px);
    }
    .navigation ul li.active a .text {
      opacity: 1;
      transform: translateY(20px);
    }
    /* .indicator{
      position: absolute;
      top: -40%;
      width: 50px;
      height: 50px;
      background: #E48C4B;
      border-radius: 50%;
      border: 6px solid #ffffff;
      transition: 0.5s;
    }
    .indicator::before{
      content: '';
      position: absolute;
      top: 53%;
      left: -11px;
      width: 0.45em;
      height: 0.45em;
      background: transparent;
      border-top-right-radius: 20px;
      box-shadow: 0px -0.28em 0px 0px #fff;
    }
    .indicator::after{
      content: '';
      position: absolute;
      top: 53%;
      right: -14px;
      width: 10px;
      height: 10px;
      background: transparent;
      border-top-left-radius: 25px;
      box-shadow: 0px -0.28em 0px 0px #fff;
    } */
  }
`;

export const MobileHeader = () => {
  const [active, setActive] = useState([]);

  useEffect(() => {
    const listItem = document.querySelectorAll(".list");
    function activeLink() {
      listItem.forEach((item) => item.classList.remove("active"));
      this.classList.add("active");
      setActive();
    }
    listItem.forEach((item) => item.addEventListener("click", activeLink));
  }, [active]);
  return (
    <>
      <Container>
        <div className="navigation">
          <ul>
            <li className="list active">
              <a href="#inicio">
                <span className="icon">
                  <ion-icon name="home-outline"></ion-icon>
                </span>
                <span className="text">Inicio</span>
              </a>
            </li>
            <li className="list">
              <a href="#about">
                <span className="icon">
                  <ion-icon name="information-outline"></ion-icon>
                </span>
                <span className="text">Sobre</span>
              </a>
            </li>
            <li className="list">
              <a href="#benf">
                <span className="icon">
                  <ion-icon name="megaphone-outline"></ion-icon>
                </span>
                <span className="text">Compromisso</span>
              </a>
            </li>
            <li className="list">
              <a href="#transparencia">
                <span className="icon">
                  <ion-icon name="contrast-outline"></ion-icon>
                </span>
                <span className="text">Transparencia</span>
              </a>
            </li>
            <li className="list">
              <a href="#parceiros">
                <span className="icon">
                  <ion-icon name="people-outline"></ion-icon>
                </span>
                <span className="text">Comunidade</span>
              </a>
            </li>
            <li className="list">
              <a href="https://www.shopdin.com.br/">
                <span className="icon">
                  <ion-icon name="log-in-outline"></ion-icon>
                </span>
                <span className="text">Login</span>
              </a>
            </li>
            <div className="indicator"></div>
          </ul>
        </div>
      </Container>
    </>
  );
};
