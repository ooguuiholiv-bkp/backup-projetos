import Cashback from '../../Assets/cashback.png'
import ISocial from '../../Assets/iSocial.png'
import FComercio from '../../Assets/fComercio.png'

export const BeneficiosData = [
  {
    id: 1,
    title: 'GANHA CASHBACK',
    img: (Cashback)
  },
  {
    id: 2,
    title: 'AJUDA UMA INSTITUIÇÃO SOCIAL LOCAL',
    img: (ISocial)
  },
  {
    id: 3,
    title: 'FORTALECE O COMÉRCIO LOCAL',
    img: (FComercio)
  },
]