import Restaurantes from "../../Assets/restaurantes.png";
import Mercado from "../../Assets/mercado.png";
import Padaria from "../../Assets/padaria.png";
import Farmacia from "../../Assets/farmacia.png";
import Calcados from "../../Assets/calcados.png";
import Oticas from "../../Assets/otica.png";
import Cosmeticos from "../../Assets/cosmeticos.png";
import More from "../../Assets/more.png";
export const OptionsData = [
  {
    id: 1,
    title: "RESTAURANTES",
    img: Restaurantes,
    path: "/restaurantes",
  },
  {
    id: 2,
    title: "MERCADO",
    img: Mercado,
    path: "/mercado",
  },
  {
    id: 3,
    title: "PADARIA",
    img: Padaria,
    path: "/padaria",
  },
  {
    id: 4,
    title: "FARMÁCIA",
    img: Farmacia,
    path: "/farmacia",
  },
  { id: 5, title: "CALÇADOS", img: Calcados, path: "/calcados" },
  {
    id: 6,
    title: "ÓTICAS",
    img: Oticas,
    path: "/oticas",
  },
  {
    id: 7,
    title: "COSMÉTICOS",
    img: Cosmeticos,
    path: "/cosmeticos",
  },
  {
    id: 8,
    title: "E MUITO MAIS!",
    img: More,
    path: "/more",
  },
];
