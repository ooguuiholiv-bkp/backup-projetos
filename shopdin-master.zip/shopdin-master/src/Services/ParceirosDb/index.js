// Lista de funções dos parceiros

import Moto from '../../Assets/moto.png'
import Note from '../../Assets/note.png'
import Pasta from '../../Assets/pasta.png'


export const DBParceiros = [
  {
    id: 1,
    funcao: 'ENTREGADOR',
    descricao: 'lorem ipsum',
    img: (Moto)
  },
  {
    id: 2,
    funcao: 'PARCEIRO',
    descricao: 'lorem ipsum',
    img: (Note)
  },
  {
    id: 3,
    funcao: 'FRANQUEADO',
    descricao: 'lorem ipsum',
    img: (Pasta)
  },
  {
    id: 4,
    funcao: 'ENTREGADOR',
    descricao: 'lorem ipsum',
    img: (Moto)
  },
  {
    id: 5,
    funcao: 'PARCEIRO',
    descricao: 'lorem ipsum',
    img: (Note)
  },
  {
    id: 6,
    funcao: 'FRANQUEADO',
    descricao: 'lorem ipsum',
    img: (Pasta)
  },
]