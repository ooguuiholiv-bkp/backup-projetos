import React from "react";
import { Beneficios } from "../../Components/Beneficios";
import { CarrouselCep } from "../../Components/Carrousel";
import { NossoCompromisso } from "../../Components/Compromisso";
import { Footer } from "../../Components/Footer";
import { Foot } from "../../Components/Footer2/foot";
import { NavBar } from "../../Components/Header";
import { MobileHeader } from "../../Components/HeaderMobile/MobileHeader";
import { Options } from "../../Components/Options";
import { Parceiros } from "../../Components/Parceiros";
import { Youtube } from "../../Components/Youtube";


export const Home = () => {
  return (
    <>
     <NavBar />
     <MobileHeader />
     <CarrouselCep />
     <Options />
     <NossoCompromisso />
     <Beneficios />
     <Youtube />
     <Parceiros />
     <Footer />
     <Foot />
    </>
  );
};
