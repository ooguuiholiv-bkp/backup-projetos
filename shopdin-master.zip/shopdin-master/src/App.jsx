import { Home } from "./Pages/Home";

export const App = () => {
  return (<>
  <Home />
  </>
  );
};
