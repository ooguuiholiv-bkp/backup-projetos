# Site desenvolvido para a Shopdin.com.br

## Lista de To-Do

-[ x ] NavBar

-[ x ] Carroussel

-[ x ] Form de Dados de localização

-[ x ] 8 Buttons "Clique e conheça seu comércio local"

-[ x ] Algo que fale da valorização Local = lorem ipsum "Sobre"

-[ x ] Beneficios de comprar com a Shopdin

-[ x ] YT video + Mockup

-[ x ] Faça parte da nossa Comunidade

-[ x ] Rodapé


## Entenda o projeto

-[ x ] Aicionar links ao id
-[ x ] Textos dos parceiros
-[   ] Criar Formularios campos parceiros -> Criar formularios com box
-[   ] Barra de Navegação Mobile

Entregador: 
Parceiro: 
Franqueado: 
Lojistas: 