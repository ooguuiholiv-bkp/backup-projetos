import React from "react";
import "./styles.scss";

import { Container } from "../SignIn/styles";
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";

import { TextAll } from "../../components/Text";
import { Input } from "../../components/Input";
import { Button } from "reactstrap";



export const CheckCode: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="CheckCodeArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <TextAll id="checkTxt" className="checkTxt" text="Informe o código enviado em seu e-mail" />
          <div className="codeArea">
            <Input id="ChCode1" className="code1" placeholder="" type="text" maxLength={1} onChange={() => {
              
            }}/>
            <Input id="ChCode2" className="code2" placeholder="" type="text" maxLength={1}/>
            <Input id="ChCode3" className="code3" placeholder="" type="text" maxLength={1}/>
            <Input id="ChCode4" className="code4" placeholder="" type="text" maxLength={1}/>
            <Input id="ChCode5" className="code5" placeholder="" type="text" maxLength={1}/>
          </div>
          <Button color="primary" id="btnCheck" className="btn-rounded" onClick={() => {
            window.location.href = "/reset"
          }}>Validar código de recuperação</Button>
        </div>
      </Container>
    </div>
  )
}

//TODO Inserir apenas um Input no check Code