import React from "react";
import CodeInput from "../components/InputCode/CodeInput";
import { InputComponent } from "../components/InputComponent/InputComponent";

export const AppInput = () => {
  return (

    <div>
      <CodeInput />
      <InputComponent classNameDiv="form" classNameInput="form__inputEmail" classNameLabel="form__label" type="text" placeholder=" " placeholderLabel="Usuário / E-mail" />
      <InputComponent classNameDiv="form" classNameInput="form__inputPass" classNameLabel="form__labelPass" type="password" placeholder=" " placeholderLabel="Senha" />
    
    </div>
  )
}