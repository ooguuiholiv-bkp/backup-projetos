import React from "react";
import "./styles.scss";

import { Container } from "../SignIn/styles";
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";

import { Button } from "reactstrap";

export const ResetPass: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="ResetArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <div className="form">
            <input
              id="passReset"
              className="form__input"
              type="password"
              placeholder=" "
            />
            <label htmlFor="passReset" className="form__label">
              Nova senha
            </label>
            <input
              id="repeatPassReset"
              className="form__inputRepeat"
              type="password"
              placeholder=" "
            />
            <label htmlFor="repeatPassReset" className="form__labelRepeat">
              Repita a nova senha
            </label>
          </div>
          <Button
            color="primary"
            id="btnReset"
            className="btn-rounded"
            onClick={() => {
              window.location.href = "/login"
            }}
          >
            Salvar nova senha
          </Button>
        </div>
      </Container>
    </div>
  );
};
