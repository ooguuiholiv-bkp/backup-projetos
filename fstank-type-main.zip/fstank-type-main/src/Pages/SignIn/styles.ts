import styled from "styled-components";

export const Container = styled.div`
  display: flex;
  flex-direction: row;
  box-sizing: border-box;
  width: 100%;
  max-width: 1200px;
  height: 100%;
  max-height: 600px;
  background-color: #F6F7FB;
`;