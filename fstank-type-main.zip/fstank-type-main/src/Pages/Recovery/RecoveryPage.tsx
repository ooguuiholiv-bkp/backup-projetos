import React from "react";
// Importando Estilos
import "./styles.scss";
import { Container } from "../SignIn/styles";
// Importando Imagens
import SplashImg from "../../assets/splash.png";
import LogoImg from "../../assets/logo.png";
// Importando os Componentes
import { Button } from "reactstrap";
import { TextAll } from "../../components/Text";
import { useNavigate } from "react-router-dom";


export const RecoveryPage: React.FC = () => {
  return (
    <div>
      <Container>
        <img src={SplashImg} alt="splash" className="SplashImg" />
        <div className="RecoveryArea">
          <img src={LogoImg} alt="logo" className="LogoImg" />
          <TextAll
            text="Informe Seu e-mail de usuário"
            id="txtRecovery"
            className="txtRecovery"
          />
          <div className="form">
            <input
              id="emailRecovery"
              type="text"
              className="form__input"
              placeholder=" "
            />
            <label htmlFor="emailRecovery" className="form__label">
              Usuário / e-Mail
            </label>
          </div>
          <Button
            color="primary"
            id="btnLogin"
            type="button"
            className="btn-rounded"
            onClick={() => {
              function getElement<T extends HTMLElement>(selector: string) {
                const element = document.querySelector<T>(selector);
                if (!element) {
                  throw new Error("O elemento não existe");
                }
                return element;
              }
              const emailField = getElement<HTMLInputElement>("#emailRecovery");
              var email = emailField.value;

              window.location.href = "/verify"
            }}
          >
            Recuperar senha
          </Button>
        </div>
      </Container>
    </div>
  );
};
