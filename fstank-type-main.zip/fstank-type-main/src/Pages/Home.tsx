import React from "react";
import { Link } from "react-router-dom";
import { Navbar, NavItem, NavLink } from "reactstrap";

export const Home = () => {
  return (
    <div>
      <Navbar color="light"
        expand="md"
        light>
        <NavItem>
          <NavLink>
            <Link to="/login">Login</Link>
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink>
            <Link to="/recovery">Recovery</Link>
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink>
            <Link to="/verify">Verify</Link>
          </NavLink>
        </NavItem>
        <NavItem>
        <NavLink>
            <Link to="/check-code">CheckCode</Link>
          </NavLink>
        </NavItem>
        <NavItem>
        <NavLink>
            <Link to="/reset">Reset</Link>
          </NavLink>
        </NavItem>
        <NavItem>
        <NavLink>
            <Link to="/home">Home</Link>
          </NavLink>
        </NavItem>
      </Navbar>
    </div>
  )
}