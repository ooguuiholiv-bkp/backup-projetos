
interface IProps {
  id: string;
  className: string;
  placeholder: string;
  type: string;
  maxLength?: number;
  onChange?: VoidFunction;
}


export const Input = (props: IProps) => {
  const {id, className, placeholder, type, maxLength, onChange} = props;
  return(
    <div>
      <input type={type} id={id} className={className} placeholder={placeholder} maxLength={maxLength} onChange={onChange}></input>
    </div>
  )
}
