import React from "react";
import "./styles.scss";
import {AiOutlineCopyrightCircle} from "react-icons/ai";

export const Footer: React.FC = () => {
  return(
    <div>
      <footer className="rodape">
        <AiOutlineCopyrightCircle/>
        <p>2022 CHROPO</p>
      </footer>
    </div>
  )
}