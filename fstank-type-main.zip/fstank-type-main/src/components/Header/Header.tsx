import React from "react";
import "./styles.scss";
import Avatar1 from "../../assets/images/users/avatar-6.jpg";
import LogoImg from "../../assets/logo.png";
import { IoIosNotificationsOutline } from "react-icons/io";
import { AiTwotoneSetting } from "react-icons/ai";

export const Header: React.FC = () => {
  return (
    <div>
      <header className="cabecalho">
        <div className="logo">
          <img src={LogoImg} alt="logoimg" className="LogoImg" />
        </div>
        <div className="user">
          <img src={Avatar1} alt="USER" className="ImgUsuario" />
        </div>
        <div className="icon">
          <IoIosNotificationsOutline className="iconNotification" />
          <div className="d-inline-block dropdown">
              <AiTwotoneSetting className="iconSettings" />
          </div>
        </div>
      </header>
    </div>
  );
};
