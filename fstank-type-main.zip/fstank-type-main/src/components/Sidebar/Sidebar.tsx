import React from "react";
import "./styles.scss";

export const Sidebar: React.FC = () => {
  return(
    <div>
      <div className="sidebar">
        
      </div>
    </div>
  )
}