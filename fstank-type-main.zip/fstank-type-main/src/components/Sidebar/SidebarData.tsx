import React from 'react'

export const SidebarData = [
  {
    title: "Dashboard",
    link: "/dashboard"
  },
  {
    title: "Analytics",
    link: "/Analytics"
  },
  {
    title: "Tables",
    link: "/Tables"
  },
  {
    title: "Users",
    link: "/Users"
  },
  {
    title: "Cost Center",
    link: "/CostCenter"
  },
  {
    title: "Tank",
    link: "/Tank"
  },
  {
    title: "Copy",
    link: "/paste"
  },
  {
    title: "Copy",
    link: "/paste"
  },
  {
    title: "Copy",
    link: "/paste"
  },
  {
    title: "Copy",
    link: "/paste"
  },
  
]
