interface IProps {
  href?: string;
  id?: string;
  className?: string;
  text?: string;
  onClick?: undefined;

}

export const Hiperlink = (props: IProps) => {
  const {href, id, className, text, onClick} = props;
  return(
    <div>
      <a id={id} className={className} href={href} onClick={onClick}>{text}</a>
    </div>
  )
}