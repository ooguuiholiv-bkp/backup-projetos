import React from "react";
import "./styles.scss";

//TODO Componentizar o input de forma que eu possa utilizar em todas as telas.

interface Iprops {
  id?: string;
  type?: string;
  classNameDiv?: string;
  classNameInput?: string;
  classNameLabel?: string;
  placeholder?: string;
  placeholderLabel?: string;
}


export const InputComponent = (props: Iprops) => {
  const {id, type, classNameDiv, classNameInput,classNameLabel, placeholder, placeholderLabel} = props;
  return(
    <div className={classNameDiv}>
      <input id={id} type={type} className={classNameInput} placeholder={placeholder} />
      <label htmlFor={id} className={classNameLabel}>{placeholderLabel}</label>
    </div>
  )
}