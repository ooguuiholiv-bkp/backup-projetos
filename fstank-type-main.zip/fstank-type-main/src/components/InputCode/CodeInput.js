import React, { useState } from "react";
import ReactDOM from "react-dom";

import InputCode from "./InputCode";

import "./styles.scss";

function CodeInput() {
  const [loading, setLoading] = useState(false);
  return (
    <div className="InputCodeVerify">
      

      <InputCode
        length={6}
        label=""
        loading={loading}
        onComplete={code => {
          setLoading(true);
          setTimeout(() => setLoading(false), 10000);
        }}
      />
    </div>
  );
}
export default CodeInput;