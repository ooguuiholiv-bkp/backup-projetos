import React from "react";
import "./styles.scss";
interface IProps {
  type?: string,
  id?: string,
  className?: string,
  placeholder?: string,
  classNameLabel?: string
}


export const InputPlace = (props: IProps) => {
  const {type, id, className, placeholder, classNameLabel} = props;
  return(
    <div className="form">
      <input type={type} id={id} className={className} placeholder={placeholder}/>
      <label htmlFor={id} className={classNameLabel}></label>
    </div>
  )
}