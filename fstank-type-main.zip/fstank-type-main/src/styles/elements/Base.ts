import { createGlobalStyle, GlobalStyleComponent } from "styled-components";

export const Base = createGlobalStyle`
html, body{
  background-color: #fff;
  display: flex;
  /* align-items: center;
  justify-content: center; */
  min-height: 100vh;
  font-family: 'Public Sans', sans-serif;
}
`;