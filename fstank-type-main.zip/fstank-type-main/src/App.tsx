import React from 'react';
import { MyRoutes } from './route';
import "./assets/scss/theme.scss";

function App() {
  return (
      <MyRoutes />
  );
}

export default App;
