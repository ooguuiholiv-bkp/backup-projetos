import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SignIn } from "./Pages/SignIn/LoginPage";
import { Home } from "./Pages/Home";
import { RecoveryPage } from "./Pages/Recovery/RecoveryPage";
import { VerifyPage } from "./Pages/Verify/VerifyPage";
import { CheckCode } from "./Pages/CheckCode/CheckCode";
import { ResetPass } from "./Pages/Reset/Reset";
import { MainPage } from "./Pages/MainForm/Main";
import { AppInput } from "./Pages/teste";

export const MyRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/login" element={<SignIn />}></Route>
        <Route path="/recovery" element={<RecoveryPage />}></Route>
        <Route path="/verify" element={<VerifyPage/>}></Route>
        <Route path="/check-code" element={<CheckCode/>}></Route>
        <Route path="/reset" element={<ResetPass/>}></Route>
        <Route path="/home" element={<MainPage />}></Route>
        <Route path="/teste" element={<AppInput />}></Route>
      </Routes>
    </BrowserRouter>
  )
}