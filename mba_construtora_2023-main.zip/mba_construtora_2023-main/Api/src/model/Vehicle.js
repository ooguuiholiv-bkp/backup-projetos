const { Model, DataTypes } = require('sequelize');

class Vehicle extends Model {
    static init(sequelize) {
        super.init(
            {
                marca: DataTypes.STRING,
                placa: DataTypes.STRING,
                km: DataTypes.INTEGER,
                frota: DataTypes.STRING
            },
            {
                sequelize,
            }
        );
    }
}

module.exports = Vehicle;
