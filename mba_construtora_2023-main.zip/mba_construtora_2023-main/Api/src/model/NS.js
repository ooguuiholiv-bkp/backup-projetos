const { Model, DataTypes } = require('sequelize');

class NS extends Model {
    static init(sequelize) {
        super.init(
            {
                ns: DataTypes.STRING,
                cliente: DataTypes.STRING,
                cnpj_cliente: DataTypes.STRING,
                cidade: DataTypes.STRING,
                tipo: DataTypes.STRING,
                data_inicio: DataTypes.DATE,
                data_final: DataTypes.DATE,
                situacao: DataTypes.STRING,
                status_cemig: DataTypes.STRING,
                calc_lt: DataTypes.STRING,
                travessia_rod_dnit: DataTypes.STRING,
                travessia_rod_der: DataTypes.STRING,
                parametrizacao: DataTypes.STRING,
                travessia_fca: DataTypes.STRING,
                suprimentos: DataTypes.STRING,
                vistoria: DataTypes.STRING,
                pre_att: DataTypes.STRING,
                devolucao: DataTypes.STRING,
                pendencia: DataTypes.STRING,
                cco: DataTypes.STRING,
                transformadores: DataTypes.STRING,
            },
            {
                sequelize,
            }
        );
    }
}

module.exports = NS;
