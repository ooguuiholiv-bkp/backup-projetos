const dotenv = require('dotenv')
dotenv.config()

module.exports = {
    dialect: process.env.DIALECT,
    host: process.env.HOST_DB_LOCAL,
    username: process.env.USER_DB_LOCAL,
    password: process.env.PASSWORD_DB_LOCAL,
    database: process.env.BANK_DB_LOCAL,
    dialectModule: require('mysql2'),
    port: process.env.PORT_DB_LOCAL,
    define: {
        timestamp: true,
        underscored: true,
    }
}
