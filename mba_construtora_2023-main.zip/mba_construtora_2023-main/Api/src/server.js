const App = require("./app");
const dotenv = require('dotenv');
dotenv.config();
const cors = require('cors')

const Port = process.env.PORT

App.use(cors)

App.listen(Port, (err) => {
    if (err){
        console.log('Ops, algo não me parece bem...')
    } else {
        console.log(`O servidor está rodando em http://localhost:${Port}`)
    }
})
