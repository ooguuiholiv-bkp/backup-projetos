const { UUIDV4, where } = require('sequelize');
const User = require('../model/User');
const {hash} = require('bcrypt')
const uuid = require('uuid')

module.exports = {
    async CreateUser(req, res) {
        try {
            const {
                first_name,
                last_name,
                cpf_cnpj,
                username,
                email,
                password,
                is_client,
                is_employee
            } = req.body;
            const user = await User.findOne({ where: { email } })
            if (user) {
                return res.status(401).json({
                    message:
                        'Já existe um usuário com este e-mail cadastrado em nosso sistema!',
                });
            } else {
                const passwordHashed = await hash(password, 8)
                const criarUsuario = await User.create({
                    id: uuid.v4(),
                    first_name,
                    last_name,
                    cpf_cnpj,
                    username,
                    email,
                    password: passwordHashed,
                    is_client,
                    is_employee
                });
                res.status(200).json({ criarUsuario });
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },

    async userUpdate(req, res){
        try{
            const {id} = req.params;
            const {password, first_name, last_name, cpf_cnpj, username, is_client, is_employee} = req.body;
            const hashedPassword = await hash(password, 8)
            const user = await User.findOne({where: {id}})
            if (!user){
                res.status(401).json({message: "Nenhum usuário encontrado"})
            } else {

                const user = await User.update({password: hashedPassword, first_name, last_name, cpf_cnpj, username, is_client, is_employee},{where: {id}})
                res.status(200).json({user})
            }
        } catch (err) {
            res.status(400).json({err})
        }
    },

    async listUsers(req, res){
        try {
            const users = await User.findAll()
            if(!users){
                res.status(401).json({message: "Não foi possível encontrar usuários cadastrados em nossa base de dados"})
            } else{
                res.status(200).json({users})
            }

        } catch (err) {
            res.status(400).json({err})
        }
    },
    async getinfoUser(req, res){
        try {
            const {id} = req.params;
            const user = await User.findByPk(id)
            if(!user){
                res.status(401).json({message: "Não foi possível encontrar usuários cadastrados em nossa base de dados"})
            } else{
                res.status(200).json({user})
            }

        } catch(err){
            res.status(400).json({err})
        }
    },
    async delUser(req, res){
        try{
            const {id} = req.params;
            const user = await User.findByPk(id)
            if(!user){
                res.status(401).json({message: "Usuário não encontrado"})
            } else{
                await User.destroy({where: {id: id}})
                res.status(200).json({message: "Usuário apagado com sucesso"})
            }

        }catch (err){
            res.status(400).json({err})
        }
    }
};
