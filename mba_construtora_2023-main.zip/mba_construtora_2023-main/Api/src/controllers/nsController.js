const NS = require('../model/NS');
const uuid = require('uuid');

module.exports = {
    async createNs(req, res) {
        try {
            const {
                ns,
                cliente,
                cnpj_cliente,
                cidade,
                tipo,
                data_inicio,
                data_final,
                situacao,
                status_cemig,
                calc_lt,
                travessia_rod_dnit,
                travessia_rod_der,
                parametrizacao,
                travessia_fca,
                suprimentos,
                vistoria,
                pre_att,
                devolucao,
                pendencia,
                cco,
                transformadores,
            } = req.body;
            const nsExist = await NS.findOne({ where: { ns } });
            console.log(nsExist);
            if (nsExist) {
                res.status(401).json({
                    message:
                        'Já existe cadastrado em nossa base de dados informações com mesmo número de NS',
                });
            } else {
                const nsExist = await NS.create({
                    id: uuid.v4(),
                    ns,
                    cliente,
                    cnpj_cliente,
                    cidade,
                    tipo,
                    data_inicio,
                    data_final,
                    situacao,
                    status_cemig,
                    calc_lt,
                    travessia_rod_dnit,
                    travessia_rod_der,
                    parametrizacao,
                    travessia_fca,
                    suprimentos,
                    vistoria,
                    pre_att,
                    devolucao,
                    pendencia,
                    cco,
                    transformadores,
                });
                res.status(200).json({ nsExist });
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },
    async listNs(req, res) {
        try {
            const ns = await NS.findAll();
            if (!ns) {
                res.status(401).json({
                    message:
                        "Não foi possivel encontrar ns's em nossa base de dados",
                });
            } else {
                res.status(200).json({ ns });
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },
    async getInfoNs(req, res) {
        try {
            const { id } = req.params;
            const ns = await NS.findOne({ where: { id } });
            if (!ns) {
                res.status(401).json({
                    message: 'Não foi possível encontrar a NS desejada',
                });
            } else {
                res.status(200).json({ ns });
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },
    async updateNs(req, res) {
        try {
            const { id } = req.params;
            const {
                ns,
                cliente,
                cnpj_cliente,
                cidade,
                tipo,
                data_inicio,
                data_final,
                situacao,
                status_cemig,
                calc_lt,
                travessia_rod_dnit,
                travessia_rod_der,
                parametrizacao,
                travessia_fca,
                suprimentos,
                vistoria,
                pre_att,
                devolucao,
                pendencia,
                cco,
                transformadores,
            } = req.body;
            const nsExist = await NS.findOne({ where: { id } });
            if (!nsExist) {
                res.status(401).json({
                    message: 'Não foi possivel localizar esta NS',
                });
            } else {
                const nsExist = await NS.update(
                    {
                        ns,
                        cliente,
                        cnpj_cliente,
                        cidade,
                        tipo,
                        data_inicio,
                        data_final,
                        situacao,
                        status_cemig,
                        calc_lt,
                        travessia_rod_dnit,
                        travessia_rod_der,
                        parametrizacao,
                        travessia_fca,
                        suprimentos,
                        vistoria,
                        pre_att,
                        devolucao,
                        pendencia,
                        cco,
                        transformadores,
                    },
                    { where: { id } }
                );
                res.status(200).json(await NS.findAll({where:{id}}))
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },
    async deleteNs(req, res){
        try{
            const {id} = req.params;
            const nsExist = await NS.findOne({where: {id}})
            if(!nsExist){
                res.status(401).json({message: "Não foi possivel localizar esta NS"})
            } else {
                await NS.destroy({where: {id}})
                res.status(200).json({message: "Ns deletada com sucesso!"})
            }
        }catch(err){
            res.status(400).json({err})
        }
    }
};
