const Vehicle = require('../model/Vehicle');
const uuid = require('uuid');

module.exports = {
    async createVehicle(req, res) {
        try {
            const { marca, placa, km, frota } = req.body;
            const vehicleExist = await Vehicle.findOne({ where: { placa } });
            if (vehicleExist) {
                res.status(401).json({
                    message:
                        'Já existe um veículo com esta placa cadastrado em nossa base de dados',
                });
            } else {
                const createVehicle = await Vehicle.create({
                    id: uuid.v4(),
                    frota,
                    marca,
                    placa,
                    km,
                });
                res.status(200).json({ createVehicle });
            }
        } catch (err) {
            res.status(400).json({ err });
        }
    },
    async vehicleUpdate(req, res){
        try{
            const {id} = req.params;
            const {marca, placa, km, frota} = req.body;
            const vehicleExist = await Vehicle.findOne({where: {id}});
            if (!vehicleExist){
                res.status(401).json({message: "Não conseguimos encontrar este veículo"})
            } else {
               const vehicleExist = await Vehicle.update({marca, placa, frota, km},{where: {id}})
               res.status(200).json({vehicleExist})
            }

        } catch(err){
            res.status(400).json({err})
        }
    },
    async vehicleList(req, res){
        try{
            const vehicle = await Vehicle.findAll()
            if (!vehicle){
                res.status(401).json({message: "Não foi possível localizar a lista de veiculos"})
            } else {
                res.status(200).json({vehicle})
            }

        } catch(err){
            res.status(400).json({err})
        }
    },
    async getInfoVehicle(req, res){
        try{
            const {id} = req.params;
            const vehicleExist = await Vehicle.findOne({where: {id}})
            if(!vehicleExist){
                res.status(401).json({message: "Não conseguimos encontrar este veículo"})
            } else{
                res.status(200).json({vehicleExist})
            }

        } catch(err){
            res.status(400).json({err})
        }
    },
    async deleteVehicle(req, res){
        try{
            const {id} = req.params;
            const vehicleExist = await Vehicle.findOne({where: {id}})
            if(!vehicleExist){
                res.status(401).json({message: "Não conseguimos encontrar este veículo"})
            } else{
                const vehicleExist = await Vehicle.destroy({where: {id}})
                res.status(200).json({message: "Veiculo apagado com sucesso!"})
            }


        } catch(err){
            res.status(400).json({err})
        }
    }
};
