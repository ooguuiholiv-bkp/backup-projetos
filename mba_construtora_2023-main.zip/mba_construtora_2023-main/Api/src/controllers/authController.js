const User = require('../model/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();

const JwtDecrypt = process.env.JWTPASS;

module.exports = {
    async login(req, res) {
        try {
            const { email, password } = req.body;
            const mailExist = await User.findOne({where: {email}})
            if (!mailExist) {
               return res.status(401).json({
                    message:
                        'Ops, não foi possivel localizar nenhum usuário com estas credenciais',

                });
            }
            const matchPassword = await bcrypt.compare(
                password,
                mailExist.password
            );

            if (!matchPassword) {
                return res
                    .status(400)
                    .json({ message: 'Credenciais inválidas' });
            }
            const token = jwt.sign(
                { email: mailExist.email, id: mailExist.id },
                JwtDecrypt, {expiresIn: "1h"}
            );
            const tokenHash = await bcrypt.hash(token, 10);
            //const decryptToken = await bcrypt.()
            res.status(201).json({
                nome: mailExist.first_name + ' ' + mailExist.last_name,
                cpf_cnpj: mailExist.cpf_cnpj,
                email: mailExist.email,
                token: token,
            });
        } catch (err) {
            res.status(400).json({ err });
        }
    },
};
