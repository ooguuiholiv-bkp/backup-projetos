const express = require('express');
const UserController = require('../controllers/userController');
const VehicleController = require('../controllers/vehicleController');
const NsController = require('../controllers/nsController');
const AuthController = require('../controllers/authController');
const router = express.Router();
const cors = require('cors');
const dotenv = require('dotenv');
dotenv.config();

require('../database/index');

router.use(cors());

router.get('/', (req, res) => {
    res.status(200).json('ok');
});

/* Autenticação - Rotas privadas */


/*  */

/* Rotas de Usuário */
router.get('/users/', UserController.listUsers);
router.get('/users/:id', UserController.getinfoUser);
router.post('/users', UserController.CreateUser);
router.put('/users/:id', UserController.userUpdate);
router.delete('/users/:id', UserController.delUser);

/* Rotas de Veículo */
router.get('/vehicle', VehicleController.vehicleList);
router.get('/vehicle/:id', VehicleController.getInfoVehicle);
router.post('/vehicle', VehicleController.createVehicle);
router.put('/vehicle/:id', VehicleController.vehicleUpdate);
router.delete('/vehicle/:id', VehicleController.deleteVehicle);

/* Rotas de NS */
router.get('/ns', NsController.listNs);
router.get('/ns/:id', NsController.getInfoNs);
router.post('/ns', NsController.createNs);
router.put('/ns/:id', NsController.updateNs);
router.delete('/ns/:id', NsController.deleteNs);

/* Rota Auth */
router.post('/auth', AuthController.login);

module.exports = router;
