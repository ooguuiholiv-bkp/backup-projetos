'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    async up(queryInterface, Sequelize) {
        return queryInterface.createTable('Vehicles', {
            id: {
                type: Sequelize.UUID,
                primaryKey: true,
            },
            marca: {
                type: Sequelize.STRING,
            },
            placa: {
                type: Sequelize.STRING,
            },
            km: {
                type: Sequelize.INTEGER,
            },
            frota:{
                type:Sequelize.STRING,
            },
            created_at: {
                type: Sequelize.DATE,
                allowNull: false,
            },
            updated_at: {
                type: Sequelize.DATE,
                allowNull: false,
            },
        });
    },

    async down(queryInterface, Sequelize) {
        return queryInterface.dropTable('Vehicles');
    },
};

