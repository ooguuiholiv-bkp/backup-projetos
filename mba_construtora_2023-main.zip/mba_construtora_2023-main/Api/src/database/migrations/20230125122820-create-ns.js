'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
    up(queryInterface, Sequelize) {
        return queryInterface.createTable('Ns', {
            id: {
                type: Sequelize.UUID,
                primaryKey: true,
            },
            ns: {
                type: Sequelize.STRING,
            },
            cliente: {
                type: Sequelize.STRING,
            },
            cnpj_cliente: {
                type: Sequelize.STRING,
            },
            cidade: {
                type: Sequelize.STRING,
            },
            tipo: {
                type: Sequelize.STRING,
            },
            data_inicio: {
                type: Sequelize.DATE,
            },
            data_final: {
                type: Sequelize.DATE,
            },
            situacao: {
                type: Sequelize.STRING,
            },
            status_cemig: {
                type: Sequelize.STRING,
            },
            calc_lt: {
                type: Sequelize.STRING,
            },
            travessia_rod_dnit: {
                type: Sequelize.STRING,
            },
            travessia_rod_der: {
                type: Sequelize.STRING,
            },
            parametrizacao: {
                type: Sequelize.STRING,
            },
            travessia_fca: {
                type: Sequelize.STRING,
            },
            suprimentos: {
                type: Sequelize.STRING,
            },
            vistoria: {
                type: Sequelize.STRING,
            },
            pre_att: {
                type: Sequelize.STRING,
            },
            devolucao: {
                type: Sequelize.STRING,
            },
            pendencia: {
                type: Sequelize.STRING,
            },
            cco: {
                type: Sequelize.STRING,
            },
            transformadores: {
                type: Sequelize.STRING,
            },
            created_at: {
                type: Sequelize.DATE,
                allowNull: false,
            },
            updated_at: {
                type: Sequelize.DATE,
                allowNull: false,
            },
        });
    },

    down(queryInterface, Sequelize) {
        return queryInterface.dropTable('Ns');
    },
};
