const Sequelize = require('sequelize');
const configDb = require('../config/database');
const connection = new Sequelize(configDb);

const User = require('../model/User');
const Vehicle = require('../model/Vehicle');
const NS = require('../model/NS');

User.init(connection);
Vehicle.init(connection);
NS.init(connection)

module.exports = connection;
