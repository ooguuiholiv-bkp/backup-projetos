import React from "react";

import styled from "styled-components";
import Logo from "../../assets/logo.png";
import { Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import api from "../../services/api";

export const LoginContainer = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: "Roboto", sans-serif;

  .content {
    width: 30vw;
    height: 65vh;
    background: #ffbb00;
    border-radius: 0.5rem;
    box-shadow: 6px 6px 18px -10px #6b6b6b;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
    .dados {
      form {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.4rem;

        .fields {
          .inputLogin {
            width: 25vw;
            height: 5vh;
            border: none;
            border-radius: 0.3rem;
          }
          .error-message {
            margin-top: 0.5rem;
            color: red;
            font-size: 0.7rem;
          }
        }
      }
    }
    .logo {
      width: 55%;
      img {
        width: 100%;
      }
    }
  }
`;
export const LoginPage = () => {
  const validationLogin = yup.object().shape({
    email: yup.string().required("É obrigatório informar o e-mail").max(255),
    password: yup
      .string()
      .required("É obrigatório informar o password")
      .max(50),
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationLogin),
  });

  const LoginData = (data) =>
    api
      .post("/auth", data)
      .then((res) => {
        console.log(data);
        const nome = res.data.nome;
        const documento = res.data.cpf_cnpj;
        const email = res.data.email;
        const token = res.data.token;
        localStorage.setItem("nome", nome);
        localStorage.setItem("documento", documento);
        localStorage.setItem("email", email);
        localStorage.setItem("token", token);
        window.location.href = "/intranet";
      })
      .catch((res) => {
        console.log(res.response.data)
      });
  return (
    <LoginContainer>
      <div className="content">
        <div className="logo">
          <img src={Logo} alt="logo" />
        </div>
        <div className="dados">
          <form onSubmit={handleSubmit(LoginData)}>
            <div className="fields">
              <input
                type="text"
                className="inputLogin"
                name="email"
                {...register("email")}
                id="email"
              />
              <p className="error-message">{errors.email?.message}</p>
            </div>
            <div className="fields">
              <input
                type="password"
                className="inputLogin"
                name="password"
                {...register("password")}
                id="password"
              />
              <p className="error-message">{errors.password?.message}</p>
            </div>
            <div className="fields">
              <Link to="/forgot">
                <p>Esqueci minha senha!</p>
              </Link>
            </div>
            <div className="fields">
              <button type="submit" className="btn btn-secondary">
                Entrar
              </button>
            </div>
          </form>
        </div>
      </div>
    </LoginContainer>
  );
};
