import React from 'react';
import styled from 'styled-components';
import { Layout } from '../../../components/Layout';

export const DashUserContainer = styled.div`
  
`;

export const DashUsers = () => {
    return(
        <Layout>
            <DashUserContainer>
                
            </DashUserContainer>
        </Layout>
    )

}