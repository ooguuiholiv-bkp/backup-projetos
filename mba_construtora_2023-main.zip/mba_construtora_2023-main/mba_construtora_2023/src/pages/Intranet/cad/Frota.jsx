import React from "react";
import { Layout } from "../../../components/Layout";
import styled from "styled-components";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import api from "../../../services/api";

export const FrotaContainer = styled.div`
  width: 75vw;
  height: 75vh;
  background: #1c1c1cd2;
  border-radius: 0.5rem;
  color: white;
  .content {
    form {
      .submit {
        display: flex;
        justify-content: center;
        margin-top: 2rem;
        button {
          width: 18vw;
          border: none;
          height: 5vh;
          border-radius: 0.3rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }
      }
      .fields {
        display: flex;
        justify-content: center;
        gap: 2rem;
        margin-top: 2rem;

        .campos {
          display: flex;
          flex-direction: column;
          .error-message{
            font-size: 0.8rem;
            color: #ffc107;
          }

          input {
            width: 20vw;
            height: 5vh;
            border: none;
            border-radius: 0.3rem;
          }
        }
      }
    }
  }
`;

export const FrotaCad = () => {
  const validFrota = yup.object().shape({
    marca: yup.string().required("Este campo é obrigatório").max(40),
    placa: yup.string().required("Este campo é obrigatório").max(10),
    km: yup.number().required(),
    frota: yup.string().required("Este campo é obrigatório").max(10),
  });
  const addFrota = (data) =>
    api
      .post("/vehicle", data)
      .then(() => {
        window.location.href = "/intranet";
      })
      .catch((err) => {
        console.log(err.response.data);
      });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validFrota),
  });

  return (
    <Layout>
      <FrotaContainer>
        <div className="content">
          <form onSubmit={handleSubmit(addFrota)}>
            <div className="fields">
              <div className="campos">
                <label for="marca">Marca</label>
                <input
                  type="text"
                  id="marca"
                  name="marca"
                  {...register("marca")}
                />
                <p className="error-message">{errors.marca?.message}</p>
              </div>
              <div className="campos">
                <label for="placa">Placa</label>
                <input
                  type="text"
                  id="placa"
                  name="placa"
                  {...register("placa")}
                />
                <p className="error-message">{errors.placa?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="km">KM</label>
                <input type="number" id="km" name="km" {...register("km")} />
                <p className="error-message">{errors.placa?.message}</p>
              </div>
              <div className="campos">
                <label for="frota">Frota</label>
                <input
                  type="text"
                  name="frota"
                  id="frota"
                  {...register("frota")}
                />
                <p className="error-message">{errors.frota?.message}</p>
              </div>
            </div>
            <div className="submit">
              <button className="btn btn-success" type="submit">
                Cadastrar
              </button>
            </div>
          </form>
        </div>
      </FrotaContainer>
    </Layout>
  );
};
