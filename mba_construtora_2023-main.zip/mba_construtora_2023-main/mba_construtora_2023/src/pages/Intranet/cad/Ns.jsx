import React from "react";
import { Layout } from "../../../components/Layout";
import styled from "styled-components";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import api from "../../../services/api";
export const Container = styled.div`
  width: 75vw;
  height: 75vh;
  background: #1c1c1cd2;
  border-radius: 0.5rem;
  color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: auto;
  .content {
    margin-top: 10rem;
    form {
      margin-top: 6rem;
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 1rem;
      .submit {
        display: flex;
        justify-content: center;
        margin-bottom: 2rem;
      }
      .fields {
        display: flex;
        gap: 2rem;
        .campos {
          display: flex;
          flex-direction: column;
          .error-message {
            color: red;
            font-size: 0.7rem;
          }
          label {
            font-size: 0.8rem;
            color: #ffc107;
          }
        }
        input {
          width: 20vw;
          height: 4vh;
          border: none;
          border-radius: 0.3rem;
        }
      }
    }
  }
`;

export const NSCadPage = () => {
  const validNs = yup.object().shape({
    ns: yup.string().required("Este campo é obrigatório").max(11),
    cliente: yup.string().required("Este campo é obrigatório").max(255),
    cnpj_cliente: yup.string().required("Este campo é obrigatório").min(13).max(18),
    cidade: yup.string().required("Este campo é obrigatório").max(30),
    tipo: yup.string().required("Este campo é obrigatório").max(30),
    // data_inicio: yup.date().required("Este campo é obrigatório"),
    // data_final: yup.date().required("Este campo é obrigatório"),
    situacao: yup.string().required("Este campo é obrigatório").max(30),
    status_cemig: yup.string().required("Este campo é obrigatório").max(30),
    calc_lt: yup.string().required("Este campo é obrigatório").max(30),
    travessia_rod_dnit: yup
      .string()
      .required("Este campo é obrigatório")
      .max(30),
    travessia_rod_der: yup
      .string()
      .required("Este campo é obrigatório")
      .max(30),
    parametrizacao: yup.string().required("Este campo é obrigatório").max(30),
    travessia_fca: yup.string().required("Este campo é obrigatório").max(30),
    suprimentos: yup.string().required("Este campo é obrigatório").max(30),
    vistoria: yup.string().required("Este campo é obrigatório").max(30),
    pre_att: yup.string().required("Este campo é obrigatório").max(30),
    devolucao: yup.string().required("Este campo é obrigatório").max(30),
    pendencia: yup.string().required("Este campo é obrigatório").max(30),
    cco: yup.string().required("Este campo é obrigatório").max(30),
    transformadores: yup.string().required("Este campo é obrigatório").max(30),
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validNs),
  });
  const addNs = (data) => api.post('/ns', data).then(() => {
    alert("Cadastrado com sucesso!")
    window.location.href = "/intranet"
  }).catch((err) => {
    console.log(err)
  })
  return (
    <Layout>
      <Container>
        <div className="content">
          <form onSubmit={handleSubmit(addNs)}>
            <div className="fields">
              <div className="campos">
                <label for="ns">NS</label>
                <input
                  type="text"
                  id="ns"
                  name="ns"
                  {...register("ns")}
                  //   placeholder="NS"
                />
                <p className="error-message">{errors.ns?.message}</p>
              </div>
              <div className="campos">
                <label for="cliente">Cliente</label>
                <input
                  type="text"
                  id="cliente"
                  name="cliente"
                  {...register("cliente")}
                  //   placeholder="Cliente"
                />
                <p className="error-message">{errors.cliente?.message}</p>
              </div>
              <div className="campos">
                <label for="cnpj_cliente">Cnpj do Cliente</label>
                <input
                  type="text"
                  id="cnpj_cliente"
                  name="cnpj_cliente"
                  {...register("cnpj_cliente")}
                  //   placeholder="Cnpj do cliente"
                />
                <p className="error-message">{errors.cnpj_cliente?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="cidade">Cidade</label>
                <input
                  type="text"
                  id="cidade"
                  name="cidade"
                  {...register("cidade")}
                  //   placeholder="cidade da obra"
                />
                <p className="error-message">{errors.cidade?.message}</p>
              </div>
              <div className="campos">
                <label for="tipo">Tipo de Obra</label>
                <input
                  type="text"
                  id="tipo"
                  name="tipo"
                  {...register("tipo")}
                  //   placeholder="tipo"
                />
                <p className="error-message">{errors.tipo?.message}</p>
              </div>
              <div className="campos">
                <label for="data_inicio">Data de Inicio</label>
                <input
                  type="date"
                  id="data_inicio"
                  name="data_inicio"
                  {...register("data_inicio")}
                  //   placeholder="data Inicio"
                />
                <p className="error-message">{errors.data_inicio?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="data_final">Data de Finalização</label>
                <input
                  type="date"
                  id="data_final"
                  name="data_final"
                  {...register("data_final")}
                />
                <p className="error-message">{errors.data_final?.message}</p>
              </div>
              <div className="campos">
                <label for="situacao">Situação</label>
                <input
                  type="text"
                  id="situacao"
                  name="situacao"
                  {...register("situacao")}
                  //   placeholder="situacao"
                />
                <p className="error-message">{errors.situacao?.message}</p>
              </div>
              <div className="campos">
                <label for="status_cemig">Status Cemig</label>
                <input
                  type="text"
                  id="status_cemig"
                  name="status_cemig"
                  {...register("status_cemig")}
                  //   placeholder="Status Cemig"
                />
                <p className="error-message">{errors.status_cemig?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="calc_lt">Calculo de Lt</label>
                <input
                  type="text"
                  id="calc_lt"
                  name="calc_lt"
                  {...register("calc_lt")}
                  //   placeholder="Calc LT"
                />
                <p className="error-message">{errors.calc_lt?.message}</p>
              </div>
              <div className="campos">
                <label for="travessia_rod_dnit">Travessia Rod DNIT</label>
                <input
                  type="text"
                  id="travessia_rod_dnit"
                  name="travessia_rod_dnit"
                  {...register("travessia_rod_dnit")}
                  //   placeholder="travessia rod dnit"
                />
                <p className="error-message">
                  {errors.travessia_rod_dnit?.message}
                </p>
              </div>
              <div className="campos">
                <label for="travessia_rod_der">Travessia Rod DER</label>
                <input
                  type="text"
                  id="travessia_rod_der"
                  name="travessia_rod_der"
                  {...register("travessia_rod_der")}
                  //   placeholder="travessia rod der"
                />
                <p className="error-message">
                  {errors.travessia_rod_der?.message}
                </p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="parametrizacao">Parametrização</label>
                <input
                  type="text"
                  id="parametrizacao"
                  name="parametrizacao"
                  {...register("parametrizacao")}
                  //   placeholder="parametrização"
                />
                <p className="error-message">
                  {errors.parametrizacao?.message}
                </p>
              </div>
              <div className="campos">
                <label for="travessia_fca">Travessia FCA</label>
                <input
                  type="text"
                  id="travessia_fca"
                  name="travessia_fca"
                  {...register("travessia_fca")}
                  //   placeholder="travessia fca"
                />
                <p className="error-message">{errors.travessia_fca?.message}</p>
              </div>
              <div className="campos">
                <label for="suprimentos">Suprimentos</label>
                <input
                  type="text"
                  id="suprimentos"
                  name="suprimentos"
                  {...register("suprimentos")}
                  //   placeholder="suprimentos"
                />
                <p className="error-message">{errors.suprimentos?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="vistoria">Vistoria</label>
                <input
                  type="text"
                  id="vistoria"
                  name="vistoria"
                  {...register("vistoria")}
                  //   placeholder="vistoria"
                />
                <p className="error-message">{errors.vistoria?.message}</p>
              </div>
              <div className="campos">
                <label for="pre_att">Pre Atualização</label>
                <input
                  type="text"
                  id="pre_att"
                  name="pre_att"
                  {...register("pre_att")}
                  //   placeholder="PreAtt"
                />
                <p className="error-message">{errors.pre_att?.message}</p>
              </div>
              <div className="campos">
                <label for="devolucao">Devolução</label>
                <input
                  type="text"
                  id="devolucao"
                  name="devolucao"
                  {...register("devolucao")}
                  //   placeholder="devolução"
                />
                <p className="error-message">{errors.devolucao?.message}</p>
              </div>
            </div>
            <div className="fields">
              <div className="campos">
                <label for="pendencia">Pendencia</label>
                <input
                  type="text"
                  id="pendencia"
                  name="pendencia"
                  {...register("pendencia")}
                  //   placeholder="pendencia"
                />
                <p className="error-message">{errors.pendencia?.message}</p>
              </div>
              <div className="campos">
                <label for="cco">CCO</label>
                <input
                  type="text"
                  id="cco"
                  name="cco"
                  {...register("cco")}
                  //   placeholder="cco"
                />
                <p className="error-message">{errors.cco?.message}</p>
              </div>
              <div className="campos">
                <label for="transformadores">Transformadores</label>
                <input
                  type="text"
                  id="transformadores"
                  name="transformadores"
                  {...register("transformadores")}
                  //   placeholder="transformadores"
                />
                <p className="error-message">
                  {errors.transformadores?.message}
                </p>
              </div>
            </div>
            <div className="submit">
              <button className="btn btn-success">Cadastrar</button>
            </div>
          </form>
        </div>
      </Container>
    </Layout>
  );
};
