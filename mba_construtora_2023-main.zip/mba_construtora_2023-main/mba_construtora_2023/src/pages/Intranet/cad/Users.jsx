import { Layout } from "../../../components/Layout";
import styled from "styled-components";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Alert from "react-bootstrap/Alert";
import api from "../../../services/api";
export const Container = styled.div`
  width: 75vw;
  height: 75vh;
  background: #1c1c1cd2;
  border-radius: 0.5rem;
  color: white;
  .form {
    width: 100%;
    height: 100%;
    .control-form {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
      justify-content: center;
      width: 100%;
      height: 100%;
      .submit {
        display: flex;
        justify-content: center;
      }
      .formCheck {
        display: flex;
        gap: 2rem;
        justify-content: center;
        .check {
          display: flex;
          gap: 0.3rem;
        }
      }
      .labels {
        width: 100%;
        display: flex;
        .fields {
          align-items: center;
          gap: 0.2rem;
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          .error-message {
            color: #ffc107;
            font-family: "Roboto", sans-serif;
            font-size: 0.8rem;
          }
          input {
            width: 30vw;
            height: 5vh;
            border-radius: 0.4rem;
            border: none;
          }
        }
      }
    }
  }
`;

export const CadUsers = () => {
  const validarDadosCadastro = yup.object().shape({
    first_name: yup.string().required("Este campo é obrigatório").max(20),
    last_name: yup.string().required("Este campo é obrigatório").max(20),
    cpf_cnpj: yup.string().required("Este campo é obrigatório").max(15),
    username: yup.string().required("Este campo é obrigatório").max(30),
    email: yup.string().required("Este campo é obrigatório").max(255),
    password: yup.string().required("Este campo é obrigatório").max(35),
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validarDadosCadastro),
  });

  const createUser = (data) =>
    api
      .post("/users", data)
      .then(() => {
        window.location.href = "/intranet";
      })
      .catch((err) => {
        console.log(err.response.data);
      });

  return (
    <Layout>
      <Container>
        <div className="form">
          <form className="control-form" onSubmit={handleSubmit(createUser)}>
            <div className="labels">
              <div className="fields">
                <input
                  type="text"
                  name="first_name"
                  id="first_name"
                  placeholder="Nome"
                  {...register("first_name")}
                />
                <p className="error-message">{errors.first_name?.message}</p>
              </div>
              <div className="fields">
                <input
                  type="text"
                  name="last_name"
                  id="last_name"
                  placeholder="Sobrenome"
                  {...register("last_name")}
                />
                <p className="error-message">{errors.last_name?.message}</p>
              </div>
            </div>
            <div className="labels">
              <div className="fields">
                <input
                  type="text"
                  name="cpf_cnpj"
                  id="cpf_cnpj"
                  placeholder="CPF / CNPJ"
                  {...register("cpf_cnpj")}
                />
                <p className="error-message">{errors.cpf_cnpj?.message}</p>
              </div>
              <div className="fields">
                <input
                  type="text"
                  name="username"
                  id="username"
                  placeholder="Usuário"
                  {...register("username")}
                />
                <p className="error-message">{errors.username?.message}</p>
              </div>
            </div>
            <div className="labels">
              <div className="fields">
                <input
                  type="text"
                  name="email"
                  id="email"
                  placeholder="E-mail"
                  {...register("email")}
                />
                <p className="error-message">{errors.email?.message}</p>
              </div>
              <div className="fields">
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Senha"
                  {...register("password")}
                />
                <p className="error-message">{errors.password?.message}</p>
              </div>
            </div>
            <div className="formCheck">
              <div className="check">
                <label for="is_client" className="form-check-label">
                  É cliente{" "}
                </label>
                <input
                  name="is_client"
                  id="is_client"
                  className="form-check-input"
                  type="checkbox"
                  {...register("is_client")}
                />
              </div>
              <div className="check">
                <label for="is_employee" className="form-check-label">
                  É funcionário{" "}
                </label>
                <input
                  name="is_employee"
                  id="is_employee"
                  className="form-check-input"
                  type="checkbox"
                  {...register("is_employee")}
                />
              </div>
            </div>
            <div className="submit">
              <button className="btn btn-success">Cadastrar</button>
            </div>
          </form>
        </div>
      </Container>
    </Layout>
  );
};
