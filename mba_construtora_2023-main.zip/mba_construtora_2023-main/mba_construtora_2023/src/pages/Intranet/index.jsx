import { Layout } from "../../components/Layout";
import lupa from "../../assets/search.svg";
import styled from "styled-components";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Table from "react-bootstrap/Table";

export const Container = styled.div`
  width: 100vw;
  height: 80vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  .content {
    form {
      .fields {
        display: flex;
        button {
          width: 4vw;
          height: 5vh;
          border: none;
          background-color: #c9c9c9;
          border-top-right-radius: 0.3rem;
          border-bottom-right-radius: 0.3rem;
          display: flex;
          justify-content: center;
          align-items: center;
          img {
            width: 60%;
          }
        }
        input {
          width: 15vw;
          height: 5vh;
          border: none;
          background-color: #c9c9c9;
          border-top-left-radius: 0.3rem;
          border-bottom-left-radius: 0.3rem;
        }
      }
    }
  }
`;

export const IntranetPage = () => {
  return (
    <Layout>
      <Container>
        <div className="content">
          <form action="">
            <div className="fields">
              <InputGroup className="mb-3">
                <Form.Control
                  placeholder="NS"
                  aria-label="NS"
                  id="ns"
                  name="ns"
                />
                <Button variant="outline-secondary" id="submit" type="submit">
                  <img src={lupa} alt="" />
                </Button>
              </InputGroup>
            </div>
          </form>
        </div>
        <div className="table">
          <Table responsive>
            <thead>
              <tr>
                <th>#</th>
                {Array.from({ length: 12 }).map((_, index) => (
                  <th key={index}>Table heading</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                {Array.from({ length: 12 }).map((_, index) => (
                  <td key={index}>Table cell {index}</td>
                ))}
              </tr>
              <tr>
                <td>2</td>
                {Array.from({ length: 12 }).map((_, index) => (
                  <td key={index}>Table cell {index}</td>
                ))}
              </tr>
              <tr>
                <td>3</td>
                {Array.from({ length: 12 }).map((_, index) => (
                  <td key={index}>Table cell {index}</td>
                ))}
              </tr>
            </tbody>
          </Table>
        </div>
      </Container>
    </Layout>
  );
};
