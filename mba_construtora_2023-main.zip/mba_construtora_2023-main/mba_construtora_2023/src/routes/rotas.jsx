import React from "react";

import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import { LoginPage } from "../pages/Login/Login";
import { IntranetPage } from "../pages/Intranet";
import { ForgotPage } from "../pages/Forgot";
import { CadUsers } from "../pages/Intranet/cad/Users";
import { NSCadPage } from "../pages/Intranet/cad/Ns";
import { PrivateRoute } from "./PrivateRoutes";
import { FrotaCad } from "../pages/Intranet/cad/Frota";
import { DashUsers } from "../pages/Intranet/Dash/Users";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/login",
    element: <LoginPage />,
  },
  {
    path: "/intranet",
    element: (
      <PrivateRoute>
        <IntranetPage />,
      </PrivateRoute>
    ),
  },
  {
    path: "/forgot",
    element: <ForgotPage />,
  },
  {
    path: "/cad/users",
    element: (
      <PrivateRoute>
        <CadUsers />,
      </PrivateRoute>
    ),
  },
  {
    path: "/cad/ns/",
    element: (
      <PrivateRoute>
        <NSCadPage />,
      </PrivateRoute>
    ),
  },
  {
    path: "/cad/frotas/",
    element: (
      <PrivateRoute>
        <FrotaCad />,
      </PrivateRoute>
    ),
  },
  {
    path: "/users",
    element: (
      <PrivateRoute>
        <DashUsers />,
      </PrivateRoute>
    ),
  },
  
]);
