import { useState } from "react";
import reactLogo from "./assets/react.svg";
import nodeLogo from "./assets/node.svg";
import bootstrap from "./assets/bootstrap.svg";
import { Link } from "react-router-dom";
import styled from "styled-components";

export const Container = styled.div`
  @import url(https://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,regular,italic,500,500italic,700,700italic,900,900italic);
  background: #1c1c1c;
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #f2f2f2;
  font-family: "Roboto", sans-serif;
  .App {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 2rem;
    div {
      display: flex;
      gap: 1rem;
      align-items: center;
    }
  }
`;

function App() {
  const [count, setCount] = useState(0);

  return (
    <Container>
      <div className="App">
        <h1>Aqui será listado o site da Mba Construtora</h1>
        <div>
          <a href="https://vitejs.dev" target="_blank">
            <img src="/vite.svg" className="logo" alt="Vite logo" />
          </a>
          <a href="https://reactjs.org" target="_blank">
            <img src={reactLogo} className="logo react" alt="React logo" />
          </a>
          <a href="https://reactjs.org" target="_blank">
            <img src={nodeLogo} className="logo react" alt="React logo" />
          </a>
          <a href="https://reactjs.org" target="_blank">
            <img src={bootstrap} className="logo react" alt="React logo" />
          </a>
        </div>
        <h1>Vite + React</h1>
        <Link to="/login">
          <button
            style={{
              width: "auto",
              borderRadius: "0.2rem",
              border: "2px solid purple",
              background: "transparent",
              color: "#3de3ca",
            }}
          >
            Acesse á pagina de login
          </button>
        </Link>
      </div>
    </Container>
  );
}

export default App;
