import React from 'react';
import styled from 'styled-components';

export const MainContainer = styled.div`
  width: 100vw;
  height: 80vh;
  background: white;
  display: flex;
  justify-content: center;
  align-items: center;
`;
export const Main = ({children}) => {
    return(
        <MainContainer>
            {children}
        </MainContainer>
    )
}