import React from "react";
import logo from "../../assets/logo.png";
import user from "../../assets/user.jpg";

import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";

export const Header = () => {
  return (
    <Navbar bg="warning" expand="lg">
      <Container>
        <Navbar.Brand href="/intranet">
          <img src={logo} style={{ width: "8vw" }} alt="" />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <NavDropdown title="Dashboard" id="dashboard">
              <NavDropdown.Item href="/dash/users">Usuário</NavDropdown.Item>
              <NavDropdown.Item href="/dash/clientes">Cliente</NavDropdown.Item>
              <NavDropdown.Item href="/dash/ns">Ns</NavDropdown.Item>
              <NavDropdown.Item href="/dash/funcionarios">
                Funcionários
              </NavDropdown.Item>
              <NavDropdown.Item href="/dash/equipe">Equipe</NavDropdown.Item>
              <NavDropdown.Item href="/dash/frotas">Frotas</NavDropdown.Item>
            </NavDropdown>
            <NavDropdown title="Cadastros" id="cadastros">
              <NavDropdown.Item href="/cad/users">Usuário</NavDropdown.Item>
              <NavDropdown.Item href="/cad/ns">Ns</NavDropdown.Item>
              <NavDropdown.Item href="/cad/frotas">Frotas</NavDropdown.Item>
            </NavDropdown>
          </Nav>
          <NavDropdown title={localStorage.getItem("nome")} id="logout">
            <NavDropdown.Item href="">Configurações</NavDropdown.Item>
            <NavDropdown.Item
              href="#"
              onClick={() => {
                localStorage.removeItem("token");
                localStorage.removeItem("nome");
                localStorage.removeItem("documento");
                localStorage.removeItem("email");
                window.location.href = "/";
              }}
            >
              sair
            </NavDropdown.Item>
          </NavDropdown>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};
