import React from "react";

import styled from "styled-components";
import { Footer } from "./Footer";
import { Header } from "./Header";
import { Main } from "./Main";

export const Container = styled.div``;

export const Layout = ({ children }) => {
  return (
    <Container>
      <Header />
      <Main children={children}></Main>
      <Footer />
    </Container>
  );
};
