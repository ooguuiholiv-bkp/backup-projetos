import { Route, Routes } from "react-router-dom";
import { GlobalStyle } from "./Global";
import Layout from "./Layout";
import Main from "./Layout/Main";
import Motorista from "./Pages/Cadastros/Motorista";

function App() {
  return (
    <>
      <GlobalStyle />
      <Layout>
        <Routes>
          <Route path="/" />

          <Route path="/cadastros/motorista" element={<Motorista />} />
        </Routes>
      </Layout>
    </>
  );
}

export default App;
