import React from "react";
import styled from "styled-components";
import { SidebarData } from "../../Services/SidebarMenu/";
import { Link } from "react-router-dom";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import { useState } from "react";
import SubMenu from "./SubMenu";
import { IconContext } from "react-icons";

const Nav = styled.div`
  display: flex;
  width: 20vw;
  height: 10vh;
  background-color: #0f619f;
  margin-top: 0;
  grid-row-start: 1;
  grid-column-start: 1;
`;

const NavIcon = styled(Link)`
  margin-left: 0.5rem;
  font-size: 2rem;
  color: #f2f2f2;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

const SidebarNav = styled.nav`
  background: #0f619f;
  width: 20vw;
  height: 94vh;
  display: flex;
  justify-content: center;
  position: fixed;
  top: 1rem;
  left: ${({ sidebar }) => (sidebar ? "0" : "-100%")};
  transition: 350ms;
  z-index: 10;
`;

const SidebarWrap = styled.div`
  width: 100%;
`;

const MenuList = styled.ul`
  margin-top: 5rem;
  list-style: none;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  column-gap: 1rem;
  row-gap: 1rem;
`;

const Menu = styled.li`
  display: flex;
  flex-direction: column;
  align-items: center;
  img {
    width: 200px;
    border-radius: 50%;
    margin-bottom: 2rem;
  }
  span {
    font-weight: bold;
    text-align: center;
  }
  a {
    color: white;
    text-decoration: none;
    transition: all 0.4s;
  }
  a:hover {
    transform: scale(1.1);
  }
  p {
    color: black;
    text-transform: capitalize;
  }
`;

const Sidebar = () => {
  const [sidebar, setSidebar] = useState(false);
  const showSidebar = () => setSidebar(!sidebar);

  return (
    <>
      <IconContext.Provider value={{ color: "#f2f2f2" }}>
        <Nav>
          <NavIcon to="#">
            <FaIcons.FaBars onClick={showSidebar} />
          </NavIcon>
        </Nav>
        <SidebarNav sidebar={sidebar}>
          <SidebarWrap>
            <NavIcon to="#">
              <AiIcons.AiOutlineClose onClick={showSidebar} />
            </NavIcon>
            {SidebarData.map((item, index) => {
              return <SubMenu item={item} key={index} />;
            })}
          </SidebarWrap>
        </SidebarNav>
      </IconContext.Provider>
    </>
  );
};

export default Sidebar;
