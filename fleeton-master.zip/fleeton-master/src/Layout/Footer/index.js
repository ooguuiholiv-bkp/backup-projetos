import React from "react";
import styled from 'styled-components';

export const Container = styled.footer`
  width: 20vw;
  height: 3vh;
  background-color: white;
  margin-top: 0;
  grid-row-start: 3;
  grid-column-start: 1;

  .footerText{
    color: #2198F3;
    font-size: 1rem;
    text-align: center;
  }
`;
export default function Footer(){
  return(
    <Container>
      <div className="footerText">
        2020 &copy; <u>fleetOn</u> by <u>CHROPO ltd</u>
      </div>
    </Container>
  )
}