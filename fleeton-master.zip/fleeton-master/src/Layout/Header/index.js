import React from "react";
import styled from 'styled-components';

export const Container = styled.header`
  width: 80vw;
  height: 10vh;
  background-color: #0f619f;
  margin-left: auto;
  grid-row-start: 1;
  grid-column-start: 2;
`;

export default function Header(){
  return(
    <Container>
      
    </Container>
  )
}
