import React from "react";
import Footer from "./Footer";
import Header from "./Header";
import Main from "./Main";
import Sidebar from "./Sidebar";
import styled from "styled-components";
import { BrowserRouter, Route } from "react-router-dom";
import Rotas from "../Routes";


export const Container = styled.div`
  width: 100%;
  height: 100%;
  display: grid;
`;

export default function Layout({children}) {
  return (
      <Container>
        <Header />
        <Sidebar />
        <Main children={children} />
        <Footer />
      </Container>
  );
}
