import React from "react";
import styled from "styled-components";

export const Container = styled.div`
  width: 80vw;
  height: 90vh;
  background-color: white;
  grid-column-start: 2;
  grid-row-start: 1;
  grid-row-end: 4;
  margin-top: 10vh;
`;

export default function Main({children}){
  return(
    <Container>
      {children}
    </Container>
  )
}

