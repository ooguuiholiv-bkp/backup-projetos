import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./Layout";
import Motorista from "./Pages/Cadastros/Motorista";

const Rotas = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />} />
          <Route path="/cadastros/motorista" element={<Motorista />} />
        </Routes>
      </BrowserRouter>
    </>
  );
};
export default Rotas;
