import React from "react";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import * as RiIcons from "react-icons/ri";
import * as GiIcons from "react-icons/gi";

export const SidebarData = [
  {
    title: "Página Inicial",
    path: "/",
    icon: <FaIcons.FaDesktop />,
  },
  {
    title: "Dashboard",
    path: "/dashboard",
    icon: <AiIcons.AiFillDashboard />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Operação",
        path: "/dashboard/operacao",
        icon: <AiIcons.AiOutlineBarChart />,
      },
      {
        title: "GasStation",
        path: "/dashboard/gasstation",
        icon: <AiIcons.AiOutlineBarChart />,
      },
    ],
  },
  {
    title: "Cadastros",
    path: "/cadastros",
    icon: <AiIcons.AiOutlineFolder />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Filial",
        path: "/cadastros/filial",
        icon: <FaIcons.FaRegBuilding />,
      },
      {
        title: "Centro de Custo",
        path: "/cadastros/centrodecusto",
        icon: <AiIcons.AiOutlineCopyright />,
      },
      {
        title: "Motorista",
        path: "/cadastros/motorista",
        icon: <AiIcons.AiOutlineIdcard />,
      },
      {
        title: "Veículo",
        path: "cadastros/veiculo",
        icon: <FaIcons.FaCarAlt />,
      },
    ],
  },
  {
    title: "Operação",
    path: "/operacao",
    icon: <AiIcons.AiFillSetting />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Negociação",
        path: "/operacao/negociacao",
        icon: <FaIcons.FaHandsHelping />,
      },
      {
        title: "Voucher",
        path: "/operacao/voucher",
        icon: <FaIcons.FaTicketAlt />,
      },
      {
        title: "Abastecimento",
        path: "/operacao/abastecimento",
        icon: <FaIcons.FaThermometerHalf />,
      },
      {
        title: "Preço Combustível",
        path: "operacao/precocombustivel",
        icon: <FaIcons.FaGasPump />,
      },
    ],
  },
  {
    title: "Cadastros",
    path: "/AdmCadastros",
    icon: <AiIcons.AiOutlineFolder />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Postal",
        path: "/admcadastros/postal",
        icon: <AiIcons.AiOutlineGlobal />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: "Cidade",
            path: "/admcadastros/postal/cidade",
          },
          {
            title: "Estado",
            path: "/admcadastros/postal/estado",
          },
          {
            title: "País",
            path: "/admcadastros/postal/pais",
          },
        ],
      },

      {
        title: "Combustível",
        path: "/admcadastros/combustivel",
        icon: <FaIcons.FaGasPump />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: "Tipo de combustível",
            path: "/admcadastros/combustivel/tipo",
          },
          {
            title: "Combustível",
            path: "/admcadastros/combustivel/combustivel",
          },
          {
            title: "Bandeira Posto",
            path: "/admcadastros/combustivel/bandeiraposto",
          },
          {
            title: "Estabelecimento",
            path: "/admcadastros/combustivel/estabelecimento",
          },
        ],
      },
      {
        title: "Veículo",
        path: "/admcadastros/veiculo",
        icon: <FaIcons.FaCarAlt />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: "Cor",
            path: "/admcadastros/veiculo/cor",
          },
          {
            title: "Espécie",
            path: "/admcadastros/veiculo/especie",
          },
          {
            title: "Tipo",
            path: "/admcadastros/veiculo/tipo",
          },
          {
            title: "Marca",
            path: "/admcadastros/veiculo/marca",
          },
          {
            title: "Modelo",
            path: "/admcadastros/veiculo/modelo",
          },
          {
            title: "Situação",
            path: "/admcadastros/veiculo/situacao",
          },
        ],
      },
    ],
  },
  {
    title: "Sistema",
    path: "/sistema",
    icon: <AiIcons.AiFillSetting />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Módulo",
        path: "/sistema/modulo",
      },
      {
        title: "Entrada",
        path: "/sistema/entrada",
      },
      {
        title: "Ação",
        path: "/sistema/acao",
      },
    ],
  },
  {
    title: "Segurança",
    path: "/seguranca",
    icon: <FaIcons.FaShieldAlt />,
    iconClosed: <RiIcons.RiArrowDownSFill />,
    iconOpened: <RiIcons.RiArrowUpSFill />,
    subNav: [
      {
        title: "Autenticação",
        path: "/seguranca/autenticacao",
        icon: <GiIcons.GiPadlock />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: 'Token',
            path: '/seguranca/autenticacao/token',
            icon: <FaIcons.FaCode />
          },
          {
            title: 'Licenças',
            path: '/seguranca/autenticacao/licencas',
            icon: <AiIcons.AiOutlineKey />
          },
        ]
      },
      {
        title: "Acesso",
        path: "/seguranca/acesso",
        icon: <FaIcons.FaUniversalAccess />,
        iconClosed: <RiIcons.RiArrowDownSFill />,
        iconOpened: <RiIcons.RiArrowUpSFill />,
        subNav: [
          {
            title: 'Usuário',
            path: '/seguranca/acesso/usuario',
            icon: <AiIcons.AiOutlineUser />
          },
          {
            title: 'Pemissões',
            path: '/seguranca/acesso/permissoes',
            icon: <AiIcons.AiOutlineUsergroupAdd />
          },
        ]
      },
    ],
  },
];
