import styled from "styled-components";

export const Container = styled.div`
  width: 90%;
  height: 100%;
  .icon {
    font-size: 2rem;
  }
  .header {
    display: flex;
    align-items: center;
    font-size: 1.5rem;
    padding: 2rem;
    span {
      font-weight: bold;
    }
  }
  .card {
    padding-top: 1rem;
    padding-left: 0.5rem;
    background-color: #f2f2f2;
    border: none;
  }
`;


