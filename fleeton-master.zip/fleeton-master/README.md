# FleetOn 

## Plugins a serem instalados
  -[x] Bootstrap
  -[x] React-Bootstrap
  -[x] Sass
  -[x] React-router-dom
  -[x] React-router
  -[x] Styled-components

## Telas a serem criadas
  -[] Layout padrão
  -[] DataTable
  -[] Modal
  -[] Dashboard