import { LandingPage } from "./pages/LandingPage";
import './reset.css'
import './root.css'
function App() {
  return (
    <div className="App">
      <LandingPage />
    </div>
  );
}

export default App;
