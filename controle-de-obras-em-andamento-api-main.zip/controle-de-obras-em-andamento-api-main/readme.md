
# Controle de obras em Andamento - API

Criar um sistema de gerencimento de obras em andamento, onde sera adicionado as obras vigentes podendo alterar a qualquer momento o status da mesma. Os clientes deverao conseguir acessar o site e acompanhar o status da obra.
Se possivel adicionar tambem abertura de chamado a cada NS e criar um chat interno dentro da aplicacao.

##### TO-DO 


[x] - Crud de usuarios.

     1. Create - ok
     2. Read - ok
     3. Update - ok
     4. Delete - ok

[x] - Crud de Obras (NS).

     1. Create - ok
     2. Read - ok
     3. Update - ok
     4. Delete - ok

[x] - TypeUser - Admin, Editor, Client.

[ ] - Roles

[ ] - Criar função findUserByEmail - Clientes


## Instalação

Instale controle-de-obras-em-andamento-api com npm

```bash
  git clone https://github.com/oguuiholiv/controle-de-obras-em-andamento-api.git
  cd controle-de-obras-em-andamento-api
  npm install
```
    
## Documentação da API

#### Retorna todos os usuarios

```http
  GET /user
```

| Parâmetro   | Tipo       | Descrição                           |
| :---------- | :--------- | :---------------------------------- |
| `token` | `json` | **Obrigatório**. estar logado na aplicação |

#### Retorna um usuario com seus endereços

```http
  GET /user/${id}
```

| Parâmetro   | Tipo       | Descrição                                   |
| :---------- | :--------- | :------------------------------------------ |
| `id`      | `json` | **Obrigatório**. O ID do item que você quer |
#### Cadastrar um usuario

```http
  POST /user/
```

| Parâmetro   | Tipo       | Descrição                                   |
| :---------- | :--------- | :------------------------------------------ |
| `token`      | `json` | **Obrigatório**. O ID do item que você quer |




## Rodando os testes

Para rodar os testes, rode o seguinte comando

```bash
  npm run test
```


## 🚀 Sobre mim
Tenho 24 anos, sou cristão, guitarrista/adorador, e sou apaixonado pelo Desenvolvimento Front-End. Ultimamente tenho estudado muito sobre o Back-End, espero um dia ter conhecimento suficiente para me auto proclamar Desenvolvedor Full-Stack.


## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://portfolio.oguuiholiv.com.br/)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/oguuiholiv/)



## 🛠 Habilidades
<p align="left"> 
    <a href="https://www.w3.org/html/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/html-5.png"/> </a> 
    <a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/css3.png"/> </a> 
    <a href="https://getbootstrap.com.br/docs/4.1/getting-started/download/" target="_blank" <img src="https://img.icons8.com/color/48/000000/bootstrap.png"/> </a>
    <a href="https://sass-lang.com" target="_blank"> <img src="https://img.icons8.com/color/48/000000/sass-avatar.png"/> </a>
    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img src="https://img.icons8.com/color/48/000000/javascript.png"  width="48" height="48"/> </a> 
    <a href="https://pt-br.reactjs.org" targer="_blank"> <img src="https://img.icons8.com/ultraviolet/48/000000/react--v2.png"/> </a>
    <a style="padding-right:8px;" href="https://nodejs.org" target="_blank"> <img src="https://img.icons8.com/color/48/000000/nodejs.png"/> </a>
    <a href="https://git-scm.com/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/git.png"/> </a> 
   <a align="center"href="https://www.adobe.com/br/products/photoshop/" target="_blank" > <img src="https://i.pinimg.com/originals/31/02/38/31023806400284920008d8ebd24a2218.png"  width="48" height="48"/> </a>
   <a href="https://code.visualstudio.com/docs" target="_blank"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Visual_Studio_Code_1.35_icon.svg/1024px-Visual_Studio_Code_1.35_icon.svg.png"  width="44" height="44"/></a> 
   
   
</p>

