import { UserEntity } from '../../user/entities/user.entity';

export class LoginPayload {
  id: string;
  typeUser: number;
  name: string;

  constructor(user: UserEntity) {
    this.id = user.id;
    this.typeUser = user.typeUser;
    this.name = user.name;
  }
}
