import { Test, TestingModule } from '@nestjs/testing';
import { Repository } from 'typeorm';
import { getRepositoryToken } from '@nestjs/typeorm';
import { AddressService } from '../address.service';
import { AddressEntity } from '../entities/address.entity';
import { addressMock } from '../__mocks__/address.mock';
import { UserService } from '../../user/user.service';
import { UserEntityMock } from '../../user/__mocks__/user.mock';
import { CityService } from '../../city/city.service';
import { cityMock } from '../../city/__mocks__/city.mock';
import { createAddressMockDto } from '../__mocks__/create-address.mock';
import { UserEntity } from '../../user/entities/user.entity';
import { CityEntity } from '../../city/entities/city.entity';

describe('AddressService', () => {
  let service: AddressService;
  let addressRepository: Repository<AddressEntity>;
  let userRepository: Repository<UserEntity>;
  let cityRepository: Repository<CityEntity>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AddressService,
        {
          provide: UserService,
          useValue: {
            findUserById: jest.fn().mockResolvedValue(UserEntityMock),
          },
        },
        {
          provide: CityService,
          useValue: {
            findCityById: jest.fn().mockResolvedValue(cityMock),
          },
        },
        {
          provide: getRepositoryToken(AddressEntity),
          useValue: {
            save: jest.fn().mockResolvedValue(addressMock),
            find: jest.fn().mockResolvedValue(addressMock),
          },
        },
      ],
    }).compile();

    service = module.get<AddressService>(AddressService);
    addressRepository = module.get<Repository<AddressEntity>>(
      getRepositoryToken(AddressEntity),
    );
  });
  it('should be defined', () => {
    expect(service).toBeDefined();
    expect(addressRepository).toBeDefined();
  });

  it('should return address after saving', async () => {
    const address = await service.createAddress(
      createAddressMockDto,
      UserEntityMock.id,
    );
    expect(address).toEqual(addressMock);
  });
  it('should return error UserService', async () => {
    const address = await service.createAddress(
      createAddressMockDto,
      UserEntityMock.id,
    );
    expect(address).toEqual(addressMock);
  });

  it('should return all addressess to user', async () => {
    const addresses = await service.findAddressByUserId(UserEntityMock.id);
    expect(addresses).toEqual(addressMock);
  });
  it('should return not found if not address registred', async () => {
    jest.spyOn(addressRepository, 'find').mockResolvedValue(undefined);
    expect(
      service.findAddressByUserId(UserEntityMock.id),
    ).rejects.toThrowError();
  });
});
