import { cityMock } from '../../city/__mocks__/city.mock';
import { AddressEntity } from '../entities/address.entity';
import { UserEntityMock } from '../../user/__mocks__/user.mock';

export const addressMock: AddressEntity = {
  cep: '38307-837',
  cityId: cityMock.id,
  complement: 'cs',
  createdAt: new Date(),
  id: 777,
  numberAddress: 777,
  updatedAt: new Date(),
  userId: UserEntityMock.id,
};
