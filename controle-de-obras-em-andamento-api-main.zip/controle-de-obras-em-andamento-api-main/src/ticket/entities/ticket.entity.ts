import { NsEntity } from 'src/ns/entities/ns.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';

@Entity({ name: 'ticket' })
export class TicketEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;
  @Column({ name: 'ns_id', nullable: false })
  nsId: string;
  @Column({ name: 'title', nullable: false })
  title: string;
  @Column({ name: 'description', nullable: false })
  description: string;
  @Column({ name: 'priority', nullable: true })
  priority: string;
  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
  @ManyToOne(() => NsEntity, (ns) => ns.tickets)
  @JoinColumn({ name: 'ns_id', referencedColumnName: 'id' })
  ns?: NsEntity;
}
