import { Controller } from '@nestjs/common';

@Controller('ticket')
export class TicketController {}
