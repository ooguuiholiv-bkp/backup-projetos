import { LoginPayload } from '../auth/dtos/loginPayload.dto';

export const authorizationToLoginPayload = (
  authorization: string,
): LoginPayload => {
  const splited = authorization.split('.');

  if (splited.length < 3 || !splited[1]) {
    return undefined;
  }
  return JSON.parse(Buffer.from(splited[1], 'base64').toString('ascii'));
};
