import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateTableTickets1692362657502 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
    CREATE TABLE public.ticket(
        id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
        ns_id UUID NOT NULL,
        title character varying NOT NULL,
        description character varying NOT NULL,
        priority character varying NOT NULL,
        created_at timestamp without time zone default now() NOT NULL,
        updated_at timestamp without time zone default now() NOT NULL,
        primary key (id),
        foreign key (ns_id) references public.ns(id)

    );
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
    drop table public.ticket;
    `);
  }
}
