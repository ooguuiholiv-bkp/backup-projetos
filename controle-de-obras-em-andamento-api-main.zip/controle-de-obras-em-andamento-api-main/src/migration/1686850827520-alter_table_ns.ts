import { MigrationInterface, QueryRunner } from 'typeorm';

export class AlterTableNs1686850827520 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        alter table public.ns add unique(ns);
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(``);
  }
}
