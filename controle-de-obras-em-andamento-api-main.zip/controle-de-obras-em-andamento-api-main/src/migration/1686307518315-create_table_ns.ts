import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateTableNs1686307518315 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        CREATE TABLE public.ns(
          id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
            ns character varying NOT NULL,
            user_id UUID,
            client character varying NOT NULL ,
            cnpj character varying ,
            city character varying ,
            nameobra character varying ,
            type character varying ,
            start_date date,
            completion_date date,
            situation character varying ,
            status_cemig character varying ,
            calc_lt character varying ,
            trav_rod_dnit character varying ,
            trav_rod_der character varying ,
            parameterization character varying ,
            trav_fca character varying ,
            supplies character varying ,
            survey character varying ,
            pre_att character varying ,
            devolution character varying ,
            pendency character varying ,
            cco character varying ,
            transformers character varying ,
            created_at timestamp without time zone default now() NOT NULL,
            updated_at timestamp without time zone default now() NOT NULL,
            primary key (id),
            foreign key (user_id) references public.user(id)
        );
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        drop table public.ns;
    `);
  }
}
