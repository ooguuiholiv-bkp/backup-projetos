import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateTableUser1685465259815 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
        CREATE TABLE public.user(
            id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
            name character varying NOT NULL,
            email character varying NOT NULL,
            cpf character varying,
            type_user int NOT NULL,
            password character varying NOT NULL,
            created_at timestamp without time zone default now() NOT NULL,
            updated_at timestamp without time zone default now() NOT NULL,
            primary key (id)
        );
    
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    queryRunner.query(`
    drop table public.user;
    `);
  }
}
