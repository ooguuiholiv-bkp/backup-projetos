import { TicketEntity } from 'src/ticket/entities/ticket.entity';
import { UserEntity } from 'src/user/entities/user.entity';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';

@Entity({ name: 'ns' })
export class NsEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'ns', nullable: false })
  ns: string;

  @Column({ name: 'user_id', nullable: false })
  userId: string;

  @Column({ name: 'client', nullable: false })
  client: string;

  @Column({ name: 'cnpj', nullable: false })
  cnpj: string;

  @Column({ name: 'city', nullable: true })
  city: string;

  @Column({ name: 'nameobra', nullable: true })
  nameobra: string;

  @Column({ name: 'type', nullable: true })
  type: string;

  @Column({ name: 'start_date' })
  startDate: Date;

  @Column({ name: 'completion_date' })
  completionDate: Date;

  @Column({ name: 'situation', nullable: true })
  situation: string;

  @Column({ name: 'status_cemig', nullable: true })
  statusCemig: string;

  @Column({ name: 'calc_lt', nullable: true })
  calcLt: string;

  @Column({ name: 'trav_rod_dnit', nullable: true })
  travRodDnit: string;

  @Column({ name: 'trav_rod_der', nullable: true })
  travRodDer: string;

  @Column({ name: 'parameterization', nullable: true })
  parameterization: string;

  @Column({ name: 'trav_fca', nullable: true })
  travFca: string;

  @Column({ name: 'supplies', nullable: true })
  supplies: string;

  @Column({ name: 'survey', nullable: true })
  survey: string;

  @Column({ name: 'pre_att', nullable: true })
  preAtt: string;

  @Column({ name: 'devolution', nullable: true })
  devolution: string;

  @Column({ name: 'pendency', nullable: true })
  pendenncy: string;

  @Column({ name: 'cco', nullable: true })
  cco: string;

  @Column({ name: 'transformers', nullable: true })
  transformers: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;

  @JoinColumn({ name: 'user_id', referencedColumnName: 'id' })
  @OneToMany(() => TicketEntity, (ticket) => ticket.ns)
  tickets?: TicketEntity[];
}
