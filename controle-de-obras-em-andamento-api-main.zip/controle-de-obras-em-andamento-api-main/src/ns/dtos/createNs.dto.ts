import { IsDate, IsDateString, IsOptional, IsString } from 'class-validator';

export class CreateNsDto {
  @IsString()
  ns: string;

  @IsString()
  client: string;

  @IsOptional()
  @IsString()
  userId: string;

  @IsOptional()
  @IsString()
  cnpj: string;

  @IsOptional()
  @IsString()
  city: string;

  @IsOptional()
  @IsString()
  nameobra: string;

  @IsOptional()
  @IsString()
  type: string;

  @IsOptional()
  @IsDateString()
  startDate: Date;

  @IsOptional()
  @IsDateString()
  completionDate: Date;

  @IsOptional()
  @IsString()
  situation: string;

  @IsOptional()
  @IsString()
  statusCemig: string;

  @IsOptional()
  @IsString()
  calcLt: string;

  @IsOptional()
  @IsString()
  travRodDnit: string;

  @IsOptional()
  @IsString()
  travRodDer: string;

  @IsOptional()
  @IsString()
  parameterization: string;

  @IsOptional()
  @IsString()
  travFca: string;

  @IsOptional()
  @IsString()
  supplies: string;

  @IsOptional()
  @IsString()
  survey: string;

  @IsOptional()
  @IsString()
  preAtt: string;

  @IsOptional()
  @IsString()
  devolution: string;

  @IsOptional()
  @IsString()
  pendenncy: string;

  @IsOptional()
  @IsString()
  cco: string;

  @IsOptional()
  @IsString()
  transformers: string;
}
