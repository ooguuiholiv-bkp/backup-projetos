import { IsDate, IsString } from 'class-validator';
import { NsEntity } from '../entities/ns.entity';

export class ReturnNsDto {
  id: string;
  ns: string;
  userId: string;
  client: string;
  cnpj: string;
  city: string;
  type: string;
  /*   startDate: Date;
  completionDate: Date; */
  situation: string;
  statusCemig: string;
  calcLt: string;
  travRodDnit: string;
  travRodDer: string;
  parameterization: string;
  travFca: string;
  supplies: string;
  survey: string;
  preAtt: string;
  devolution: string;
  pendenncy: string;
  cco: string;
  transformers: string;
  nameobra: string;

  constructor(nsEntity: NsEntity) {
    this.id = nsEntity.id;
    this.ns = nsEntity.ns;
    this.userId = nsEntity.userId;
    this.client = nsEntity.client;
    this.cnpj = nsEntity.cnpj;
    this.city = nsEntity.city;
    this.nameobra = nsEntity.nameobra;
    this.type = nsEntity.type;
    this.situation = nsEntity.situation;
    this.statusCemig = nsEntity.statusCemig;
    this.calcLt = nsEntity.calcLt;
    this.travRodDnit = nsEntity.travRodDnit;
    this.travRodDer = nsEntity.travRodDer;
    this.parameterization = nsEntity.parameterization;
    this.travFca = nsEntity.travFca;
    this.supplies = nsEntity.supplies;
    this.survey = nsEntity.survey;
    this.preAtt = nsEntity.preAtt;
    this.devolution = nsEntity.devolution;
    this.pendenncy = nsEntity.pendenncy;
    this.cco = nsEntity.cco;
    this.transformers = nsEntity.transformers;
  }
}
