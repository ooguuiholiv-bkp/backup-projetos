import { Injectable, NotFoundException } from '@nestjs/common';
import { NsEntity } from './entities/ns.entity';
import { CreateNsDto } from './dtos/createNs.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository } from 'typeorm';
import { BadGatewayException } from '@nestjs/common/exceptions';
import { UpdateNsDto } from './dtos/updateNs.dto';
import { UserEntity } from 'src/user/entities/user.entity';

@Injectable()
export class NsService {
  constructor(
    @InjectRepository(NsEntity)
    private readonly nsRepository: Repository<NsEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,
  ) {}

  /* Buscar Ns Existente */
  async findNs(ns: string): Promise<NsEntity> {
    const findns = await this.nsRepository.findOne({
      where: {
        ns,
      },
    });
    if (!findns) {
      throw new NotFoundException(`The ns ${ns} was not found`);
    }

    return findns;
  }

  async findNsByClientId(id: string): Promise<NsEntity[]> {
    const findNs = await this.nsRepository.find({
      where: {
        userId: id,
      },
    });
    return findNs;
  }

  /* Buscar Ns pelo Id */
  async findNsById(nsId: string): Promise<NsEntity> {
    const findNs = await this.nsRepository.findOne({
      where: { id: nsId },
    });

    if (!findNs) {
      throw new NotFoundException(`NsId ${nsId} not found`);
    }

    return findNs;
  }

  /* Criar ns */
  async createNs(createNs: CreateNsDto): Promise<NsEntity> {
    // Verificar se o ns já existe no banco de dados
    const checkNs = await this.findNs(createNs.ns).catch(() => undefined);
    if (checkNs) {
      throw new BadGatewayException(
        `This Ns ${createNs.ns} already exists in our database`,
      );
    }
    const checkClient = await this.userRepository.findOne({
      where: {
        name: createNs.client,
      },
    });
    return this.nsRepository.save({
      userId: checkClient.id,
      ...createNs,
    });
  }

  /* Obter lista de Ns */
  async getAllNs(): Promise<NsEntity[]> {
    return this.nsRepository.find();
  }

  /* Deletar uma Ns */
  async deleteNs(nsId: string): Promise<DeleteResult> {
    await this.findNsById(nsId);
    return this.nsRepository.delete(nsId);
  }

  /* Editar uma NS */
  async updateNs(updateNs: UpdateNsDto, nsId: string): Promise<NsEntity> {
    const findNs = await this.findNsById(nsId);
    return this.nsRepository.save({
      ...findNs,
      ...updateNs,
    });
  }
}
