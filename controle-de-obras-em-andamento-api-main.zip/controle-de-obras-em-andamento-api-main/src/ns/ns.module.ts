import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { NsEntity } from './entities/ns.entity';
import { NsController } from './ns.controller';
import { NsService } from './ns.service';
import { UserEntity } from 'src/user/entities/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([NsEntity, UserEntity])],
  controllers: [NsController],
  providers: [NsService],
})
export class NsModule {}
