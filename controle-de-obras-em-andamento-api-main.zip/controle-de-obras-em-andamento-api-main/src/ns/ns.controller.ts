import { Controller } from '@nestjs/common';
import { NsService } from './ns.service';
import { CreateNsDto } from './dtos/createNs.dto';
import { NsEntity } from './entities/ns.entity';
import {
  Body,
  Delete,
  Get,
  Param,
  Post,
  UsePipes,
  ValidationPipe,
  Put,
} from '@nestjs/common';
import { ReturnNsDto } from './dtos/returnNS.dto';
import { DeleteResult } from 'typeorm';
import { UpdateNsDto } from './dtos/updateNs.dto';
import { Roles } from 'src/decorators/roles.decorator';
import { UserType } from 'src/user/enum/user-type.enum';

@Controller('ns')
export class NsController {
  constructor(private readonly nsService: NsService) {}

  //TODO Ativar validation pipe
  @Roles(UserType.Admin, UserType.Editor)
  @UsePipes(new ValidationPipe({ forbidNonWhitelisted: true, whitelist: true }))
  @Post()
  async createNs(@Body() createNs: CreateNsDto): Promise<NsEntity> {
    return this.nsService.createNs(createNs);
  }

  @Get()
  async getAllNs(): Promise<ReturnNsDto[]> {
    return (await this.nsService.getAllNs()).map(
      (nsEntity) => new ReturnNsDto(nsEntity),
    );
  }

  @Get('/:nsId')
  async getNsById(@Param('nsId') nsId: string): Promise<ReturnNsDto> {
    return new ReturnNsDto(await this.nsService.findNsById(nsId));
  }

  @Get('/u/:id')
  async getNsByClientId(@Param('id') id: string): Promise<ReturnNsDto[]> {
    return (await this.nsService.findNsByClientId(id)).map(
      (nsEntity) => new ReturnNsDto(nsEntity),
    );
  }

  @Roles(UserType.Admin, UserType.Editor)
  @Delete('/:nsId')
  async deleteNs(@Param('nsId') nsId: string): Promise<DeleteResult> {
    return this.nsService.deleteNs(nsId);
  }

  @Roles(UserType.Admin, UserType.Editor)
  @UsePipes(new ValidationPipe({ forbidNonWhitelisted: true, whitelist: true }))
  @Put('/:nsId')
  async updateNs(
    @Body() updateNs: UpdateNsDto,
    @Param('nsId') nsId: string,
  ): Promise<NsEntity> {
    return this.nsService.updateNs(updateNs, nsId);
  }
}
