import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  UsePipes,
  ValidationPipe,
  Put,
} from '@nestjs/common';
import { CreateUserDto } from './dtos/createUser.dto';
import { UserService } from './user.service';
import { UserEntity } from './entities/user.entity';
import { ReturnUserDto } from './dtos/returnUser.dto';
import { Roles } from 'src/decorators/roles.decorator';
import { UserType } from './enum/user-type.enum';
import { DeleteResult } from 'typeorm';
import { UpdateUserDto } from './dtos/updateUser.dto';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  /* Cadastrar um novo usuário */
  //@Roles(UserType.Editor, UserType.Admin)
  @UsePipes(new ValidationPipe({ forbidNonWhitelisted: true, whitelist: true }))
  @Post()
  async createUser(@Body() createUser: CreateUserDto): Promise<UserEntity> {
    return this.userService.createUser(createUser);
  }

  /* Obter lista de usuários */
  @Get()
  async getAllUser(): Promise<ReturnUserDto[]> {
    return (await this.userService.getAllUser()).map(
      (userEntity) => new ReturnUserDto(userEntity),
    );
  }

  /* Obter um usuário atraves do ID */
  @Get('i/:userId')
  async getUserById(@Param('userId') userId: string): Promise<ReturnUserDto> {
    return new ReturnUserDto(
      await this.userService.getUserByIdUsingRelations(userId),
    );
  }

  /* Deletar um usuário */
  @Roles(UserType.Admin)
  @Delete('/:userId')
  async deleteUser(@Param('userId') userId: string): Promise<DeleteResult> {
    return this.userService.deleteUser(userId);
  }

  /* Atualizar um usuário */
  @Roles(UserType.Admin)
  @UsePipes(new ValidationPipe({ forbidNonWhitelisted: true, whitelist: true }))
  @Put('/:userId')
  async updateUser(
    @Body() updateUser: UpdateUserDto,
    @Param('userId') userId: string,
  ): Promise<UserEntity> {
    return this.userService.updateUser(updateUser, userId);
  }

  @Get('c')
  async getUsersWhenClient(): Promise<ReturnUserDto[]> {
    return (await this.userService.getUsersWhenClient()).map(
      (userEntity) => new ReturnUserDto(userEntity),
    );
  }
}
