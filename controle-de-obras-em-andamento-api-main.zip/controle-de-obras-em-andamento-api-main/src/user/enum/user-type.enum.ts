export enum UserType {
  Admin = 1,
  Editor = 2,
  Client = 3,
}
