import { ReturnAddressDto } from '../../address/dtos/returnAddress.dto';
import { UserEntity } from './../entities/user.entity';

export class ReturnUserDto {
  id: string;
  name: string;
  email: string;
  cpf: string;
  addresses?: ReturnAddressDto[];
  typeUser: number;

  constructor(userEntity: UserEntity) {
    this.id = userEntity.id;
    this.name = userEntity.name;
    this.email = userEntity.email;
    this.cpf = userEntity.cpf;
    this.typeUser = userEntity.typeUser;
    this.addresses = userEntity.addresses
      ? userEntity.addresses.map((address) => new ReturnAddressDto(address))
      : undefined;
  }
}
