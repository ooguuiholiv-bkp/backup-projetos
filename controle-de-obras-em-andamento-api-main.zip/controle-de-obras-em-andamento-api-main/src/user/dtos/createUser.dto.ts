import {
  IsEmail,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
} from 'class-validator';

export class CreateUserDto {
  @IsString()
  name: string;

  @IsEmail()
  email: string;

  @IsOptional()
  @IsString()
  cpf: string;

  @IsString()
  password: string;

  @Min(2)
  @Max(3)
  @IsInt()
  typeUser: number;
}
