import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateUserDto } from './dtos/createUser.dto';
import { UserEntity } from './entities/user.entity';
import { hash } from 'bcrypt';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository } from 'typeorm';
import { BadGatewayException } from '@nestjs/common/exceptions';
import { UpdateUserDto } from './dtos/updateUser.dto';
import { UserType } from './enum/user-type.enum';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepository: Repository<UserEntity>,
  ) {}

  /* Criar novo usuário */
  async createUser(createUserDto: CreateUserDto): Promise<UserEntity> {
    const user = await this.findUserByEmail(createUserDto.email).catch(
      () => undefined,
    );

    if (user) {
      throw new BadGatewayException(
        `This email ${createUserDto.email} already exists in our database`,
      );
    }

    // const userCpf = await this.findUserByCpf(createUserDto.cpf).catch(
    //   () => undefined,
    // );

    /* if (userCpf) {
      throw new BadGatewayException(
        `This cpf ${createUserDto.cpf} already exists in our database`,
      );
    } */
    const saltOrRounds = 10;

    const passwordHash = await hash(createUserDto.password, saltOrRounds);
    const capName = createUserDto.name.toUpperCase();
    const lowMail = createUserDto.email.toLocaleLowerCase();
    return this.userRepository.save({
      ...createUserDto,
      name: capName,
      email: lowMail,
      password: passwordHash,
    });
  }

  /* Obter todos os usuários */
  async getAllUser(): Promise<UserEntity[]> {
    return this.userRepository.find();
  }

  /* Buscar usuário pelo ID */
  async findUserById(userId: string): Promise<UserEntity> {
    const user = await this.userRepository.findOne({
      where: {
        id: userId,
      },
    });

    if (!user) {
      throw new NotFoundException(`UserId ${userId} not found`);
    }

    return user;
  }

  /* Busca por usuario com relação de tabelas */
  async getUserByIdUsingRelations(userId: string): Promise<UserEntity> {
    return this.userRepository.findOne({
      where: {
        id: userId,
      },
      relations: {
        addresses: {
          city: {
            state: true,
          },
        },
      },
    });
  }

  /* Buscar usuário por email */
  async findUserByEmail(email: string): Promise<UserEntity> {
    const user = await this.userRepository.findOne({
      where: {
        email,
      },
    });
    if (!user) {
      throw new NotFoundException(`The email ${email} was not found`);
    }

    return user;
  }
  /* Buscar usuário por CPF */
  async findUserByCpf(cpf: string): Promise<UserEntity> {
    const user = await this.userRepository.findOne({
      where: {
        cpf,
      },
    });
    if (!user) {
      throw new NotFoundException(`The email ${cpf} was not found`);
    }

    return user;
  }

  /* Deletar um usuário */
  async deleteUser(userId: string): Promise<DeleteResult> {
    await this.findUserById(userId);
    return this.userRepository.delete(userId);
  }

  /* Editar um usuário */
  async updateUser(
    updateUser: UpdateUserDto,
    userId: string,
  ): Promise<UserEntity> {
    const user = await this.findUserById(userId);

    return this.userRepository.save({
      ...user,
      ...updateUser,
    });
  }

  async getUsersWhenClient(): Promise<UserEntity[]> {
    const users = await this.userRepository.find({
      where: {
        typeUser: 3,
      },
    });

    if (!users) {
      throw new NotFoundException(`No user registered as a customer was found`);
    }

    return users;
  }
}
