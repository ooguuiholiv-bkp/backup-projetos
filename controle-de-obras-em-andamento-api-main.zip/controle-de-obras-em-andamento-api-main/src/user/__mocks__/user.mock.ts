import { UserEntity } from '../entities/user.entity';
import { UserType } from '../enum/user-type.enum';

export const UserEntityMock: UserEntity = {
  cpf: '123',
  createdAt: new Date(),
  email: 'mail@mock.com',
  id: 'uuid',
  name: 'mock',
  password: '$2b$10$d0AmfIITG8uKFpMfQO2WleYn1V07Nyr8jHR0U7HiFF/vjEDqqn9a2',
  typeUser: UserType.Editor,
  updatedAt: new Date(),
};
