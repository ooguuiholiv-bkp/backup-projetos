import { CreateUserDto } from '../dtos/createUser.dto';

export const createUserMock: CreateUserDto = {
  cpf: '123',
  email: 'mail@mock.com',
  name: 'mock',
  password: 'mock',
  typeUser: 1,
};
