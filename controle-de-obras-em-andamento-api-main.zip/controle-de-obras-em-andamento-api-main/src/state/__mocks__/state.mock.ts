import { StateEntity } from '../entities/state.entity';

export const stateMock: StateEntity = {
  createdAt: new Date(),
  id: 77777,
  name: 'estado01',
  updatedAt: new Date(),
  cities: null,
};
